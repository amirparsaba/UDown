<!DOCTYPE html>
<html class="language-en" lang="en">
    
<head>
	<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="rating" content="RTA-5042-1996-1400-1577-RTA" />

    <title>Pornhub</title>
    
    
    <script>
        var COOKIE_DOMAIN = 'pornhub.com';
        window.telemetryHostname = "https:\/\/i.pornhub.com";
    </script>

    <script src="https://ei.phncdn.com/www-static/js/lib/interval-helper.js?cache=2026052109"></script>

            
                                                

        
<script>    var cbDomainName = 'pornhub.com';
    var baseUrl = 'https://www.pornhub.com';
    var cbConsent = '3';
    var isLoggedInUser = 0;
    var isPlatformMobile = 0;
    var isPremiumDomainBanner = 0;
    var essentialCookiesListAll = JSON.parse('{"a.adtng.com":[],"ads.trafficjunky.net":[],"creative.dzhjmp.com":{"__cflb":"essential"},"go.dzhjmp.com":{"__cflb":"essential"},"google.com":{"HSID":"essential","SEARCH_SAMESITE":"essential","SIDCC":"essential"},"modelhub.com":{"testCookieTubescms":"essential"},"pornhub.com":{"accessAgeDisclaimerPH":"essential","accessPH":"essential","adBlockAlertHidden":"essential","additionalIdsRequiredModal":"essential","age_verified":"essential","aihac":"essential","autoplay":"essential","avukredirecturl":"essential","awc":"essential","blogUserAvatar":"essential","blogUserName":"essential","comp_*":"essential","cookieBannerEU":"essential","cookieBannerState":"essential","cookieConsent":"essential","cookiesBanner":"essential","cts":"essential","desired_username":"essential","dismissCoPerfAdditionalIdModal":"essential","email2faModal":"essential","emailConfirmCookie_*":"essential","entryOrigin":"essential","flag_limit_timeout":"essential","from":"essential","fr_unblock":"essential","g_state":"essential","il":"essential","isSuggestion":"essential","jp-ud":"essential","lang":"essential","legalTextLangId":"essential","local_storage":"essential","mi_deterrence":"essential","overwriteCCVal":"essential","password_reset_hash":"essential","platform":"essential","platform_cookie_reset":"essential","platform_forced":"essential","popShown":"essential","pornhub_av":"essential","premium_redirect":"essential","prerollShown":"essential","preWallNotice":"essential","quality":"essential","redirect":"essential","RNLBSERVERIDPH":"essential","rp":"essential","settingsScrollTop":"essential","shouldShowModalCppVerificationWindow":"essential","showModalPremiumTry":"essential","showPremiumWelcomeFromPornhub":"essential","signup:from":"essential","ss":"essential","stage_sso_token":"essential","STCtestcookie":"essential","STCtestcookie3":"essential","STCtestcookie4":"essential","temp_album_id":"essential","TestCookieNecessaryP":"essential","testCookieTubescms":"essential","title_translation_*":"essential","trending_search":"essential","views":"essential","vk_try":"essential","__l":"essential","__s":"essential"},"pornhub.org":{"accessAgeDisclaimerPH":"essential","accessPH":"essential","adBlockAlertHidden":"essential","additionalIdsRequiredModal":"essential","age_verified":"essential","aihac":"essential","autoplay":"essential","avukredirecturl":"essential","awc":"essential","blogUserAvatar":"essential","blogUserName":"essential","comp_*":"essential","cookieBannerEU":"essential","cookieBannerState":"essential","cookieConsent":"essential","cookiesBanner":"essential","cts":"essential","desired_username":"essential","dismissCoPerfAdditionalIdModal":"essential","email2faModal":"essential","emailConfirmCookie_*":"essential","entryOrigin":"essential","flag_limit_timeout":"essential","from":"essential","fr_unblock":"essential","g_state":"essential","il":"essential","isSuggestion":"essential","jp-ud":"essential","lang":"essential","legalTextLangId":"essential","local_storage":"essential","mi_deterrence":"essential","overwriteCCVal":"essential","password_reset_hash":"essential","platform":"essential","platform_cookie_reset":"essential","platform_forced":"essential","popShown":"essential","pornhub_av":"essential","premium_redirect":"essential","prerollShown":"essential","preWallNotice":"essential","quality":"essential","redirect":"essential","RNLBSERVERIDPH":"essential","rp":"essential","settingsScrollTop":"essential","shouldShowModalCppVerificationWindow":"essential","showModalPremiumTry":"essential","showPremiumWelcomeFromPornhub":"essential","signup:from":"essential","ss":"essential","stage_sso_token":"essential","STCtestcookie":"essential","STCtestcookie3":"essential","STCtestcookie4":"essential","temp_album_id":"essential","TestCookieNecessaryP":"essential","testCookieTubescms":"essential","title_translation_*":"essential","trending_search":"essential","views":"essential","vk_try":"essential","__l":"essential","__s":"essential"},"pornhubpremium.com":{"aihac":"essential","atsd":"essential","atsm":"essential","atstrackPiece1":"essential","atstrackPiece2":"essential","atstrackPiece3":"essential","atstrackPiece4":"essential","autoplay":"essential","awc":"essential","comp_*":"essential","cookieBannerState":"essential","cookieConsent":"essential","cookiesBanner":"essential","desired_username":"essential","dismissCoPerfAdditionalIdModal":"essential","email2faModal":"essential","entryOrigin":"essential","expiredEnterModalShown":"essential","flag_limit_timeout":"essential","from":"essential","g_state":"essential","il":"essential","isSuggestion":"essential","jp-ud":"essential","lang":"essential","local_storage":"essential","mi_deterrence":"essential","overwriteCCVal":"essential","password_reset_hash":"essential","platform":"essential","platform_forced":"essential","premium_redirect":"essential","prerollShown":"essential","quality":"essential","RNLBSERVERIDPH":"essential","settingsScrollTop":"essential","showModalPremiumTry":"essential","showPremiumWelcomeFromPornhub":"essential","ss":"essential","stage_sso_token":"essential","STCtestcookie":"essential","STCtestcookie3":"essential","STCtestcookie4":"essential","TestCookieNecessaryP":"essential","testCookieTubescms":"essential","title_translation_*":"essential"},"srv272a.com":[],"thumbzilla.com":{"accessAgeDisclaimerTZ":"essential","aihac":"essential","atstrackPiece1":"essential","atstrackPiece2":"essential","awc":"essential","comp_*":"essential","cookieBannerState":"essential","cookieConsent":"essential","cookiesBanner":"essential","flag_limit_timeout":"essential","platform":"essential","platform_forced":"essential","prerollShown":"essential","RNLBSERVERIDPH":"essential","ss":"essential","stage_sso_token":"essential","STCtestcookie":"essential","STCtestcookie3":"essential","STCtestcookie4":"essential","TestCookieNecessaryP":"essential"},"twitter.com":[],"www.sffsdvc.com":[]}');
    var allowedCookies = [];
    var cookieConsentValues = {"no-action":1,"essential":2,"all":3,"functional":10,"analytics":18,"advertising":34,"functional-analytics":26,"functional-advertising":42,"analytics-advertising":50}
    var currentDomain = 'https://www.pornhub.com';
    var essentialCookiesList = typeof essentialCookiesListAll['pornhub.com'] != 'undefined' ? Object.keys(essentialCookiesListAll['pornhub.com']) : '';
    var Banner_Text = {"primaryCTA":"Accept all cookies","secondaryCTA":"Accept only essential cookies","thirdCTA":"Customize Cookies","thirdCTASaveText":"Save And Apply","shortBannerText":"Some features may not be available with your selection. For a better browsing experience, you may select"};
    var originPart = 'view_video.php';
    var originUrl = '/view_video.php?viewkey=68d18a4de7806';
    var logCookieConsentUrl = '/user/log_user_cookie_consent';
    var logCookieConsentUrlPremium = '/user/log_user_cookie_consent_premium';
    var biggerCookieBannerTemplate = "\n    <img class=\"phLogo\" src=\"https:\/\/ei.phncdn.com\/www-static\/images\/pornhub_logo_straight.svg?cache=2026052109\" alt=\"Pornhub Logo\"\/>\n    <div class=\"scrollableBannerContent\">\n        <p style=\"margin-left:0px;text-align:justify;\">We use cookies and similar technologies that are necessary to run our Websites (essential cookies). We also use Analytics, Functionality and Targeting cookies to analyse our Websites\u2019 traffic, optimize your experience, personalize content and serve targeted advertisements. You can switch off cookies at any time by visiting the Manage Cookies option at the footer of the page.<\/p>\n        \n        <div class=\"learnMoreContent\">\n            <p>Learn more in our <a href=\"https:\/\/www.pornhub.com\/information\/cookie-notice\">Cookie Notice<\/a><span style=\"color:rgb(23,43,77);\">.<\/span> For more information about how we process your personal data, please refer to our<span style=\"color:rgb(23,43,77);\"> <\/span><a href=\"https:\/\/www.pornhub.com\/information\/privacy\">Privacy Notice<\/a>.<\/p>\n        <\/div>\n    <\/div>\n";

    var customizeCookiesTemplate = "<div class=\"customizeCookiesContent\">\n            <img class=\"phLogo\" src=\"https:\/\/ei.phncdn.com\/www-static\/images\/pornhub_logo_straight.svg?cache=2026052109\" alt=\"Pornhub Logo\"\/>\n            <h3 class=\"heading1\">Customize Cookies<\/h3>\n            <div class=\"customizeCookiesWrapper\">\n                <div class=\"backToscrollableContent\"><i class=\"ph-icon-chevron-left\"><\/i> Back<\/div>\n                <div class=\"customizeMainContent\">\n                    <div class=\"column\">\n                        <div class=\"customizeFirstColumn\">\n                            <div class=\"expandableSection\">\n                                <div class=\"title expandableTitle\"><span class=\"ph-icon-chevron-down\"><\/span>Essential Cookies<\/div>\n                                <span class=\"toggleBtn\">always active<\/span>\n                                <p style=\"margin-left:0px;text-align:justify;\">These are cookies necessary for the functioning of the Website and cannot be switched off in our systems as they enable core website functionality They are used to carry out the transmission of a communication (e.g. Load balancing cookies), provide you with the requested services or are set in response to actions made by you,&nbsp; such as setting your privacy preferences, logging in or filling in forms (UI customization cookies). \u202f \u202f&nbsp;&nbsp;<\/p>\n                            <\/div>\n                            <div class=\"expandableSection\">\n                                <div class=\"title expandableTitle\"><span class=\"ph-icon-chevron-down\"><\/span>Functional Cookies<\/div>\n                                <label class=\"customizeToggleSwitch\" for=\"functionalCookies\">\n                                    <input type=\"checkbox\" id=\"functionalCookies\" value=\"8\">\n                                    <div class=\"slider round\">\n                                        <span class=\"toggle-icon\"><\/span>\n                                    <\/div>\n                                <\/label>\n                                <p style=\"margin-left:0px;text-align:justify;\">These cookies are set to implement additional functionalities or to enhance features and website performance. These cookies help us personalize and enhance your online experience on the Website. This type of cookies also allows us to recognize you when you return to the Website and to remember your choices.&nbsp;<\/p>\n                            <\/div>\n                            <div class=\"expandableSection\">\n                                <div class=\"title expandableTitle\"><span class=\"ph-icon-chevron-down\"><\/span>Analytics Cookies<\/div>\n                                <label class=\"customizeToggleSwitch\" for=\"analyticsCookies\">\n                                    <input type=\"checkbox\" id=\"analyticsCookies\" value=\"16\">\n                                    <div class=\"slider round\">\n                                        <span class=\"toggle-icon\"><\/span>\n                                    <\/div>\n                                <\/label>\n                                <p style=\"margin-left:0px;text-align:justify;\">These cookies allow us to recognize and count the number of users and to see how users use and explore the Website, for example they allow us to carry out statistical analysis of page use, interactions, and paths a user takes through the Website to improve the performance of our Website. This is known as \u2018digital analytics,\u2019 where this information allows us to know what content on our Website is the most and least popular. \u202fAdditionally, we use third party session recording technologies that help us better understand our users\u2019 experience, however, the recording data is pseudonymized.&nbsp;<\/p>\n                            <\/div>\n                        <\/div>\n                    <\/div>\n                    <div class=\"column\">\n                        <div class=\"customizeSecondColumn\">\n                            <div class=\"expandableSection\">\n                                <div class=\"title expandableTitle\"><span class=\"ph-icon-chevron-down\"><\/span>Targeting\/Advertising Cookies<\/div>\n                                <label class=\"customizeToggleSwitch\" for=\"advertisingCookies\">\n                                    <input type=\"checkbox\" id=\"advertisingCookies\" value=\"32\">\n                                    <div class=\"slider round\">\n                                        <span class=\"toggle-icon\"><\/span>\n                                    <\/div>\n                                <\/label>\n                                <p style=\"margin-left:0px;text-align:justify;\">These cookies enable us to make the Website more relevant to your interests and to help us serve ads that might be of interest to you. The Website and our advertising partners set these cookies to provide behavioural advertising and define the number of ads that will be displayed to you. Collected data can be any type of browsing information necessary to understand your browsing habits. If you choose to disable this type of cookies, you will still see advertisements, but they will be less relevant and will not be tailored to your interests.<\/p>\n                            <\/div>\n                        <\/div>\n                    <\/div>\n                <\/div>\n            <div>\n        <\/div>";
    var isGlobalCookieBanner = 1;
    var globalCookieBannerContent = "\n        <div class=\"globalCookieBanner\">\n            <div class=\"globalCookieBanner__wrapper\">\n                <i class=\"globalCookieBanner__icon bg-cookie\"><\/i>\n\n                <div class=\"globalCookieBanner__content\">This site uses cookies to help improve your user experience. Learn more about how we use cookies in our <a href=\"https:\/\/www.pornhub.com\/information\/cookie-notice\">Cookie Notice<\/a>.\n                    <button class=\"globalCookieBanner__close js-closeGlobalBanner\">\n                        <i class=\"ph-icon-cross\"><\/i>\n                    <\/button>\n                <\/div>\n                <div class=\"globalCookieBanner__buttons\">\n                    <button class=\"buttonBase js-customizeGlobalCookies\">Customize Cookies<\/button>\n                    <button class=\"buttonBase js-acceptGlobalCookies\">Ok<\/button>\n                <\/div>\n            <\/div>\n        <\/div>\n    ";
    var shortCookieBannerContent = "\n        <p>Some features may not be available with your selection. For a better browsing experience, you may select <span class=\"cbPrimaryCTA cbSpan\">' Accept all cookies '<\/span><\/p><button class=\"cbCloseButton ph-icon-cross\" title=\"close\"><\/button>\n    ";
</script>
    <script>var cbExpiration,cbCookieName="cookieConsent",bsCookieName="bs",cbCookieBannerStateName="cookieBannerState",customHash=window.location.hash,CookieDate=new Date,nonEssentialLocalStorageKeys=(CookieDate.setFullYear(CookieDate.getFullYear()+1),cbExpiration=CookieDate.toUTCString(),["playlistRated","gifRated","photoRated","streamRated","search","searches","ISP_INFO_SEND","newTermSearched","recentSearch","currentTimeStamp","watchedVideoStorage","favoritesRedirect","promoBannerPersistant","eta_guid","ALIAS_premiumPromoBanner","pwaInstallPrompt","commentsRated"]),essentialLocalStorageKeys=["LsAccessSuccess","enableStorage","phLivePlayerQuality","commentsReported","dataProductID","trialBottomNotificationHidden","notLoggedIn","savedData","videoOffset","mgp_player","cookieNamesList","storage_test","__storage_test__"],_cbCookieRegex=new RegExp("(?:(?:^|.*;\\s*)"+cbCookieName+"\\s*\\=\\s*([^;]*).*$)|^.*$"),_cbCookieBannerStateRegex=new RegExp("(?:(?:^|.*;\\s*)"+cbCookieBannerStateName+"\\s*\\=\\s*([^;]*).*$)|^.*$"),cbCookie=document.cookie.replace(_cbCookieRegex,"$1"),cbCookieBannerState=document.cookie.replace(_cbCookieBannerStateRegex,"$1"),linkToPrivacyPolicy="https://www.pornhub.com/information/privacy#cookies",cbTexts={primaryCTA:"Accept all cookies",secondaryCTA:"Accept only essential cookies",thirdCTA:"Customize Cookies",shortBannerText:"Some features may not be available with your selection. For a better browsing experience, you may select"},shouldLogGTMImpression=!1,CookieHelper={listCookiesArrayFromString:function(e){return e.split("; ").map(function(e){return e.split("=")[0]})},deleteCookie:function(e){document.cookie=e+"=0;expires=Thu, 01 Jan 1970 00:00:01 GMT",document.cookie=e+"=0;expires=Thu, 01 Jan 1970 00:00:01 GMT;domain="+cbDomainName},deleteNonEssentialCookies:function(e){var n=[];(n=allowedCookies.length?e.filter(function(e){return!(allowedCookies.includes(e)||e.startsWith("comp_")||e.startsWith("emailConfirmCookie_")||e.startsWith("playlistShuffle_")&&allowedCookies.includes("playlistShuffle_*")||e.startsWith("fg_")&&allowedCookies.includes("fg_*"))}):n).forEach(function(e){"undefined"!=typeof cookieStore&&void 0!==cookieStore.delete&&cookieStore.delete(e),document.cookie=e+"=0;expires=Thu, 01 Jan 1970 00:00:01 GMT;path=/",document.cookie=e+"=0;expires=Thu, 01 Jan 1970 00:00:01 GMT;domain="+cbDomainName})},deleteNonEssentialsLocalStorageKeys:function(){var o=[];nonEssentialLocalStorageKeys.forEach(function(e){-1!==e.indexOf("ALIAS_")&&o.push(e.replace("ALIAS_",""))}),"undefined"!=typeof localStorage&&(nonEssentialLocalStorageKeys.forEach(function(e){localStorage.removeItem(e)}),o.length)&&Object.keys(localStorage).filter(function(n){return!CookieHelper.isEssentialLSKey(n)&&o.some(function(e){return-1!==n.indexOf(e)})}).forEach(function(e){localStorage.removeItem(e)}),"undefined"!=typeof sessionStorage&&(nonEssentialLocalStorageKeys.forEach(function(e){sessionStorage.removeItem(e)}),o.length)&&Object.keys(sessionStorage).filter(function(n){return!CookieHelper.isEssentialLSKey(n)&&o.some(function(e){return-1!==n.indexOf(e)})}).forEach(function(e){sessionStorage.removeItem(e)})},isEssentialLSKey:function(e){var n=-1!==e.indexOf("playlist_shuffle_"),o=-1!==e.indexOf("comp_");return essentialLocalStorageKeys.includes(e)||n||o},isNonEssentialLSKey:function(e){return nonEssentialLocalStorageKeys.includes(e)},isInEssentialList:function(e){return essentialCookiesList.includes(e)},canAdd:function(e){return 0==allowedCookies.length||allowedCookies.includes(e)||0===e.indexOf("comp_")||0===e.indexOf("emailConfirmCookie_")||0===e.indexOf("playlistShuffle_")&&allowedCookies.includes("playlistShuffle_*")||0===e.indexOf("fg_")&&allowedCookies.includes("fg_*")},getCurrentConsent:function(){return document.cookie.replace(_cbCookieRegex,"$1")},isAllowedCategory:function(n){var e=document.cookie.replace(_cbCookieRegex,"$1");return(e=isGlobalCookieBanner&&cbConsent&&(void 0!==e||"1"===e||""===e)?cbConsent:e)==cookieConsentValues.all||Object.values(Object.keys(cookieConsentValues).filter(function(e){return-1!=e.indexOf(n)}).reduce(function(e,n){return e[n]=cookieConsentValues[n],e},{})).includes(Number(e))}},initializedLangSelector=(!isGlobalCookieBanner&&""==cbCookie||"1"==cbCookie||"#cookie-banner"===customHash||"#cookie-banner-expand"===customHash?(showFullCookieBanner(),shouldLogGTMImpression=!0):isGlobalCookieBanner||"2"!=cbCookie||"1"===cbCookieBannerState||showShortCookieBanner(),!1),initialCookieBannerHeight=0;function showFullCookieBanner(){var t,i,e,a,r,n;isGlobalCookieBanner?void 0!==globalCookieBanner&&globalCookieBanner.showBanner():((t=document.getElementById("cookieBanner"))&&t.classList.contains("cbShort")&&(t.classList.remove("cbShort"),t.innerHTML=""),t||((e=document.createElement("div")).id="cookieBanner",document.body&&document.body.appendChild(e)),t&&t.classList.add("withOverlay"),(i=document.createElement("div")).id="cookieBannerWrapper",(e=document.createElement("div")).id="cookieBannerContent","undefined"!=typeof biggerCookieBannerTemplate&&(e.innerHTML=biggerCookieBannerTemplate,"undefined"==typeof isPlatformMobile||isPlatformMobile||e.classList.add("cookieBannerV1")),(a=document.createElement("button")).classList.add("cbPrimaryCTA","cbButton","gtm-event-cookie-banner"),a.textContent=("undefined"!=typeof Banner_Text&&Banner_Text.primaryCTA?Banner_Text:cbTexts).primaryCTA,a.dataset.event="cookie_banner",a.dataset.label="accept_all",a.addEventListener("click",function(){document.cookie=cbCookieName+"=3; expires="+cbExpiration+";domain="+cbDomainName+";secure;path=/",cookieConsentUserChoice("granted"),t.className="",t.innerHTML="",initializedLangSelector=!1,addClogCookieBanner(currentDomain,"accept-all",originPart,originUrl),logUserConsentCookie(3),mainInterval.unsubscribe(cookieChangeCallbackName),"#cookie-banner-expand"===customHash&&history.pushState("",document.title,window.location.pathname+window.location.search)}),(r=document.createElement("button")).classList.add("cbSecondaryCTA","cbButton","gtm-event-cookie-banner"),r.textContent=("undefined"!=typeof Banner_Text&&Banner_Text.secondaryCTA?Banner_Text:cbTexts).secondaryCTA,r.dataset.event="cookie_banner",r.dataset.label="accept_essential",r.addEventListener("click",function(){document.cookie=cbCookieName+"=2; expires="+cbExpiration+";domain="+cbDomainName+";secure;path=/",cookieConsentUserChoice("denied"),t.classList.contains("withOverlay")&&t.classList.remove("withOverlay"),i.remove(),showShortCookieBanner(),clearNonEssentialCookies(),CookieHelper.deleteNonEssentialsLocalStorageKeys(),"#cookie-banner-expand"===customHash&&history.pushState("",document.title,window.location.pathname+window.location.search),location.reload(),addClogCookieBanner(currentDomain,"accept-essential",originPart,originUrl),logUserConsentCookie(2)}),(n=document.createElement("button")).classList.add("cbThirdCTA","cbButton","gtm-event-cookie-banner"),n.textContent=("undefined"!=typeof Banner_Text&&Banner_Text.thirdCTA?Banner_Text:cbTexts).thirdCTA,n.dataset.event="cookie_banner",n.dataset.label="customize",n.addEventListener("click",function(e){var n,o=this,e=e?e.target:null;e&&e.classList.contains("saveChangesBtn")?(n=(e={functional:(e={functional:document.getElementById("functionalCookies"),analytics:document.getElementById("analyticsCookies"),advertising:document.getElementById("advertisingCookies")}).functional.checked?Number(e.functional.value):0,analytics:e.analytics.checked?Number(e.analytics.value):0,advertising:e.advertising.checked?Number(e.advertising.value):0}).functional&&e.analytics&&e.advertising?3:2+e.functional+e.analytics+e.advertising,document.cookie=cbCookieName+"="+n+"; expires="+cbExpiration+";domain="+cbDomainName+";secure;path=/",e.analytics&&cookieConsentUserChoice("granted"),logGTMEvent(e),2===n?(t.classList.contains("withOverlay")&&t.classList.remove("withOverlay"),i.remove(),showShortCookieBanner(),clearNonEssentialCookies(),CookieHelper.deleteNonEssentialsLocalStorageKeys()):(e=document.getElementById("cookieBanner"))&&(e.className="",e.innerHTML=""),"#cookie-banner-expand"===customHash&&history.pushState("",document.title,window.location.pathname+window.location.search),location.reload(),logUserConsentCookie(n),addClogCookieBanner(currentDomain,"save-cookie-pref",originPart,originUrl),initializedLangSelector=!1):(o.removeAttribute("data-event"),o.removeAttribute("data-label"),MG_Utils.removeClass(o,"gtm-event-cookie-banner"),expandCustomizedOptions(o,a,r))}),i.appendChild(e),i.appendChild(a),i.appendChild(r),n&&i.appendChild(n),"undefined"!=typeof isPlatformMobile&&isPlatformMobile&&i.classList.add("mobileCCBanner"),t&&t.appendChild(i),addStyling(),t&&t.appendChild(i),document.body?(addStyling(),t&&t.appendChild(i)):window.addEventListener("DOMContentLoaded",function(e){addStyling(),t&&t.appendChild(i)}),document.addEventListener("click",function(e){var n,o,t,i=e?e.target:null;i&&MG_Utils.hasClass(i,"showPrivacyPolicy")?(e.stopImmediatePropagation(),showPrivacyPolicy(i)):i&&"cookieBanner"===i.id?(n=document.querySelector(".cbPrimaryCTA"),o=document.querySelector(".cbSecondaryCTA"),t=document.querySelector(".cbThirdCTA "),n&&MG_Utils.addClass(n,"focus"),o&&MG_Utils.addClass(o,"focus"),t&&MG_Utils.addClass(t,"focus"),setTimeout(function(){n&&MG_Utils.removeClass(n,"focus"),o&&MG_Utils.removeClass(o,"focus"),t&&MG_Utils.removeClass(t,"focus")},100)):i&&MG_Utils.hasClass(i,"expandableTitle")&&(e.stopImmediatePropagation(),expandCustomizeDetail(i))}),""===CookieHelper.getCurrentConsent()&&(document.cookie=cbCookieName+"=1; expires="+cbExpiration+"; domain="+cbDomainName+"; secure;path=/"),document.cookie=cbCookieBannerStateName+"=0;expires=Thu, 01 Jan 1970 00:00:01 GMT",document.cookie=cbCookieBannerStateName+"=0;expires=Thu, 01 Jan 1970 00:00:01 GMT;domain="+cbDomainName,"3"!==cbCookie&&(clearNonEssentialCookies(),CookieHelper.deleteNonEssentialsLocalStorageKeys()),setTimeout(function(){"#cookie-banner-expand"===customHash&&t&&expandCustomizedOptions(n,a,r)},0),!initializedLangSelector&&t&&(bannerChangeLanguage(),initializedLangSelector=!0),window.addEventListener("resize",function(e){var n=document.getElementById("cookieBannerWrapper");n&&(n.style.removeProperty("height"),initialCookieBannerHeight=n.clientHeight)}))}function bannerChangeLanguage(){var e=document.getElementById("cookieBanner"),n=e.querySelector("#changeLegalTextLang"),o=e.querySelector("#langNameSpan");n&&n.addEventListener("change",function(e){var n=this.selectedOptions[0];o&&(o.innerHTML=n.text),MG_Utils.setCookie("legalTextLangId",parseInt(n.value)),window.location.reload()}.bind(n))}function expandCustomizeDetail(e){var o=null!=e.parentElement?e.parentElement:"",e=o?o.clientHeight:0,n=o?o.querySelector(".title span"):"",t=document.querySelectorAll(".customizeMainContent .expandableSection.expanded"),i=!1,a=document.getElementById("cookieBannerWrapper");o&&(Array.prototype.slice.call(t).forEach(function(e){var n=e.querySelector(".title span");o==e&&(i=!0),MG_Utils.removeClass(e,"expanded"),n&&(MG_Utils.removeClass(n,"ph-icon-chevron-up"),MG_Utils.addClass(n,"ph-icon-chevron-down"))}),i||(MG_Utils.toggleClass(o,"expanded"),n&&MG_Utils.hasClass(o,"expanded")&&(MG_Utils.addClass(n,"ph-icon-chevron-up"),MG_Utils.removeClass(n,"ph-icon-chevron-down"))),t=o.clientHeight-e,document.querySelector(".customizeMainContent .expandableSection.expanded")&&a?(initialCookieBannerHeight=initialCookieBannerHeight||a.clientHeight,a.style.height=initialCookieBannerHeight+Math.abs(t)+"px",MG_Utils.addClass(a,"optionExpanded")):!document.querySelector(".customizeMainContent .expandableSection.expanded")&&a&&(MG_Utils.removeClass(a,"optionExpanded"),a.style.removeProperty("height")))}function expandCustomizedOptions(e,n,o){var t,i=document.getElementById("cookieBannerContent"),a=document.getElementById("cookieBannerWrapper"),r=(a.classList.add("extended"),e.classList.add("saveChangesBtn"),n.classList.add("rightAlignBtn"),o.classList.add("rightAlignBtn"),e.textContent=("undefined"!=typeof Banner_Text&&Banner_Text.thirdCTASaveText?Banner_Text:cbTexts).thirdCTASaveText,"undefined"!=typeof customizeCookiesTemplate&&(i&&(i.innerHTML=customizeCookiesTemplate),t=document.querySelector(".backToscrollableContent"))&&t.addEventListener("click",function(){this&&this.classList.contains("backToscrollableContent")&&(e.textContent=("undefined"!=typeof Banner_Text&&Banner_Text.thirdCTA?Banner_Text:cbTexts).thirdCTA,e.classList.remove("saveChangesBtn"),e.dataset.event="cookie_banner",e.dataset.label="customize",e.classList.add("gtm-event-cookie-banner"),n.classList.remove("rightAlignBtn"),o.classList.remove("rightAlignBtn"),a.classList.remove("extended","optionExpanded"),a.style.removeProperty("height"),"undefined"!=typeof biggerCookieBannerTemplate&&(i.innerHTML=biggerCookieBannerTemplate,bannerChangeLanguage()),addClogCookieBanner(currentDomain,"customize-back",originPart,originUrl))}),document.getElementById("functionalCookies")),l=document.getElementById("analyticsCookies"),c=document.getElementById("advertisingCookies");r&&(r.checked=!![3,10,26,42].includes(Number(CookieHelper.getCurrentConsent()))),l&&(l.checked=!![3,18,26,50].includes(Number(CookieHelper.getCurrentConsent()))),c&&(c.checked=!![3,34,42,50].includes(Number(CookieHelper.getCurrentConsent()))),r&&r.addEventListener("change",function(){var e=r.checked?"functional-cookies-enabled":"functional-cookies-disabled";addClogCookieBanner(currentDomain,e,originPart,originUrl)}),l&&l.addEventListener("change",function(){var e=l.checked?"analytics-cookies-enabled":"analytics-cookies-disabled";addClogCookieBanner(currentDomain,e,originPart,originUrl)}),c&&c.addEventListener("change",function(){var e=c.checked?"target-adv-cookies-enabled":"target-adv-cookies-disabled";addClogCookieBanner(currentDomain,e,originPart,originUrl)}),addClogCookieBanner(currentDomain,"customize-cookies",originPart,originUrl),initialCookieBannerHeight=a.clientHeight}function showPrivacyPolicy(e){var n=document.querySelector(".scrollableBannerContent"),o=document.getElementById("privacyPolicyContent"),t=document.getElementById("cookieBannerWrapper"),i="undefined"!=typeof isPlatformMobile&&isPlatformMobile?180:158,e=e?e.querySelector("span"):"";o&&MG_Utils.hasClass(o,"displayNone")?(n&&t&&(t.classList.add("extended"),n.style.height=t.clientHeight-i+"px",MG_Utils.addClass(n,"scrollEnabled"),e)&&(MG_Utils.addClass(e,"ph-icon-chevron-up"),MG_Utils.removeClass(e,"ph-icon-chevron-down")),MG_Utils.removeClass(o,"displayNone"),setTimeout(function(){o.scrollIntoView({behavior:"smooth"})},0)):o&&(n&&(n.style.height="auto"),n&&MG_Utils.removeClass(n,"scrollEnabled"),t&&t.classList.remove("extended"),MG_Utils.addClass(o,"displayNone"),e)&&(MG_Utils.removeClass(e,"ph-icon-chevron-up"),MG_Utils.addClass(e,"ph-icon-chevron-down"))}function showShortCookieBanner(){var n,o,e,t,i,a;isGlobalCookieBanner||((n=document.getElementById("cookieBanner"))&&n.classList.add("cbShort"),(o=document.createElement("p")).innerHTML=("undefined"!=typeof Banner_Text&&Banner_Text.shortBannerText?Banner_Text:cbTexts).shortBannerText,e=document.createElement("span"),t=("undefined"!=typeof Banner_Text&&Banner_Text.primaryCTA?Banner_Text:cbTexts).primaryCTA,i="undefined"!=typeof isPlatformMobile&&isPlatformMobile,e.classList.add("cbPrimaryCTA","cbSpan","gtm-event-cookie-banner"),i&&e.classList.add("cbPrimaryCTA","mobileLink"),e.textContent=" '"+t+"' ",e.dataset.event="cookie_banner",e.dataset.label="essential_accept_all",e.addEventListener("click",function(){document.cookie=cbCookieName+"=3; expires="+cbExpiration+"; domain="+cbDomainName+";secure;path=/",document.cookie=cbCookieBannerStateName+"=0;expires=Thu, 01 Jan 1970 00:00:01 GMT",cookieConsentUserChoice("granted"),n.className="",n.innerHTML="",addClogCookieBanner(currentDomain,"accept-all",originPart,originUrl),logUserConsentCookie(3),mainInterval.unsubscribe(cookieChangeCallbackName)}),(a=document.createElement("button")).classList.add("cbCloseButton","ph-icon-cross"),a.setAttribute("title","close"),a.addEventListener("click",function(){addClogCookieBanner(currentDomain,"consent-modal-close",originPart,originUrl,"button-close"),document.cookie=cbCookieBannerStateName+"=1; expires="+cbExpiration+"; domain="+cbDomainName+";secure;path=/",cookieConsentUserChoice("denied"),n.className="",n.innerHTML=""}),o.appendChild(e),document.body?(addStyling(),n&&n.appendChild(o),n&&n.appendChild(a)):window.addEventListener("DOMContentLoaded",function(e){addStyling(),n&&n.appendChild(o),n&&n.appendChild(a)}),"undefined"!=typeof isPremiumDomainBanner&&isPremiumDomainBanner&&"undefined"!=typeof isPlatformMobile&&isPlatformMobile&&adjustShortBannerPosition(),clearNonEssentialCookies(),CookieHelper.deleteNonEssentialsLocalStorageKeys(),initializedLangSelector=!1)}function adjustShortBannerPosition(){var n=0,o=document.getElementById("cookieBanner");"undefined"!=typeof MG_Utils&&document.addEventListener("scroll",MG_Utils.debounce(function(){var e=window.pageYOffset||document.documentElement.scrollTop;n<e?o&&(o.style.bottom="0"):o&&(o.style.bottom="70px"),n=e<=0?0:e},!1))}function logGTMEvent(e){var n="";e&&(n=e.analytics&&e.advertising&&e.functional?"customize_func_an_ad":e.analytics&&e.advertising?"customize_an_ad":e.analytics&&e.functional?"customize_func_an":e.advertising&&e.functional?"customize_func_ad":e.analytics?"customize_an":e.advertising?"customize_ad":e.functional?"customize_func":"customize_none",window.dataLayer.push({event:"cookie_banner",event_label:n}))}function logUserConsentCookie(e){"undefined"!=typeof isLoggedInUser&&isLoggedInUser?"undefined"!=typeof MG_Utils&&"undefined"!=typeof logCookieConsentUrl&&"undefined"!=typeof token&&MG_Utils.ajaxCall({url:logCookieConsentUrl,type:"GET",headers:"undefined"!=typeof liuIdOrNull&&liuIdOrNull?{__m:liuIdOrNull}:{},data:{token:token,cookie_selection:e,site_id:1}}):isPremiumDomainBanner&&MG_Utils.ajaxCall({url:logCookieConsentUrlPremium,type:"GET",data:{cookie_selection:e}})}function cookieConsentUserChoice(e="denied"){return dispatchEvent(new CustomEvent("cookieConsentUpdated",{detail:{consent:CookieHelper.getCurrentConsent()}})),"undefined"!=typeof gtag&&gtag("consent","update",{ad_storage:e,analytics_storage:e}),e}function triggerGA4Event(e,n,o,t){e={event:e};o&&(e.origin=o),n&&(e.origin_url=n),t&&(e.origin_item_id=t),window.dataLayer.push(e)}function addClogCookieBanner(e,n,o,t,i){var a=i?"&origin_item_id="+i:"",r=t?"&origin_url="+encodeURIComponent(t):"",l=t?"&origin="+o:"",c=setInterval(function(){"undefined"!=typeof MG_Utils&&(MG_Utils.ajaxCall({url:e+"/_i?type=event&event="+n+l+r+a,type:"POST",crossDomain:"undefined"!=typeof window&&window.telemetryHostname,headers:"undefined"!=typeof liuIdOrNull&&liuIdOrNull?{__m:liuIdOrNull}:{}}),triggerGA4Event(n,t,o,i),clearInterval(c))},200)}function addStyling(){var n;document.getElementById("cookieBannerStyle")||((n=document.createElement("style")).id="cookieBannerStyle",n.innerHTML='#cookieBanner.cbShort {background-color: rgba(15, 15, 15, 0.95);border-radius: 5px;padding: 1em;width: 90%;position: fixed;bottom: 0;margin: 5px auto;color: #c6c6c6;z-index: 100;text-align: center;left: 50%;transform: translate(-50%, 0);font-size: 14px;}#cookieBanner.withOverlay {position: fixed;width: 100%;height: 100%;top: 0;left: 0;right: 0;bottom: 0;background-color: transparent;z-index: 200;}#cookieBanner.hidden{display:none;}#cookieBannerWrapper {background-color: rgba(15, 15, 15, 0.95);border-radius: 10px 10px 0 0;padding: 1.5em;width: 100%;position: fixed;bottom: 0;margin: 5px auto 0;color: #c6c6c6;z-index: 100;text-align: center;left: 50%;transform: translate(-50%, 0);font-size: 14px;box-sizing: border-box;}#cookieBannerWrapper.extended:not(.mobileCCBanner) {height: 648px;}#cookieBannerWrapper.mobileCCBanner.extended {height: 546px;overflow-y: scroll;}@media screen and (min-width: 1000px) and (orientation: landscape) {#cookieBannerWrapper.mobileCCBanner.extended {height: 466px;}}#cookieBannerContent {width: 770px;margin: auto;}#cookieBannerContent.cookieBannerV1 {width: 668px;}.scrollableBannerContent {margin-bottom: 20px;transition: height 0.5s ease;height:auto;overflow-y: hidden;}.scrollEnabled {overflow-y: scroll;}.scrollEnabled::-webkit-scrollbar {width: 6px;}.scrollEnabled::-webkit-scrollbar-track {-webkit-box-shadow: inset 0 0 6px #222;border-radius: 10px;}.scrollEnabled::-webkit-scrollbar-thumb {border-radius: 10px;background: #2F2F2F;}.phLogo {width: 106px;margin: 0 auto 15px;}#cookieBanner h1,#cookieBanner .heading1,#cookieBanner h2 {font-size: 26px;line-height: 32px;font-weight: bold;color: #fff;margin-bottom: 10px;}#cookieBanner .heading1, #cookieBanner h2 {background-color: initial;line-height: initial;padding: 0;text-transform: capitalize;}#cookieBanner h3 {color: #fff;margin-bottom: 15px;background: none;text-transform: none;font-size: 21px;font-weight: 400;padding: 0;}#cookieBanner p, #cookieBanner ul {color: #fff;font-size: 14px;line-height: 20px;text-align: left;}#cookieBanner .expandableSection {display: flex;justify-content: space-between;flex-wrap: wrap;}#cookieBanner .expandableSection .title span {color: #FF9000;margin-right: 15px;pointer-events: none;}#cookieBanner .expandableSection p {display: -webkit-box;-webkit-line-clamp: 1;-webkit-box-orient: vertical;overflow: hidden;text-overflow: ellipsis;max-height: 82px;}#cookieBanner .expandableSection.expanded p {-webkit-line-clamp: initial;overflow-y: scroll;}#cookieBanner .expandableSection.expanded p::-webkit-scrollbar {width: 6px;}#cookieBanner .expandableSection.expanded p::-webkit-scrollbar-track {-webkit-box-shadow: inset 0 0 6px #222;border-radius: 10px;}#cookieBanner .expandableSection.expanded p::-webkit-scrollbar-thumb {border-radius: 10px;background: #2F2F2F;}#cookieBanner .policyItalic {font-style: italic;}#cookieBanner .policyBold {font-weight: bold;}#cookieBanner ul li {list-style-position: inside;list-style-type: disc;}#cookieBanner a {color: #FF9000;cursor: pointer;}#cookieBanner .learnMoreContent {color: white;text-align: left;}#cookieBanner .learnMoreContent a {color: #FF9000;text-decoration: none;}#cookieBanner .learnMoreContent a:hover {text-decoration: none;}.showPrivacyPolicy {font-weight: bold;font-size: 16px;line-height: 22px;text-align: left;display: grid;grid-template-columns: 1fr auto;padding-right: 6px;}.showPrivacyPolicy:hover {text-decoration: none;}span.ph-icon-chevron-down, span.ph-icon-chevron-up {font-size: 12px;line-height: 22px;pointer-events: none;}#privacyPolicyContent {margin-top: 15px;text-align: left;}.cbButton {margin: 5px;min-width: 250px;cursor: pointer;background-color: black;color: white;border: 2px solid #FF9000;border-radius: 5px;padding: 0.72em 1em;box-sizing: border-box;text-transform: capitalize;font-size: 14px;font-weight: bold;}.cbButton:hover,.cbButton.focus,.cbButton.saveChangesBtn {color: black;background-color: #FF9000;}#cookieBanner.cbShort p {font-size: 13px;margin: 0;text-align: center;color: #c6c6c6;}.cbShort .cbSpan {cursor: pointer;white-space: nowrap;text-transform: capitalize;margin-left: 4px;}.cbShort .cbSpan:hover, .cbShort .cbSpan.mobileLink {color: #FF9000;}.cbCloseButton {position: absolute;top: -10px;right: -9px;color: #969696;cursor: pointer;border: none;font-size: 12px;width: 26px;height: 26px;background: #333;border-radius: 13px;padding: 0;}.scrollableBannerContent table {table-layout: fixed;margin: 10px 0;display: block;overflow-x: auto;border-collapse: collapse;color: #fff;text-align: center;}.scrollableBannerContent table td,.scrollableBannerContent table th {border: 1px solid #fff;padding: 8px;vertical-align: top;}.scrollableBannerContent table td i,.scrollableBannerContent table th i {display: inline;}@media screen and (min-width: 401px) and (max-width: 800px) {.cbShort .cbButton {display: block;clear: both;}}@media screen and (max-width: 800px) {#cookieBannerContent {width: 100%;}}.customizeCookiesWrapper {text-align: left;}.backToscrollableContent {display: flex;cursor: pointer;color: #FF9000;font-weight: bold;margin-bottom: 40px;align-items: center;}.backToscrollableContent .ph-icon-chevron-left {position: relative;margin-right: 10px;margin-left: 10px;font-size: 0.7em;pointer-events: none;}.customizeMainContent {display: flex;justify-content: space-between;flex-wrap: wrap;align-items: center;}.customizeMainContent .column {width: 100%;}.customizeMainContent .title {font-size: 16px;font-weight: bold;color: #fff;cursor: pointer;}.customizeMainContent p {margin-top: 12px;margin-bottom: 40px;width: 100%;}.customizeMainContent span {color: #fff;}.customizeToggleSwitch {position: relative;display: inline-block;width: 46px;height: 28px;}.customizeToggleSwitch input {opacity: 0;width: 0;height: 0;}.customizeToggleSwitch .slider {position: absolute;cursor: pointer;top: 0;left: 0;right: 0;bottom: 0;background-color: #c6c6c6;-webkit-transition: .4s;transition: .4s;}.customizeToggleSwitch .slider:before {position: absolute;content: "";height: 24px;width: 24px;left: 3px;bottom: 2px;background-color: #fff;-webkit-transition: .4s;transition: .4s;}.customizeToggleSwitch input:checked + .slider {background-color: #FF9000;}.customizeToggleSwitch input:focus + .slider {box-shadow: 0 0 1px #FF9000;}.customizeToggleSwitch input:checked + .slider:before {-webkit-transform: translateX(16px);-ms-transform: translateX(16px);transform: translateX(16px);}.customizeToggleSwitch .slider.round {border-radius: 34px;}.customizeToggleSwitch .slider.round:before {border-radius: 50%;}.customizeToggleSwitch span {position: absolute;display: flex;flex-direction: column;justify-content: center;}.customizeToggleSwitch span::before,.customizeToggleSwitch span::after {position: absolute;content: "";width: 17px;height: 2px;top: 13px;left: 6px;background: #C6C6C6;-webkit-transition: left .5s;transition: left .5s;}.customizeToggleSwitch span::before {transform: rotate(45deg);}.customizeToggleSwitch span::after {transform: rotate(-45deg);}.customizeToggleSwitch input[type="checkbox"]:checked ~ div span {-webkit-transform: translateX(16px);-ms-transform: translateX(16px);transform: translateX(16px);}.customizeToggleSwitch input[type="checkbox"]:checked~ div span::before {content: "";background-color: transparent;position: relative;top: 4px;left: 11px;width: 6px;height: 15px;border-bottom: 2px solid #FF9000;border-right: 2px solid #FF9000;transform: rotate(45deg);}.customizeToggleSwitch input[type="checkbox"]:checked~ div.mobileBtn span::before {width: 7px;height: 16px;}.customizeToggleSwitch input[type="checkbox"]:checked ~ div span::after {content: "";background-color: transparent;}@media (any-pointer: coarse) {.customizeCookiesContent .phLogo {display: none;}.customizeCookiesContent .backToscrollableContent {margin-bottom: 12px;}.customizeMainContent p {margin-top: 12px;margin-bottom: 12px;}}@media (any-pointer: coarse) and (orientation: portrait) {.cbButton {width: 100%;margin-left: 0;margin-right: 0;}#cookieBannerContent {width: 100%;}}@media (any-pointer: coarse) and (max-width: 1000px) and (orientation: landscape) {#cookieBannerWrapper.mobileCCBanner.extended {height: 466px;}}@media (any-pointer: coarse) and (max-width: 900px) and (orientation: landscape) {#cookieBannerWrapper.mobileCCBanner.extended {height: 482px;}.customizeMainContent {display: flex;flex-direction: row;flex-wrap: wrap;width: 100%;}.customizeMainContent .column {display: flex;flex-direction: column;flex-basis: 100%;flex: 1;height: 35vh;}.customizeFirstColumn,.customizeSecondColumn {width: 100%;}.customizeFirstColumn {border-right: 1px solid #767676;padding-right: 8px;}.customizeSecondColumn {padding-left: 16px;}.rightAlignBtn,.saveChangesBtn {display: flex;margin-left: auto;justify-content: center;margin-right: 0;width: 48%;}.customizeCookiesContent .backToscrollableContent {position: absolute;top: 25px;}#cookieBanner .heading1:not(.center), #cookieBanner h2:not(.center) {position: relative;text-align: left;left: 90px;}}@media (any-pointer: coarse) and (max-width: 845px) and (orientation: landscape) {#cookieBannerWrapper.mobileCCBanner.extended {height: 359px;}}@media (any-pointer: coarse) and (max-width: 799px) and (orientation: landscape) {#cookieBannerWrapper.mobileCCBanner.extended {height: 348px;}}@media (any-pointer: coarse) and (max-width: 739px) and (orientation: landscape) {#cookieBannerWrapper.mobileCCBanner.extended {height: 367px;}}#cookieBanner #changeLanguageWrapper {display: block;padding-top: 5px;padding-bottom: 25px;}#cookieBanner #changeLanguageWrapper.displayNone {display: none;}#cookieBanner #changeLanguageWrapper label {background-color:  #212121;position: relative;width: 100%;height: auto;min-height: 52px;max-width: 414px;line-height: 26px;color: #C6C6C6;display: block;padding: 13px 0 13px 17px;font-size: 0.75rem;box-sizing: border-box;border-radius: 10px;float: none;text-align: left;margin: 0 0 10px 0;}#cookieBanner #changeLanguageWrapper label select {bottom: 0;left: 0;margin: auto;position: absolute;right: 0;top: 0;width: 95%;opacity: 0;cursor: pointer;}#cookieBanner #changeLanguageWrapper label span {font-weight: bold;}#cookieBanner #changeLanguageWrapper label.active {background-color: #212121;}#cookieBanner #changeLanguageWrapper label:hover {text-decoration: none;}#cookieBanner #changeLanguageWrapper .iconBox {width: 30px;display: inline-block;margin-right: 6px;position: relative;min-height: 10px;vertical-align: middle;}#cookieBanner #changeLanguageWrapper .iconBox i {position: absolute;top: 50%;left: 50%;transform: translate(-50%,-50%);-webkit-transform: translate(-50%,-50%);color: #fff;font-size: 19px;line-height: 24px;}#cookieBanner #changeLanguageWrapper .ph-icon-arrow-drop-down,#cookieBanner #changeLanguageWrapper .ph-icon-arrow-drop-up {color: #fff;font-size: 10px;padding: 10px 18px;float: right;}#cookieBanner #changeLanguageWrapper .disclaimer {display: block;font-size: 10px;}#globalCookieBanner {position: fixed;z-index: 1000;right: 0;bottom: 0;left: 0;padding: 20px;pointer-events: none;}#globalCookieBanner.hidden{display:none;}#globalCookieBanner .globalCookieBanner {display: block;box-sizing: border-box;max-width: 500px;margin: 0 auto;padding: 1.5em;border-radius: 10px;background-color: rgba(33,33,33,0.98);color: #c6c6c6;font-size: 14px;line-height: 1.4;letter-spacing: 0.15px;pointer-events: auto;}#globalCookieBanner .globalCookieBanner__wrapper {position: relative;}#globalCookieBanner .globalCookieBanner__icon {position: absolute;left: 4px;top: 4px;display: block;width: 35px;height: 34px;background-repeat: no-repeat;cursor: auto;}#globalCookieBanner .globalCookieBanner__content {position: relative;padding: 0 34px 0 50px;}#globalCookieBanner .globalCookieBanner__content a{color: #FF9000;}#globalCookieBanner .globalCookieBanner__close {position: absolute;right: -2px;top: -2px;border: none;background: none;color: white;font-size: 12px;line-height: 1;padding: 6px;}#globalCookieBanner button {cursor: pointer;}#globalCookieBanner .globalCookieBanner__buttons {display: grid;grid-template-columns: 1fr 1fr;gap: 10px;margin-top: 10px;}#globalCookieBanner .globalCookieBanner__buttons button {padding: 10px 12px;border: 1px solid white;border-radius: 3px;background: transparent;color: white;font-size: 14px;font-weight: bold;line-height: 1.4;letter-spacing: 0.15px;}#globalCookieBanner .globalCookieBanner__buttons button:hover, #globalCookieBanner .globalCookieBanner__buttons button:focus {border-color: #FF9000;}@media screen and (min-width: 768px) {#globalCookieBanner .globalCookieBanner__wrapper {padding-left: 60px;}#globalCookieBanner .globalCookieBanner__content {padding-left: 0;}}@media screen and (max-width: 410px) {#globalCookieBanner .globalCookieBanner {padding: 18px 20px;}#globalCookieBanner .globalCookieBanner__buttons button {font-size: 12px;padding: 10px;}}',document.head?document.head.appendChild(n):window.addEventListener("DOMContentLoaded",function(e){document.head.appendChild(n)}))}document.addEventListener("DOMContentLoaded",function(){var e;shouldLogGTMImpression&&(window.dataLayer.push({event:"cookie_banner",event_label:"impression"}),shouldLogGTMImpression=!1),isGlobalCookieBanner&&((e=document.createElement("div")).id="globalCookieBanner",e.className="hidden",document.body.prepend(e),globalCookieBanner=new GlobalCookieBanner(e))}),window.addEventListener("DOMContentLoaded",function(e){var n=document.querySelector(".manageCookiesBtn");n&&n.addEventListener("click",function(){addClogCookieBanner(currentDomain,"consent-modal-open",originPart,originUrl)})});var cookieChangeCallback,globalCookieBanner,pollingInterval=1e3,cookieChangeCallbackName="cookieBanner_cookiesChanged";function listenCookieChange(n,e){var o;e=e||pollingInterval,"3"==cbCookie||isGlobalCookieBanner&&(""==cbCookie||"1"==cbCookie)||(o=document.cookie,cookieChangeCallback=function(){var e=document.cookie;if(e!==o)try{n({oldValue:o,newValue:e})}finally{o=e}},mainInterval.subscribe(cookieChangeCallbackName,cookieChangeCallback,e))}function clearNonEssentialCookies(){CookieHelper.deleteNonEssentialCookies(document.cookie.split("; ").map(function(e){return e.split("=")[0]}))}function GlobalCookieBanner(e){var a=this;if(GlobalCookieBanner._instance)throw new Error("Singleton classes can't be instantiated more than once.");(GlobalCookieBanner._instance=this).element=e,this.init=function(){a.buttons.accept.addEventListener("click",function(){return a.acceptAllCookies()}),a.buttons.customize.addEventListener("click",function(){return a.customizeCookies()}),a.buttons.close.addEventListener("click",function(){return a.acceptAllCookies()});var e=CookieHelper.getCurrentConsent();""===e||"0"===e?(document.cookie=cbCookieName+"=1; expires="+cbExpiration+"; domain="+cbDomainName+"; secure;path=/",a.showBanner()):"1"===e?a.showBanner():"3"!==e&&"1"!==cbCookieBannerState&&a.showShortCookieBanner(),document.cookie=cbCookieBannerStateName+"=0;expires=Thu, 01 Jan 1970 00:00:01 GMT",document.cookie=cbCookieBannerStateName+"=0;expires=Thu, 01 Jan 1970 00:00:01 GMT;domain="+cbDomainName},this.showBanner=function(){a.regularCookieBanner&&a.regularCookieBanner.classList.add("hidden"),a.element.classList.remove("hidden"),a.handleClogTracking([currentDomain,"cookie-banner-impression-noneu",originPart,originUrl])},this.acceptAllCookies=function(){document.cookie=cbCookieName+"=3; expires="+cbExpiration+";domain="+cbDomainName+";secure;path=/",a.handleClogTracking([currentDomain,"cookie-banner-ok-noneu",originPart,originUrl]),logUserConsentCookie(3),"undefined"!=typeof mainInterval&&cookieChangeCallbackName&&mainInterval.unsubscribe(cookieChangeCallbackName),a.element.classList.add("hidden")},this.customizeCookies=function(){a.handleClogTracking([currentDomain,"customize-cookie-noneu",originPart,originUrl]),a.element.classList.add("hidden"),a.regularCookieBanner.hasChildNodes()&&!a.regularCookieBanner.classList.contains("cbShort")||a.showCustomizeCookies(),a.regularCookieBanner.classList.remove("hidden")},this.showCustomizeCookies=function(){a.regularCookieBanner||(a.regularCookieBanner=document.createElement("div"),a.regularCookieBanner.id="cookieBanner",document.body&&document.body.appendChild(a.regularCookieBanner)),a.regularCookieBanner.classList.add("withOverlay"),a.regularCookieBanner.classList.remove("cbShort"),a.regularCookieBanner.innerHTML="";var n=document.createElement("div"),e=document.createElement("div"),o=(n.id="cookieBannerWrapper",e.id="cookieBannerContent","undefined"!=typeof isPlatformMobile&&isPlatformMobile&&n.classList.add("mobileCCBanner"),document.createElement("button")),t=document.createElement("button"),i=document.createElement("button"),o=(o.classList.add("cbPrimaryCTA","cbButton","rightAlignBtn"),o.textContent=("undefined"!=typeof Banner_Text&&Banner_Text.primaryCTA?Banner_Text:cbTexts).primaryCTA,o.addEventListener("click",function(){document.cookie=cbCookieName+"=3; expires="+cbExpiration+";domain="+cbDomainName+";secure;path=/",a.clearRegularCookieBanner(),a.handleClogTracking([currentDomain,"cookie-pref-accept-all-noneu",originPart,originUrl]),logUserConsentCookie(3),mainInterval.unsubscribe(cookieChangeCallbackName)}),t.classList.add("cbSecondaryCTA","cbButton","rightAlignBtn"),t.textContent=("undefined"!=typeof Banner_Text&&Banner_Text.secondaryCTA?Banner_Text:cbTexts).secondaryCTA,t.addEventListener("click",function(){document.cookie=cbCookieName+"=2; expires="+cbExpiration+";domain="+cbDomainName+";secure;path=/",a.clearRegularCookieBanner(),void 0!==CookieHelper&&(CookieHelper.deleteNonEssentialCookies(document.cookie.split("; ").map(function(e){return e.split("=")[0]})),CookieHelper.deleteNonEssentialsLocalStorageKeys()),a.handleClogTracking([currentDomain,"cookie-pref-accept-essential-noneu",originPart,originUrl]),logUserConsentCookie(2),location.reload()}),i.classList.add("cbThirdCTA","cbButton","saveChangesBtn"),i.textContent=("undefined"!=typeof Banner_Text&&Banner_Text.thirdCTASaveText?Banner_Text:cbTexts).thirdCTASaveText,i.addEventListener("click",function(){var e={functional:document.getElementById("functionalCookies"),analytics:document.getElementById("analyticsCookies"),advertising:document.getElementById("advertisingCookies")},e={functional:e.functional.checked?Number(e.functional.value):0,analytics:e.analytics.checked?Number(e.analytics.value):0,advertising:e.advertising.checked?Number(e.advertising.value):0},n=e.functional&&e.analytics&&e.advertising?3:2+e.functional+e.analytics+e.advertising;document.cookie=cbCookieName+"="+n+"; expires="+cbExpiration+";domain="+cbDomainName+";secure;path=/",a.logCustomizedCookiesSelection(e),2===n?(a.clearRegularCookieBanner(),void 0!==CookieHelper&&(CookieHelper.deleteNonEssentialCookies(document.cookie.split("; ").map(function(e){return e.split("=")[0]})),CookieHelper.deleteNonEssentialsLocalStorageKeys())):a.clearRegularCookieBanner(),location.reload(),logUserConsentCookie(n)}),n.append(e,o,t,i),a.regularCookieBanner.appendChild(n),document.addEventListener("click",function(e){var n=e?e.target:null;n&&MG_Utils.hasClass(n,"expandableTitle")&&(e.stopImmediatePropagation(),expandCustomizeDetail(n))}),window.addEventListener("resize",function(e){n&&(n.style.removeProperty("height"),initialCookieBannerHeight=n.clientHeight)}),n.classList.add("extended"),e.innerHTML=customizeCookiesTemplate,document.querySelector(".backToscrollableContent")),t="1"!==CookieHelper.getCurrentConsent()?CookieHelper.getCurrentConsent():cbConsent,i=(o&&o.addEventListener("click",function(){a.regularCookieBanner.classList.add("hidden"),a.showBanner()}),{functional:document.getElementById("functionalCookies"),analytics:document.getElementById("analyticsCookies"),advertising:document.getElementById("advertisingCookies")});i.functional&&(i.functional.checked=!![3,10,26,42].includes(Number(t))),i.analytics&&(i.analytics.checked=!![3,18,26,50].includes(Number(t))),i.advertising&&(i.advertising.checked=!![3,34,42,50].includes(Number(t))),initialCookieBannerHeight=n.clientHeight},this.showShortCookieBanner=function(){a.regularCookieBanner||(a.regularCookieBanner=document.createElement("div"),a.regularCookieBanner.id="cookieBanner",document.body&&document.body.appendChild(a.regularCookieBanner)),a.regularCookieBanner.classList.add("cbShort"),a.regularCookieBanner.innerHTML=shortCookieBannerContent;var e="undefined"!=typeof isPlatformMobile&&isPlatformMobile,n=a.regularCookieBanner.querySelector(".cbPrimaryCTA"),o=a.regularCookieBanner.querySelector(".cbCloseButton");e&&n.classList.add("mobileLink"),n.addEventListener("click",function(){document.cookie=cbCookieName+"=3; expires="+cbExpiration+"; domain="+cbDomainName+";secure;path=/",document.cookie=cbCookieBannerStateName+"=0;expires=Thu, 01 Jan 1970 00:00:01 GMT",a.handleClogTracking([currentDomain,"cookie-banner-essential-to-all-noneu",originPart,originUrl]),logUserConsentCookie(3),mainInterval.unsubscribe(cookieChangeCallbackName),a.clearRegularCookieBanner()}),o.addEventListener("click",function(){document.cookie=cbCookieBannerStateName+"=1; expires="+cbExpiration+"; domain="+cbDomainName+";secure;path=/",a.clearRegularCookieBanner()}),"undefined"!=typeof isPremiumDomainBanner&&isPremiumDomainBanner&&"undefined"!=typeof isPlatformMobile&&isPlatformMobile&&adjustShortBannerPosition(),void 0!==CookieHelper&&(CookieHelper.deleteNonEssentialCookies(document.cookie.split("; ").map(function(e){return e.split("=")[0]})),CookieHelper.deleteNonEssentialsLocalStorageKeys())},this.clearRegularCookieBanner=function(){a.regularCookieBanner.innerHTML="",a.regularCookieBanner.className="hidden"},this.logCustomizedCookiesSelection=function(e){var n="";e&&(e.analytics&&e.advertising&&e.functional?n="cookie-pref-accept-all-noneu":e.analytics||e.advertising||e.functional?(e.functional&&(n+="functional-"),e.analytics&&(n+="analytics-"),e.advertising&&(n+="advertising-"),n+="save-noneu"):n="none-save-noneu",a.handleClogTracking([currentDomain,n,originPart,originUrl]))},this.handleClogTracking=function(e){var n;"function"==typeof userClogTracking?userClogTracking.apply(userClogTracking,e):n=setInterval(function(){"function"==typeof userClogTracking&&(userClogTracking.apply(userClogTracking,e),clearInterval(n))},200)},isGlobalCookieBanner&&globalCookieBannerContent&&this.element&&(this.element.innerHTML=globalCookieBannerContent,this.buttons={close:this.element.querySelector(".js-closeGlobalBanner"),customize:this.element.querySelector(".js-customizeGlobalCookies"),accept:this.element.querySelector(".js-acceptGlobalCookies")},this.regularCookieBanner=document.getElementById("cookieBanner"),addStyling(),this.init())}listenCookieChange(function(e){var n=CookieHelper.listCookiesArrayFromString(e.newValue),o=CookieHelper.listCookiesArrayFromString(e.oldValue);n.filter(function(e){return!o.includes(e)});setTimeout(function(){CookieHelper.deleteNonEssentialCookies(n)},1e3)},pollingInterval);</script>
    
                    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
                    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
                j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
                'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
            })(window,document,'script','dataLayer','GTM-5M97TMJ');</script>
            
    
    <script src="https://ei.phncdn.com/www-static/js/lib/utils/mg_utils-2.0.0.js?cache=2026052109"></script>

        <script>
    window.telemetryHostname = "https:\/\/i.pornhub.com";

    var amateurUserFlag                     = 0,
        changing_thumbs                     = [],
        disableFlipbook                     = 'false',
        largeVersionMinimumScreenSize       = 1900,
        isLarge                         = false,
        screensize                      = window.screen.width,
        isLogged                        = 0,
        pageKeyStat                     = "sfw_homepage",
        platformPcSet                   = 1,
        focusSearchInput                = 0, // Variable used in Header.js, related to search & autocomplete
        isGay                           = "0",
        isLesbianContentEnabled          = 1,
        searchUrlVideo                  = "/video/search?search=",
        searchUrlPhoto                  = "/albums/female-straight-uncategorized?search=",
        searchUrlMember                 = "/user/search?gender=0&username=",
        searchUrlPornstar               = "/pornstars/search?search=",
        searchUrlGifs                   = "/gifs/search?search=",
        searchUrlCam                    = '/live/live?k=',
        messageViewAll                  = "/chat/index", // variables used in "phub.js", related to notification
        notifViewAll                    = "/notifications",
        emailNotConfirmed               = "Email not confirmed yet!",
        accountDisabled                 = "Account disabled. Please try again later.",
        loginError                      = "Invalid username/password!",
        error513                        = "Error 513.",
        error514                        = "Error 514.",
        error515                        = "Error 515.",
        errorNoUsername                 = "Please enter your username below:",
        errorNoPassword                 = "Please enter your password below:",
        adOrientation                   = "straight",
        category                        = "",
        showStreamate                   = "1",         premiumFlag                     = "0",
        phOrientationSegment            = "straight",
        phCountryCode                   = "US",
        playlistJs                      = "https://ei.phncdn.com/www-static/js//playlist/playlist-basic.js?cache=2026052109",
        token                           = "MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8.",
        checkboxTypeCaptcha             = "checkbox",
        scoreTypeCaptcha                = "score",
        hideGoogleSsoIos                = true;
            var playlists       = "",
        watchLaterFull      = "";
        var bannedWordsCheckUrl = "/api/v1/check/has_forbidden_words";
    
            isLarge = true;
    
    var premiumRedirectCookieURL = '//www.pornhub.com/user/premium_redirect_cookie?ajax=1';

    

    function onLoad() {
        var site = 'pornhub';
        if (!window.jQuery) {
            try {
                var a = new XMLHttpRequest();

                a.open("GET", "//www.etahub.com/trackn?app_id=10305&product_name=" + site + "&category=ss&value=1", true);
                a.send();
            } catch(e) {

            }
        }
    }

    var modalTranslationText = {"okButton":"OK","cannotSubscribe":"You cannot subscribe to a private member.","blackWhiteListUrl":"\/utils\/url_status","connectionModal":"Connection Modal","closeModal":"Close Modal"};

        var videoTimeTrackingCondition 	= 0;
    var playlistViewCountCondition 	= 0;
    var reportTimeWatchedUrl = '';

    
        var networkSegement = false;
        var	networkQuery = '@media only screen and (min-width: 1200px) { div.bar_items { width:1115px;} } ';
    
    var timing_appId = 16,
        timing_productId = 2,
        timing_pageType = 'other';
        var page_params = {
        getMenuType: '0',
        jqeuryVersion : '',
        isIE7 : false,
        isIE : ( !!window.ActiveXObject && +( /msie\s(\d+)/i.exec( navigator.userAgent )[1] )) || !!navigator.userAgent.match(/rv:11/) || false,
        loadOnce: false,
        prerollFired: false
    };

    //SET UP TO lazy_load-1.0.1.js
    page_params.lazyLoad = {
        dataSrc : 'src',//data-src attribute in image
        class_name : 'lazy', //Class name to locate the image to lazy load LEAVE THE UNDERSCORE "_"
        dataBkg : 'bkg', //Data attribute to lazy load background image
        classBkg : 'js_lazy_bkg', //Class to locate the tag which need background lazy load
        thumbUrl : 'thumb_url', //Data attribute to lazy load thumbnails in a section
        sections : [] //Array to push the sections to lazy load
    };

    page_params.zoneDetails = {};

        var globalObjUtils = {
        'isXbox' 	: navigator.userAgent.match(/xbox/i) != null,
        'isTablet' 	: 0,
        'isMac'	 : navigator.userAgent.indexOf('Mac OS X') != -1,
        'isSafari'  : (navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1)
    };

        var playerObjList = {};

            var playerScriptUrl = "https://cdn1d-static-shared.phncdn.com/html5player/videoPlayer/es6player/9.0.1/basic-player.min.js";
    
    
    page_params.subdomain = "www";
</script>

<script>
    </script>

    <script src="https://static.trafficjunky.com/ab/ads_test.js"></script>

        <script src="https://ei.phncdn.com/www-static/js/lib/ph-functions.js?cache=2026052109"></script>

        <script type="text/javascript">
        (function(){
            if (typeof checkForGridSupport === 'function') {
                var htmlEl = document.documentElement;
                if (htmlEl) {
                    if (checkForGridSupport()) {
                        MG_Utils.addClass(htmlEl, 'supportsGridLayout');
                    } else {
                        MG_Utils.addClass(htmlEl, 'noGridLayout');
                    }
                }
            }
        })();
    </script>

        <script>    
    page_params.jqueryVersion = 'https://ei.phncdn.com/www-static/js/lib/jquery-3.6.0.min.js';

    var jsFileList = {};

    if (typeof window.performance === 'undefined') {
                (function(n,t){"use strict";function w(){}function u(n,t){if(n){typeof n=="object"&&(n=[].slice.call(n));for(var i=0,r=n.length;i<r;i++)t.call(n,n[i],i)}}function it(n,i){var r=Object.prototype.toString.call(i).slice(8,-1);return i!==t&&i!==null&&r===n}function s(n){return it("Function",n)}function a(n){return it("Array",n)}function et(n){var i=n.split("/"),t=i[i.length-1],r=t.indexOf("?");return r!==-1?t.substring(0,r):t}function f(n){(n=n||w,n._done)||(n(),n._done=1)}function ot(n,t,r,u){var f=typeof n=="object"?n:{test:n,success:!t?!1:a(t)?t:[t],failure:!r?!1:a(r)?r:[r],callback:u||w},e=!!f.test;return e&&!!f.success?(f.success.push(f.callback),i.load.apply(null,f.success)):e||!f.failure?u():(f.failure.push(f.callback),i.load.apply(null,f.failure)),i}function v(n){var t={},i,r;if(typeof n=="object")for(i in n)!n[i]||(t={name:i,url:n[i]});else t={name:et(n),url:n};return(r=c[t.name],r&&r.url===t.url)?r:(c[t.name]=t,t)}function y(n){n=n||c;for(var t in n)if(n.hasOwnProperty(t)&&n[t].state!==l)return!1;return!0}function st(n){n.state=ft;u(n.onpreload,function(n){n.call()})}function ht(n){n.state===t&&(n.state=nt,n.onpreload=[],rt({url:n.url,type:"cache"},function(){st(n)}))}function ct(){var n=arguments,t=n[n.length-1],r=[].slice.call(n,1),f=r[0];return(s(t)||(t=null),a(n[0]))?(n[0].push(t),i.load.apply(null,n[0]),i):(f?(u(r,function(n){s(n)||!n||ht(v(n))}),b(v(n[0]),s(f)?f:function(){i.load.apply(null,r)})):b(v(n[0])),i)}function lt(){var n=arguments,t=n[n.length-1],r={};return(s(t)||(t=null),a(n[0]))?(n[0].push(t),i.load.apply(null,n[0]),i):(u(n,function(n){n!==t&&(n=v(n),r[n.name]=n)}),u(n,function(n){n!==t&&(n=v(n),b(n,function(){y(r)&&f(t)}))}),i)}function b(n,t){if(t=t||w,n.state===l){t();return}if(n.state===tt){i.ready(n.name,t);return}if(n.state===nt){n.onpreload.push(function(){b(n,t)});return}n.state=tt;rt(n,function(){n.state=l;t();u(h[n.name],function(n){f(n)});o&&y()&&u(h.ALL,function(n){f(n)})})}function at(n){n=n||"";var t=n.split("?")[0].split(".");return t[t.length-1].toLowerCase()}function rt(t,i){function e(t){t=t||n.event;u.onload=u.onreadystatechange=u.onerror=null;i()}function o(f){f=f||n.event;(f.type==="load"||/loaded|complete/.test(u.readyState)&&(!r.documentMode||r.documentMode<9))&&(n.clearTimeout(t.errorTimeout),n.clearTimeout(t.cssTimeout),u.onload=u.onreadystatechange=u.onerror=null,i())}function s(){if(t.state!==l&&t.cssRetries<=20){for(var i=0,f=r.styleSheets.length;i<f;i++)if(r.styleSheets[i].href===u.href){o({type:"load"});return}t.cssRetries++;t.cssTimeout=n.setTimeout(s,250)}}var u,h,f;i=i||w;h=at(t.url);h==="css"?(u=r.createElement("link"),u.type="text/"+(t.type||"css"),u.rel="stylesheet",u.href=t.url,t.cssRetries=0,t.cssTimeout=n.setTimeout(s,500)):(u=r.createElement("script"),u.type="text/"+(t.type||"javascript"),u.src=t.url);u.onload=u.onreadystatechange=o;u.onerror=e;u.async=!1;u.defer=!1;t.errorTimeout=n.setTimeout(function(){e({type:"timeout"})},7e3);f=r.head||r.getElementsByTagName("head")[0];f.insertBefore(u,f.lastChild)}function vt(){for(var t,u=r.getElementsByTagName("script"),n=0,f=u.length;n<f;n++)if(t=u[n].getAttribute("data-headjs-load"),!!t){i.load(t);return}}function yt(n,t){var v,p,e;return n===r?(o?f(t):d.push(t),i):(s(n)&&(t=n,n="ALL"),a(n))?(v={},u(n,function(n){v[n]=c[n];i.ready(n,function(){y(v)&&f(t)})}),i):typeof n!="string"||!s(t)?i:(p=c[n],p&&p.state===l||n==="ALL"&&y()&&o)?(f(t),i):(e=h[n],e?e.push(t):e=h[n]=[t],i)}function e(){if(!r.body){n.clearTimeout(i.readyTimeout);i.readyTimeout=n.setTimeout(e,50);return}o||(o=!0,vt(),u(d,function(n){f(n)}))}function k(){r.addEventListener?(r.removeEventListener("DOMContentLoaded",k,!1),e()):r.readyState==="complete"&&(r.detachEvent("onreadystatechange",k),e())}var r=n.document,d=[],h={},c={},ut="async"in r.createElement("script")||"MozAppearance"in r.documentElement.style||n.opera,o,g=n.head_conf&&n.head_conf.head||"head",i=n[g]=n[g]||function(){i.ready.apply(null,arguments)},nt=1,ft=2,tt=3,l=4,p;if(r.readyState==="complete")e();else if(r.addEventListener)r.addEventListener("DOMContentLoaded",k,!1),n.addEventListener("load",e,!1);else{r.attachEvent("onreadystatechange",k);n.attachEvent("onload",e);p=!1;try{p=!n.frameElement&&r.documentElement}catch(wt){}p&&p.doScroll&&function pt(){if(!o){try{p.doScroll("left")}catch(t){n.clearTimeout(i.readyTimeout);i.readyTimeout=n.setTimeout(pt,50);return}e()}}()}i.load=i.js=ut?lt:ct;i.test=ot;i.ready=yt;i.ready(r,function(){y()&&u(h.ALL,function(n){f(n)});i.feature&&i.feature("domloaded",!0)})})(window);
            }
</script>

    <script>
        var dcEl = 'jrvj7';
        var defaultSignUpModal = false;
        var liuIdOrNull = null;
    </script>

    <script>
    /**
     *  LAZY LOAD 2.0.1
     *  This plugin will use IntersectionObserver to lazyload
     *  For browsers do not support IntersectionObserver, it falls back to the old methods in v1.0.1
     *  it will run when javascript kicks in via head_js
     *  for individual images please use "lazy" class name
     *  for background images please use "js_lazy_bkg" class name
     *  make sure elements have the proper data attribute
     *  data-src for images
     *  data-bkg for backgrounds
     **/

    var LazyLoadImage=function(){"use strict";var t=this,e="section",a="image",r="bkg",s="video",i=/^((?!chrome|android).)*safari/i.test(navigator.userAgent);t.init=function(i){if(t.isObserverDisabled=i&&void 0!==i.disableObserver&&i.disableObserver,t.supportsObserver="IntersectionObserver"in window,t.supportsObserver&&!t.isObserverDisabled){var o={root:null,rootMargin:"0px",threshold:[i&&void 0!==i.threshold?i.threshold:0]};t.setObserver(o)}if(t.params=t.params||{},i&&void 0!==i.sections&&void 0!==i.thumbUrl){t.params[e]=t.setParams(i.sections,"src",function(t){return t.getAttribute("data-"+i.thumbUrl)},"#"," li:not(.hidden) img"),t.subscribe(e)}i&&void 0!==i.class_name&&void 0!==i.dataSrc&&(t.params[a]=t.setParams(i.class_name,"src",function(t){return t.getAttribute("data-"+i.dataSrc)},".",""),t.subscribe(a)),i&&void 0!==i.classBkg&&void 0!==i.dataBkg&&(t.params[r]=t.setParams(i.classBkg,"style",function(t){return'url("'+t.getAttribute("data-"+i.dataBkg)+'")'},".",""),t.subscribe(r)),i&&void 0!==i.classVideo&&void 0!==i.dataPoster&&(t.params[s]=t.setParams(i.classVideo,"poster",function(t){return t.getAttribute("data-"+i.dataPoster)},".",""),t.subscribe(s))},t.setParams=function(t,e,a,r,s){return{tag:t,attr:e,value:a,prefix:r,suffix:s}},t.subscribe=function(e){var a=t.params[e];a.tag=a.tag instanceof Array?a.tag:[a.tag],[].forEach.call(a.tag,function(r){var s=document.querySelectorAll(a.prefix+r+a.suffix+":not([data-img_type])");[].forEach.call(s,function(a){t.params[e].value(a)&&(t.supportsObserver&&!t.isObserverDisabled?(a.setAttribute("data-img_type",e),t.observer.observe(a)):i||window.isAndroid?t.isVisible(a)?t.loadImage(a,t.params[e].attr,t.params[e].value(a),e):setTimeout(function(){t.loadImage(a,t.params[e].attr,t.params[e].value(a),e)},2e3):t.loadImage(a,t.params[e].attr,t.params[e].value(a),e))})})},t.setObserver=function(e){t.observer=new IntersectionObserver(function(e){e.forEach(function(e){if(e.isIntersecting){var a=e.target,r=a.getAttribute("data-img_type");t.loadImage(a,t.params[r].attr,t.params[r].value(a),r),t.observer.unobserve(a)}})},e)},t.loadImage=function(t,e,a,s){s===r?t.style.backgroundImage=a:t.setAttribute(e,a)},t.isVisible=function(t){var e=t.getBoundingClientRect();return e.top>=0&&e.top+10<(window.innerHeight||document.documentElement.clientHeight)||e.bottom>0&&e.bottom<(window.innerHeight||document.documentElement.clientHeight)}};
</script>
            <link rel="stylesheet" href="https://ei.phncdn.com/www-static/css/global-backgrounds.css?cache=2026052109" type="text/css" />
    <link rel="stylesheet" href="https://ei.phncdn.com/www-static/css/generated-header.css?cache=2026052109" type="text/css" />


            <link rel="stylesheet" href="https://ei.phncdn.com/www-static/css/widgets-comments.css?cache=2026052109" type="text/css" />
            <link rel="stylesheet" href="https://ei.phncdn.com/www-static/css/video-show.css?cache=2026052109" type="text/css" />
            <link rel="stylesheet" href="https://ei.phncdn.com/www-static/css/show_new-grid.css?cache=2026052109" type="text/css" />
            <link rel="stylesheet" href="https://ei.phncdn.com/www-static/css/fluid-show_new.css?cache=2026052109" type="text/css" />
            <link rel="stylesheet" href="https://ei.phncdn.com/www-static/css/htmlPauseRoll/pb_block.css?cache=2026052109" type="text/css" />
    
            <link rel="stylesheet" href="https://ei.phncdn.com/www-static/css/large.css?cache=2026052109" type="text/css" media="only screen and (min-width:1350px)" />
    
<link rel="stylesheet" href="https://ei.phncdn.com/www-static/css/flags/round_flag.css?cache=2026052109" type="text/css" />






<link rel="stylesheet" href="https://ei.phncdn.com/www-static/css/ph-icons.css?cache=2026052109" type="text/css" />
    <link rel="stylesheet" href="https://ei.phncdn.com/www-static/css/sfw_layout.css?cache=2026052109" type="text/css" />

                <link rel="stylesheet" href="https://cdn1d-static-shared.phncdn.com/html5player/videoPlayer/es6player/9.0.1/basic-player.min.css" crossorigin="anonymous">
<script src="https://cdn1d-static-shared.phncdn.com/html5player/videoPlayer/es6player/9.0.1/basic-player.min.js"></script>
        


    <script src="https://ei.phncdn.com/www-static/js/initialize-player-assets.js?cache=2026052109" defer></script>
<script src="https://ei.phncdn.com/www-static/js/next-video.js?cache=2026052109" defer></script>
    
        <script type="text/javascript">
        (function(){
            if (typeof checkForGridSupport === 'function') {
                var htmlEl = document.documentElement;
                if (htmlEl) {
                    if (checkForGridSupport()) {
                        MG_Utils.addClass(htmlEl, 'supportsGridLayout');

                        var fluidContainer = 1;
                        if (fluidContainer) {
                            MG_Utils.addClass(htmlEl, 'fluidContainer');
                        }

                    } else {
                        MG_Utils.addClass(htmlEl, 'noGridLayout');
                    }
                }
            }
        })();
    </script>

        	    			<script async type='text/javascript'>
				function requestHb(url) {
					var request = window['XDomainRequest'] ? 
					new window['XDomainRequest']() : new XMLHttpRequest();
					var screenWidth = (window && window.screen && window.screen.width) ? window.screen.width : "Unknown";
					var screenHeight = (window && window.screen && window.screen.height) ? window.screen.height : "Unknown";
					var url = url + "&width=" + screenWidth + "&height=" + screenHeight;

					var duration = new Date().getTime();
					request.onload = request.onerror = request.ontimeout = function() {
						this.response = request.responseText;
						this.duration = new Date().getTime() - duration;
						this.status = request.status;
					}

					request.onprogress = function() {};
					request.open('GET', url);
					request.timeout = 10000;
					request.send();
				}
				var initialHBUrl = '//www.pornhub.com/_xa/ads_batch?ads=true&clientType=mobile&channel[context_page_type]=other&channel[info]=%7B%22actor_id%22%3Anull%2C%22content_type%22%3Anull%2C%22video_id%22%3Anull%2C%22timestamp%22%3A1779558241%2C%22hash%22%3A%2205396eb5845bf0184c80acb5603980ad%22%2C%22session_id%22%3A%22922983257888595140%22%7D&channel[site]=pornhub&site_id=2&device_type=tablet&hbresp=header&hb=F5397646-751A-4888-BF5C-E4B3F20338AB&data=%5B%7B%22spots%22%3A%5B%7B%22zone%22%3A2517131%7D%2C%7B%22zone%22%3A2517121%7D%5D%7D%5D&noc=0&dm=www.pornhub.com/_xa';
				requestHb('//www.pornhub.com/_xa/ads_batch?ads=true&clientType=mobile&channel[context_page_type]=other&channel[info]=%7B%22actor_id%22%3Anull%2C%22content_type%22%3Anull%2C%22video_id%22%3Anull%2C%22timestamp%22%3A1779558241%2C%22hash%22%3A%2205396eb5845bf0184c80acb5603980ad%22%2C%22session_id%22%3A%22922983257888595140%22%7D&channel[site]=pornhub&site_id=2&device_type=tablet&hbresp=header&hb=F5397646-751A-4888-BF5C-E4B3F20338AB&data=%5B%7B%22spots%22%3A%5B%7B%22zone%22%3A2517131%7D%2C%7B%22zone%22%3A2517121%7D%5D%7D%5D&noc=0&dm=www.pornhub.com/_xa');
			</script>
						<script type='text/javascript' async>
			var tjPreloadAds = JSON.parse('{"2517131_1":{"url":"\/\/www.pornhub.com\/_xa\/ads_batch?ads=true&clientType=mobile&channel[context_page_type]=other&channel[info]=%7B%22actor_id%22%3Anull%2C%22content_type%22%3Anull%2C%22video_id%22%3Anull%2C%22timestamp%22%3A1779558241%2C%22hash%22%3A%2205396eb5845bf0184c80acb5603980ad%22%2C%22session_id%22%3A%22922983257888595140%22%7D&channel[site]=pornhub&site_id=2&device_type=tablet&hc=F5397646-751A-4888-BF5C-E4B3F20338AB&data=%5B%7B%22spots%22%3A%5B%7B%22zone%22%3A2517131%7D%5D%7D%5D&noc=0&dm=www.pornhub.com\/_xa"},"2517121_2":{"url":"\/\/www.pornhub.com\/_xa\/ads_batch?ads=true&clientType=mobile&channel[context_page_type]=other&channel[info]=%7B%22actor_id%22%3Anull%2C%22content_type%22%3Anull%2C%22video_id%22%3Anull%2C%22timestamp%22%3A1779558241%2C%22hash%22%3A%2205396eb5845bf0184c80acb5603980ad%22%2C%22session_id%22%3A%22922983257888595140%22%7D&channel[site]=pornhub&site_id=2&device_type=tablet&hc=F5397646-751A-4888-BF5C-E4B3F20338AB&data=%5B%7B%22spots%22%3A%5B%7B%22zone%22%3A2517121%7D%5D%7D%5D&noc=0&dm=www.pornhub.com\/_xa"}}');
			var screenWidth = (window && window.screen && window.screen.width) ? window.screen.width : "Unknown";
			var screenHeight = (window && window.screen && window.screen.height) ? window.screen.height : "Unknown";
			
			var TJ_ADS_TAKEOVER = {
				preloadAds: function() {
					if (!tjPreloadAds) return;

					for(var i in tjPreloadAds) {
						TJ_ADS_TAKEOVER.getAd(tjPreloadAds[i]);
					}
				},
				getAd: function(ad) {
					var request = window['XDomainRequest'] ? 
						new window['XDomainRequest']() : new XMLHttpRequest();
					var url = ad.url + "&width=" + screenWidth + "&height=" + screenHeight + "&v=" + String(Math.random()).substring(2, 12);
					var duration = new Date().getTime();
					request.onload = request.onerror = request.ontimeout = function() {
						ad.response = request.responseText;
						ad.duration = new Date().getTime() - duration;
						ad.status = request.status;
						if (typeof window.tjPreloadEmbeddedAds === 'function') {
							window.tjPreloadEmbeddedAds();
						}
					}
					
					request.onprogress = function() {}; // IE9 fix
					request.open('GET', url);
					request.timeout = 10000; // IE9 fix
					request.send();
				}
			};

			setTimeout(() => {
				TJ_ADS_TAKEOVER.preloadAds();
			}, 200);
		</script>
		
				<meta name='adsbytrafficjunkycontext'  data-hb-guid='F5397646-751A-4888-BF5C-E4B3F20338AB' data-custom-param='&amp;noc=0' data-platform='pc' data-site='pornhub' data-site-id='2' data-context-page-type='other' data-info='{&quot;actor_id&quot;:null,&quot;content_type&quot;:null,&quot;video_id&quot;:null,&quot;timestamp&quot;:1779558241,&quot;hash&quot;:&quot;05396eb5845bf0184c80acb5603980ad&quot;,&quot;session_id&quot;:&quot;922983257888595140&quot;}' data-refresh-times='2' data-refresh-delay='240' data-domain-rewrite='www.pornhub.com/_xa' />
							<link rel="preload" href="https://static.trafficjunky.com/invocation/embeddedads/production/embeddedads.es6.min.js?v=2026-05-23" as="script">
				<script async>
							var tjEmbeddedAdsDuration = new Date().getTime();
						(function(env) {
				var addTjScript = function (url) {
					var script   = document.createElement('script');
					script.type  = 'text/javascript';
					script.async = true;
					script.src   =  url;

					document.getElementsByTagName('head')[0].appendChild(script);
				}

				
					var supportsES6 = function() {
						try {
							new Function('(a = 0) => a');

							if (/(iPhone|iPod|iPad)/i.test(navigator.userAgent)) { // IOS10 fix
								return parseInt(navigator.userAgent.match(/OS [\d_]+/i)[0].substr(3).split('_')[0]) !== 10;
							}

							return true;
						}
						catch (err) {
							return false;
						}
					}();

					var version = 'es5';
					if (typeof Promise !== 'undefined' && Promise.toString().indexOf('[native code]') !== -1 && supportsES6) {
						version = 'es6';
					}

					addTjScript('https://static.trafficjunky.com/invocation/embeddedads/' + env + '/embeddedads.' + version + '.min.js?v=2026-05-23');
													addTjScript('https://static.trafficjunky.com/invocation/popunder/' + env + '/popunder.min.js');
							})('production');
		</script>

		
    <meta name="robots" content="noindex, nofollow">

    <link rel="canonical" href="https://www.pornhub.com/" />

    
        
    <script>
        page_params.logPageLoadTime = "";
        page_params.cpuProtection = {
            autocompleteDelay: "0",
            minimumCharacters: "0"
        };
        const startLogPageLoadTime = performance.now();
    </script>
</head>
            <div id="cookieBanner"></div>
        <script>
            if (typeof CookieHelper != 'undefined') {
                if (CookieHelper.getCurrentConsent() == '1') {
                    addClogCookieBanner(currentDomain, 'av-modal-open', originPart, originUrl);
                    showFullCookieBanner();
                } else if (CookieHelper.getCurrentConsent() == '2' && cbCookieBannerState !== '1') {
                    addClogCookieBanner(currentDomain, 'av-modal-open', originPart, originUrl);
                    showShortCookieBanner();
                }
            }
        </script>
        <body class="sfw-page logged-out">
            <meta name="rating" content="RTA-5042-1996-1400-1577-RTA" />

                    
<script type="text/javascript">
    const gSSOClientId = '387494305642-81snv5i6ka4c75cqo0qbd9km6nap3ojv.apps.googleusercontent.com';
    const gSSOLang = 'en';
    const showGoogleSso = '1';
    const redirectUrl =  "Jh_4w2qw3eDnakwRZvKQe65cP5LAtJ6bjCiLojhv3ilGc3jPRmmS-nEMycq5C7W-ydj3mvoJ0oUQLtwSaGXt2N05E1jgQHZyH9ICXDxhg9J_T9qeEOnXAyphHLLf37TgyZ5D_Y8k-lbFYXxPco4d8COAfow=";
    const createAccountUrl = 'https://www.pornhub.com/signup';

    // Show error message when user failed email verification too many times (Signin modal or page)
    
    var isDesktop = "1";
</script>
<template id="signinModal" class="modalWrapper">
    <div class="js-signUpFormModal signInModalWrapper newModalWrapper">

                <div class="signInWrap" data-step="signIn">
            <div class="mainModalTitle">
                <noscript>
                    <br>Warning: either you have javascript disabled or your browser does not support javascript. To view the video, this page requires javascript to be enabled.<br><br>
                </noscript>
                                    <img src="https://ei.phncdn.com/www-static/images/pornhub_logo_straight.svg?cache=2026052109" class="logo" alt="Pornhub logo"/>
                                                    <span class="loginAccessTitle-en">
                        Member Log In                        <span class="subtitle">Access your Pornhub account</span>
                    </span>
                            </div>

            <div class="modal-body clearfix ssoModalBody">
                                    <form autocomplete="off" class="js-loginFormModal js-loginForm">
                                                    <input
                                type="hidden"
                                class="js-redirect"
                                name="redirect"
                                value="Py1J8Y7AO-0I2jncnz_A7AEiiwIR-a-SR1O172h5eOGcsyf8eDv1jjJzQ8NLwztjGn0cWYkMmejGbe-qD-OuXpackkICZv0zpkxTT5SX40ephQEOHb1eIeTggrvG3sBx2M-md-XgynUCKRYXha1WHWLYiGM="
                            />
                            <input type="hidden" class="userId" name="user_id" value="">
                            <input
                                class="intendedAction"
                                type="hidden"
                                name="intended_action"
                                value=""
                            />
                            <input type="hidden" name="token" value="MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8." />
                            <input type="hidden" name="from" value="pc_login_modal_:sfwWatchPage">
                        
                        <div class="leftSide loginColumnLeft-en">
                                                            <div class="ssoSignWrap js-ssoContentLogin">
                                    <span class="ssoErrors js-ssoErrors displayNone"></span>
<div class="ssoSignBtns ">
            <button id="ssoGoogleSigninButton" type="button">
            <img src="https://ei.phncdn.com/www-static/images/google-sso-icon.svg?cache=2026052109" alt="Google SSO">
            <span>Log in with Google</span>
        </button>
        <button id="ssoXSigninButton" type="button">
        <i class="ph-icon-twitterX"></i>
        <span>Log in with X</span>
    </button>
    </div>
<div class="separator">
    <span class="separatorLine"></span>
    <span class="textChoose">or</span>
</div>
    <div class="emailPassSignButton  js-toggleLogin">
        Log in with email and password    </div>
                                </div>
                                                        <div class="js-emailPassLogin emailPassSignWrap">
                            <span class="signinError textCenter" style="display:none;"></span>
                            <span id="signinLoggingin" class="textCenter" style="display:none;">
                                <span class="greenLoader"></span>
                                Logging in                            </span>
                            <div>
                                <input
                                    id="usernameModal"
                                    placeholder="Email"
                                    class="js-signinUsername signup_field"
                                    name="email"
                                    maxlength="254"
                                    type="text"
                                    tabindex="0"
                                    value=""
                                    autofocus
                                >
                                <span class="ph-icon-error displayNone"></span>

                            </div>
                            <div class="loginPasswordWrapper">
                                <input
                                    id="passwordModal"
                                    placeholder="Password"
                                    class="js-signinPassword signup_field"
                                    name="password"
                                    type="password"
                                    tabindex="0"
                                    value=""
                                >
                                <div class="loginPasswordIconsWrapper">
                                    <span data-visiblitily="passwordModal" class="passIcon icons ph-icon-view-off"></span>
                                    <span class="ph-icon-error displayNone"></span>
                                </div>
                            </div>
                                                                                        <div class="optional captchaLoginBlock">
                                    <div class="g-recaptcha" data-type="checkbox" data-sitekey="6LfyQRoUAAAAAApqS-inJxUwCOtvOHwKxJuZCsuv"></div>
                                    <div class="clearfix"></div>
                                </div>
                                                                                        <div class="forgetPassWrapper">
                                    <ul>
            <li>
            <a id="signinForgotpassword" href="/front/lost_password">
                Forgot Password?            </a>
        </li>
            </ul>
                                </div>
                                                        <div class="backSignBtnWrap textCenter">
                                                                    <div class="js-toggleLogin backToSSOBtn">Back</div>
                                                                <div id="signinSubmit" class="orangeButton buttonBase js-loginSubmit disabled" disabled>
                                    Log in                                </div>
                            </div>
                                                        </div>
                            <div class="textCenter createAccount">
                                Don't have an account yet?                                <a
                                    id="signupButtonId"
                                    href="javascript:void(0)"
                                    onclick="signinbox.show({step:'signUp'});userClogTracking(currentDomain, 'signup-open', originPart, originUrl, clickedElement, newModal); return false;"
                                >
                                Sign Up                                </a>
                                here                            </div>
                                                    </div>
                    </form>

                    <form autocomplete="off" data-type class="js-userVerificationModal displayNone">
                        <div class="codeContent">
                            <h5 class="default2fa displayNone">A text message with your code has been sent to:</h5>
                            <h5 class="email2fa displayNone">An email with the verification code has been sent to:</h5>
                            <h5 class="google2fa displayNone">Use the 6 digit code sent to your two-factor authentication app</h5>
                            <h5 class="default2fa displayNone" id="userPhoneNumber"></h5>
                            <h5 class="email2fa displayNone" id="userEmail"></h5>
                        </div>

                        <input type="hidden" name="email" id="verificationEnabledEmail" />
                        <input type="hidden" name="token2" id="verificationEnabledToken" />
                        <input type="hidden" name="verification_modal" value="1" />
                        <input type="hidden" name="authyId" id="authyId" />
                        <input type="hidden" name="authyIdHashed" id="authyIdHashed" />
                        <input type="hidden" name="token" id="xsrfToken" value="MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8." />

                        <label for="enterVerificationCode">Enter the code</label>
                        <input type="number" inputmode="numeric" name="verification_code" id="enterVerificationCode" class="enterVerificationCode" />
                        <p class="twoStepVerificationMessage displayNone"></p>
                        <button id="btnVerifyCode" class="orangeButton big buttonBase disabled removeAdLink">
                            Verify                        </button>

                        <div class="resendCodeResponse displayNone">
                            <div class="resendCodeStatus"></div>
                            <div class="resendCodeMessage"></div>
                        </div>

                        <div class="codeResend default2fa email2fa displayNone">
                            <span>Didn't receive the code?</span> <a href="#" id="resendVerificationCode" class="orangeText removeAdLink">Resend</a>                        </div>

                                                    <div class="contactSupport">
                                <span>Need help? Please</span> <a href="mailto:support@pornhub.com" class="orangeText contactSupportMail">Contact Support</a>                            </div>
                                            </form>
                            </div>
        </div>

                <div class="signUpWrap clearfix newModal ssoWrapper" data-step="signUp">
                            <div class="signUpLeftWrapper straight pc all">
                                            <div class="pillsWrapper">
                            <div>
                                <p><span class="pillsValue">140M</span><span class="pillsAction">Engaged</span><span>daily users</span></p>
                            </div>
                            <div>
                                <p><span class="pillsValue">600k</span><span class="pillsAction">Active</span><span>content creators</span></p>
                            </div>
                            <div>
                                <p><span class="pillsValue">1M</span><span class="pillsAction">Hours</span><span>of free content</span></p>
                            </div>
                        </div>
                                        <div class="mainModalTitleMobile">
                        <img src="https://ei.phncdn.com/www-static/images//pornhub_logo_straight.png?cache=2026052109" class="logo" alt="Pornhub logo"/>
                        <span>
                            Sign Up for Free                        </span>
                    </div>
                </div>
                        <div class="signUpRightWrapper">
                <div class="mainModalTitle signUpTitle">
                                            <img src="https://ei.phncdn.com/www-static/images//pornhub_logo_straight.png?cache=2026052109" class="logo" alt="Pornhub logo"/>
                                        <span>
                        Sign Up for Free                        <span class="subtitle">and enhance your experience</span>
                    </span>
                </div>
                                    <div class="signUpBenefitsWrapper displayNone">
                        <ul>
                            <li>
                                <img src="https://ei.phncdn.com/www-static/images/signup_playlists.svg?cache=2026052109" alt="Playlists">
                                <p>Create your own playlists.</p>
                            </li>
                            <li>
                                <img src="https://ei.phncdn.com/www-static/images/signup_community.svg?cache=2026052109" alt="Community">
                                <p>Engage with the community.</p>
                            </li>
                            <li>
                                <img src="https://ei.phncdn.com/www-static/images/signup_tailored.svg?cache=2026052109" alt="Tailored">
                                <p>Tailored video suggestions.</p>
                            </li>
                        </ul>
                    </div>
                                <div class="modal-body clearfix">
                    <v-create-account-form
                        token="MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8."
                        email-default=""
                        password-default=""
                        show-captcha=""
                        recaptcha-key="6LfyQRoUAAAAAApqS-inJxUwCOtvOHwKxJuZCsuv"
                        email-error="Invalid email format."
                        password-error="Password not long enough."
                        gcaptcha-error="Recaptcha required."
                        post-messages='[]'
                        is-mandatory-email-verification="1"
                        show-google-sso="1"
                        google-sso-button-html='
<div class="gsi-material-button-state"></div>
<div class="gsi-material-button-content-wrapper">
    <div class="gsi-material-button-icon">
        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" xmlns:xlink="http://www.w3.org/1999/xlink" style="display: block;">
            <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
            <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
            <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
            <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
            <path fill="none" d="M0 0h48v48H0z"></path>
        </svg>
    </div>
    <span class="gsi-material-button-contents">Sign up with Google</span>
    <span style="display: none;">Sign up with Google</span>
</div>

'
                        show-x-sso="1"
                        x-sso-button-html='<span class="ssoErrors js-ssoErrors displayNone"></span>
<div class="ssoSignBtns ">
            <button id="ssoGoogleSignupButton" type="button">
            <img src="https://ei.phncdn.com/www-static/images/google-sso-icon.svg?cache=2026052109" alt="Google SSO">
            <span>Sign up with Google</span>
        </button>
        <button id="ssoXSignupButton" type="button">
        <i class="ph-icon-twitterX"></i>
        <span>Sign up with X</span>
    </button>
    </div>
<div class="separator">
    <span class="separatorLine"></span>
    <span class="textChoose">or</span>
</div>
    <div class="emailPassSignButton  js-toggleSignup">
        Sign up with email and password    </div>
'
                        translation="{&quot;createAccountUrl&quot;:&quot;https:\/\/www.pornhub.com\/signup&quot;,&quot;checkAccountUrl&quot;:&quot;https:\/\/www.pornhub.com\/api\/v1\/user\/create_account_check?token=MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8.&quot;,&quot;redirectUrl&quot;:&quot;JslFwKMhd5Nr6xM3lxhDEfEETzLirDToemWfi-9aYeAu1WBqg8LyENMX01SYWBJiAM9BqnbJrH7QPEY54hkT3eKC8rGDzOWMMgwmJPBFAy9GIW40s3fFCjT0E0c2UhpvaaW7xsp3juHcKPd9WLp5YvqSqIk=&quot;,&quot;resendConfirmationUrl&quot;:&quot;\/front\/resend_confirmation_email&quot;,&quot;emailHolder&quot;:&quot;Email&quot;,&quot;usernameHolder&quot;:&quot;Username (6+ characters)&quot;,&quot;passwordHolder&quot;:&quot;Password&quot;,&quot;submitLabel&quot;:&quot;Sign Up&quot;,&quot;gcaptchaExpired&quot;:&quot;Recaptcha expired.&quot;,&quot;or&quot;:&quot;Or&quot;,&quot;signin&quot;:&quot;Log in&quot;,&quot;terms&quot;:&quot;&lt;span&gt;By signing up, you agree to the &lt;a href=\&quot;\/information\/terms\&quot;&gt;Terms and Conditions&lt;\/a&gt; and &lt;a href=\&quot;\/information\/privacy\&quot;&gt;Privacy Policy&lt;\/a&gt;, including &lt;a href=\&quot;\/information\/cookie-notice\&quot;&gt;Cookie Use&lt;\/a&gt;.&lt;\/span&gt;&quot;,&quot;resend&quot;:&quot;Resend Confirmation Email&quot;,&quot;loginText1&quot;:&quot;Already have an account?&quot;,&quot;loginText2&quot;:&quot;Login&quot;,&quot;loginText3&quot;:&quot;here&quot;,&quot;passStrength&quot;:&quot;Strength:&quot;,&quot;checkPasswordUrl&quot;:&quot;\/api\/v1\/user\/password_challenge&quot;,&quot;backLabel&quot;:&quot;Back&quot;}"
                        dataPageAction= "show"
                        modal="true"
                        simplified-signup="1"
                                                >
                    </v-create-account-form>
                </div>
            </div>
        </div>
    </div>
</template>


<script type="text/javascript">
    var connectionModalData = {
        configs: {
            customConnectionModals: "1",
            // LOGIN
            dateAdded: "",
            xhrRequest: "",
            showXSso: "1",
            readonlyMaintenance: "",
            redirectFieldValue: "EUn9H-XykLqunOoQBtUIZqjUR0b00MRtuI9j1C2QyBc9L1RdytHZgmUlLu_IUvPFI9e4ejRHuvQI3W0IHWMUrG0vPFFcVpWIM2XsclKo8Dd49tnHX47EvbSKDs-W0eYGSZK9-MiK8Xq98UqDp0BkMGBjd94=",
            fromValue: "pc_login_modal_:sfwWatchPage",
            token: "MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8.",
            languageUsed: "en",
            withoutCaptcha: "",
            captchaType: "checkbox",
            captchaKey: "6LfyQRoUAAAAAApqS-inJxUwCOtvOHwKxJuZCsuv",
            showGoogleSso: "1",
            showDiscordSso: "",
            imageBaseUrl: "https://ei.phncdn.com/www-static/images/",
            cdnCacheKey: "?cache=2026052109",
            lostPasswordUrl: "/front/lost_password",
            mandatoryEmailVerification: "1",
            resendConfirmationEmailUrl: "/front/resend_confirmation_email",
            onPremiumDomain: "",
            freeSupportEmail: "support@pornhub.com",
            premiumSupportEmail: "support@pornhubpremium.com",
            showRegularForm: "true",
            loginUrl: "/front/authenticate",
            urlResendCode: "/user/resend_verification_code",
            forgotPasswordUrl: "/front/lost_password",
            isSfw: "1",
            countryCode: "US",

            // SIGNUP,
            newSignUpModal: "1",
            isMobile: "",
            segment: "straight",
            taste: "straight",
            region: "all",
            logo: "/logos/pornhub_vertical_white_color_2x.png",
            defaultEmail: "",
            defaultUsername: "",
            defaultPassword: "",
            showCaptcha: "",
            postMessages: '[]',
            dataPageAction: "show",
            simplifiedSignup:"1",
            googleSsoButtonHtml: "\n<div class=\"gsi-material-button-state\"><\/div>\n<div class=\"gsi-material-button-content-wrapper\">\n    <div class=\"gsi-material-button-icon\">\n        <svg version=\"1.1\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\" viewBox=\"0 0 48 48\" xmlns:xlink=\"http:\/\/www.w3.org\/1999\/xlink\" style=\"display: block;\">\n            <path fill=\"#EA4335\" d=\"M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z\"><\/path>\n            <path fill=\"#4285F4\" d=\"M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z\"><\/path>\n            <path fill=\"#FBBC05\" d=\"M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z\"><\/path>\n            <path fill=\"#34A853\" d=\"M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z\"><\/path>\n            <path fill=\"none\" d=\"M0 0h48v48H0z\"><\/path>\n        <\/svg>\n    <\/div>\n    <span class=\"gsi-material-button-contents\">Sign up with Google<\/span>\n    <span style=\"display: none;\">Sign up with Google<\/span>\n<\/div>\n\n",
            xSsoButtonHtml: "<span class=\"ssoErrors js-ssoErrors displayNone\"><\/span>\n<div class=\"ssoSignBtns \">\n            <button id=\"ssoGoogleSignupButton\" type=\"button\">\n            <img src=\"https:\/\/ei.phncdn.com\/www-static\/images\/google-sso-icon.svg?cache=2026052109\" alt=\"Google SSO\">\n            <span>Sign up with Google<\/span>\n        <\/button>\n        <button id=\"ssoXSignupButton\" type=\"button\">\n        <i class=\"ph-icon-twitterX\"><\/i>\n        <span>Sign up with X<\/span>\n    <\/button>\n    <\/div>\n<div class=\"separator\">\n    <span class=\"separatorLine\"><\/span>\n    <span class=\"textChoose\">or<\/span>\n<\/div>\n    <div class=\"emailPassSignButton  js-toggleSignup\">\n        Sign up with email and password    <\/div>\n",
            modal: "true",
            createAccountUrl: "https://www.pornhub.com/create_account",
            createAccountSelectUrl: "/create_account_select",
            checkAccountUrl: "https://www.pornhub.com/api/v1/user/create_account_check?token=MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8.",
            redirectUrl: "Jh_4w2qw3eDnakwRZvKQe65cP5LAtJ6bjCiLojhv3ilGc3jPRmmS-nEMycq5C7W-ydj3mvoJ0oUQLtwSaGXt2N05E1jgQHZyH9ICXDxhg9J_T9qeEOnXAyphHLLf37TgyZ5D_Y8k-lbFYXxPco4d8COAfow=",
            resendConfirmationUrl: "/front/resend_confirmation_email",
            checkPasswordUrl: "/api/v1/user/password_challenge",
        },
        translations: {
            'noJsError': "Warning: either you have javascript disabled or your browser does not support javascript. To view the video, this page requires javascript to be enabled.",
            'maintenanceError': "Pornhub is currently undergoing maintenance. Login and Signup are currently disabled. Hold tight, we'll be back at 100% shortly.",
            'memberLogin': "Member Log In",
            'memberSignin': "Member Sign in",
            'accessPHAccount': "Access your Pornhub account",
            'loggingIn': "Logging in",
            'email': "Email",
            'password': "Password",
            'back': "Back",
            'login': "Log in",
            'signin': "Sign in",
            'signinGoogle': "Sign in with Google",
            'noAccount': "Don't have an account yet?",
            'here': "here",
            'default2fa': "A text message with your code has been sent to",
            'email2fa': "An email with the verification code has been sent to",
            'google2fa': "Use the 6 digit code sent to your two-factor authentication app",
            'code2fa': "Enter the code",
            'verify2fa': "Verify",
            'noCodeReceived': "Didn't receive the code?",
            'resend': "Resend",
            'needHelp': "Need help? Please",
            'contactSupport': "Contact Support",
            'verificationModalTitle': "Two-Step Verification",
            'phoneNumberVerificationError': "Incorrect code. Please try again.",
            'ajaxError': "There was an error processing your request. Please try again.",
            'forgotPassword': "Forgot Password?",
            'resendConfirmation': "Resend confirmation email",
            'googleSSO': "Google SSO",
            'googleSSOLogin': "Log in with Google",
            'xSSOLogin': "Log in with X",
            'discordSSOLogin': "Log in with Discord",
            'regularFormLogin': "Log in with email and password",
            'createAccountUrl': "https://www.pornhub.com/signup",
            'passkeyCreateAccountUrl': "https://www.pornhub.com/signup/sfw",
            'checkAccountUrl': "https://www.pornhub.com/api/v1/user/create_account_check?token=MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8.",
            'redirectUrl': "Jh_4w2qw3eDnakwRZvKQe65cP5LAtJ6bjCiLojhv3ilGc3jPRmmS-nEMycq5C7W-ydj3mvoJ0oUQLtwSaGXt2N05E1jgQHZyH9ICXDxhg9J_T9qeEOnXAyphHLLf37TgyZ5D_Y8k-lbFYXxPco4d8COAfow=",
            'resendConfirmationUrl': "/front/resend_confirmation_email",
            'checkPasswordUrl': "/api/v1/user/password_challenge",
            'loginWith': "Log in with",
            'registrationMessage': "Pornhub is not currently accepting new account registrations in your region.",

            // SIGNUP
            'engaged': "Engaged",
            'dailyUsers': "daily users",
            'active': "Active",
            'contentCreators': "content creators",
            'hours': "Hours",
            'ofFreeContent': "of free content",
            'pornhubLogo': "Pornhub logo",
            'pornhubPremiumLogo': "Pornhub Premium logo",
            'signup': "Sign Up",
            'signupForFree': "Sign Up for Free",
            'enhanceExperience': "and enhance your experience",
            'createOwnPlaylist': "Create your own playlists.",
            'playlist': "Playlist",
            'engageWithCommunity': "Engage with the community.",
            'community': "Community",
            'tailoredVideoSuggestions': "Tailored video suggestions.",
            'tailored': "Tailored",
            'emailError': "Invalid email format.",
            'usernameError': "Username not long enough.",
            'passwordError': "Password not long enough.",
            'gcaptchaError': "Recaptcha required.",
            'compareError': "Username must not match Password.",
            'emailHolder': "Email",
            'usernameHolder': "Username (6+ characters)",
            'passwordHolder': "Password",
            'submitLabel': "Sign Up",
            'gcaptchaExpired': "Recaptcha expired.",
            'or': "Or",
            'signin': "Log in",
            'terms': "<span>By signing up, you agree to the <a href=\"/information/terms\">Terms and Conditions</a> and <a href=\"/information/privacy\">Privacy Policy</a>, including <a href=\"/information/cookie-notice\">Cookie Use</a>.</span>",
            'resend': "Resend Confirmation Email",
            'loginText1': "Already have an account?",
            'loginText2': "Login",
            'loginText3': "here",
            'passStrength': "Strength:",
            'backLabel': "Back",
            'privacyNotice': "Privacy Notice",
            'privacyText': "<b>Your privacy is very important to us.</b> We only collect your email address and do not share or store any other personal information.",
            'signupWith': "Sign up with",
            'googleSSOSignup': "Sign up with Google",
            'xSSOSignup': "Sign up with X",
            'discordSSOSignup': "Sign up with Discord",
            'regularFormSignup': "Sign up with email and password",
            'twoFactorAuthentication': "Two-Factor Authentication",

            // PASSKEY
            'continue': "Continue",
            'continueWithPasskey': "Continue with passkey",
            'loginOrCreateAccount': "Log in or <br>create an account",
            'invalidEmail': "Invalid email format",
            'userNotFound': "No account found with this email",
            'checkError': "Unable to verify email. Please try again.",
            'hidePassword': "Hide password",
            'showPassword': "Show password",
            'newUserTitle': "Looks like you're new to Pornhub",
            'newUserSubtitle': "Let's create an account using",
            'createAccount': "Create an account",
            'passkeyModuleNotLoaded': "Passkey module not loaded",
            'authenticationFailed': "Authentication failed",
            'invalidCredentials': "Invalid Credentials",
            'authenticationFailedFaq': "Authentication failed. Please see our <a href=\"https://help.pornhub.com/hc/en-us/sections/51334277818771-Passkeys\" target=\"_blank\" rel=\"noopener\">FAQs</a> for more information.",
            'signUpFailedFaq': "Sign up failed. Please check our <a href=\"https://help.pornhub.com/hc/en-us/sections/51334277818771-Passkeys\" target=\"_blank\" rel=\"noopener\">FAQs</a> for more information.",
            'completeCaptcha': "Please complete the captcha to continue",
            'errorOccurred': "An error occurred. Please try again.",
            'accountCreationFailed': "Account creation failed",
            'registrationFailed': "Registration failed",
            'loginFailed': "Login failed",
            'unexpectedError': "An unexpected error occurred. Please try again.",
            'operationAborted': "The operation was aborted. Please try again.",
            'permissionDenied': "Permission denied. Please try again or use a different method.",
            'passkeysNotSupported': "Passkeys are not supported on this device or browser.",
            'securityError': "A security error occurred. Please ensure you are on a secure connection.",
            'passkeyAlreadyExists': "A passkey already exists for this account on this device.",
            'verificationFailed': "Verification failed",
            'registrationInProgress': "Registration in progress",
        },
        customModalHeads: {
            notInterested: {
                title: "<span>Customize</span> your feed and hide what you don't want to see!",
                imgSrc: "customModals/notInterestedHead.png",
            },
            favorite: {
                title: "Add to <span>Favorites</span> to quickly find videos you love!",
                imgSrc: "customModals/favoriteHead.png",
            },
            subscribe: {
                title: "<span>Subscribe</span> to keep your favorite creators close!",
                imgSrc: "customModals/subscribeHead.png",
            },
            message: {
                title: "Slide into your favorite creators <span>DMs</span>!",
                imgSrc: "customModals/messageHead.png",
            },
            likedVideos: {
                title: "Easily find videos<br>you've <span>Liked</span>!",
                imgSrc: "customModals/likedVideosHead.png",
            },
            watchLater: {
                title: "Busy? Add to <span>Watch Later</span> for next time!",
                imgSrc: "customModals/watchLaterHead.png",
            },
            playlist: {
                title: "Create and share<br><span>Playlists</span> for every vibe!",
                imgSrc: "customModals/playlistsHead.png",
            },
            shortiesComment: {
                title: "Watch, React, <span>Comment</span><br> on your Favorites",
                imgSrc: "customModals/shortiesCommentHead.png",
            },
        }
    }
</script>
            
<script type="text/javascript">
    // Show error message when user failed email verification too many times (Signin modal or page)
    
    var isDesktop = "1";
    if(typeof loadGSSOLibrary === 'undefined') var loadGSSOLibrary = true;
</script>
<template id="signinModalApt" class="modalWrapper">
    <div class="js-signUpFormModal signInModalWrapper">

                <div class="signInWrap" data-step="signIn">
            <div class="mainModalTitle">
                <noscript>
                    <br>Warning: either you have javascript disabled or your browser does not support javascript. To view the video, this page requires javascript to be enabled.<br><br>
                </noscript>
                                    <span class="logoWrapper">
                        <img src="https://ei.phncdn.com/www-static/images//pornhub_logo_straight.png?cache=2026052109" class="logo" alt="Pornhub logo"/>
                        <i class="roundFlagIcon round-flag-"></i>
                    </span>
                                                    <span class="loginAccessTitle-en">
                        Member Log In                        <span class="subtitle">Access your Pornhub account</span>
                    </span>
                            </div>

            <div class="modal-body clearfix ssoModalBody">
                                    <form autocomplete="off" class="js-loginFormModal js-loginForm">
                                                    <input
                                    type="hidden"
                                    class="js-redirect"
                                    name="redirect"
                                    value="Gdi6rmkjwm2bGO1VZ1uPUMMhXkMmhZvBib8v71srzTg2xsTcIvI-OdZOeMFCyl-hmadJCG_gYABvNu0f-64dGtzVWWx4xxoGb1o8mfJzFSaMbXD_TmPY3srHAYnQhWHDkLRgc8PV4BCrX2CKxRS0BkChRqI="
                            />
                            <input type="hidden" class="userId" name="user_id" value="">
                            <input
                                    class="intendedAction"
                                    type="hidden"
                                    name="intended_action"
                                    value=""
                            />
                            <input type="hidden" name="token" value="MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8." />
                            <input type="hidden" name="from" value="pc_login_modal_:sfwWatchPage">
                        
                        <div class="leftSide loginColumnLeft-en">
                                                            <div class="ssoSignWrap js-ssoContentLogin">
                                    <span class="ssoErrors js-ssoErrors displayNone"></span>
<div class="ssoSignBtns ">
            <button id="ssoGoogleSigninButton" type="button">
            <img src="https://ei.phncdn.com/www-static/images/google-sso-icon.svg?cache=2026052109" alt="Google SSO">
            <span>Log in with Google</span>
        </button>
        <button id="ssoXSigninButton" type="button">
        <i class="ph-icon-twitterX"></i>
        <span>Log in with X</span>
    </button>
    </div>
<div class="separator">
    <span class="separatorLine"></span>
    <span class="textChoose">or</span>
</div>
    <div class="emailPassSignButton aptOrangeButton js-toggleLogin">
        Log in with email and password    </div>
                                </div>
                                                        <div class="js-emailPassLogin emailPassSignWrap">
                                <span class="signinError textCenter" style="display:none;"></span>
                                <span id="signinLoggingin" class="textCenter" style="display:none;">
                                <span class="greenLoader"></span>
                                Logging in                            </span>
                                <div>
                                    <input
                                            id="usernameModal"
                                            placeholder="Email"
                                            class="js-signinUsername signup_field"
                                            name="email"
                                            maxlength="254"
                                            type="text"
                                            tabindex="0"
                                            value=""
                                            autofocus
                                    >
                                    <span class="ph-icon-error displayNone"></span>

                                </div>
                                <div class="loginPasswordWrapper">
                                    <input
                                            id="passwordModal"
                                            placeholder="Password"
                                            class="js-signinPassword signup_field"
                                            name="password"
                                            type="password"
                                            tabindex="0"
                                            value=""
                                    >
                                    <div class="loginPasswordIconsWrapper">
                                        <span data-visiblitily="passwordModal" class="passIcon icons ph-icon-view-off"></span>
                                        <span class="ph-icon-error displayNone"></span>
                                    </div>
                                </div>
                                                                                                    <div class="optional captchaLoginBlock">
                                        <div class="g-recaptcha" data-type="checkbox" data-sitekey="6LfyQRoUAAAAAApqS-inJxUwCOtvOHwKxJuZCsuv"></div>
                                        <div class="clearfix"></div>
                                    </div>
                                                                                                    <div class="forgetPassWrapper">
                                        <ul>
            <li>
            <a id="signinForgotpassword" href="/front/lost_password">
                Forgot Password?            </a>
        </li>
            </ul>
                                    </div>
                                                                <div class="backSignBtnWrap textCenter">
                                                                            <div class="js-toggleLogin backToSSOBtn">Back</div>
                                                                        <div id="signinSubmit" class="orangeButton buttonBase js-loginSubmit disabled" disabled>
                                        Log in                                    </div>
                                </div>
                                                            </div>
                            <div class="textCenter createAccount">
                                Don't have an account yet?                                <a
                                        id="signupButtonId"
                                        href="javascript:void(0)"
                                        onclick="signinbox.show({step:'signUp'});userClogTracking(currentDomain, 'signup-open', originPart, originUrl, clickedElement, newModal); return false;"
                                >
                                    Sign Up                                </a>
                                here                            </div>
                                                    </div>
                    </form>

                    <form autocomplete="off" data-type class="js-userVerificationModal displayNone">
                        <div class="codeContent">
                            <h5 class="default2fa displayNone">A text message with your code has been sent to:</h5>
                            <h5 class="email2fa displayNone">An email with the verification code has been sent to:</h5>
                            <h5 class="google2fa displayNone">Use the 6 digit code sent to your two-factor authentication app</h5>
                            <h5 class="default2fa displayNone" id="userPhoneNumber"></h5>
                            <h5 class="email2fa displayNone" id="userEmail"></h5>
                        </div>

                        <input type="hidden" name="email" id="verificationEnabledEmail" />
                        <input type="hidden" name="token2" id="verificationEnabledToken" />
                        <input type="hidden" name="verification_modal" value="1" />
                        <input type="hidden" name="authyId" id="authyId" />
                        <input type="hidden" name="authyIdHashed" id="authyIdHashed" />
                        <input type="hidden" name="token" id="xsrfToken" value="MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8." />

                        <label for="enterVerificationCode">Enter the code</label>
                        <input type="number" inputmode="numeric" name="verification_code" id="enterVerificationCode" class="enterVerificationCode" />
                        <p class="twoStepVerificationMessage displayNone"></p>
                        <button id="btnVerifyCode" class="orangeButton big buttonBase disabled removeAdLink">
                            Verify                        </button>

                        <div class="resendCodeResponse displayNone">
                            <div class="resendCodeStatus"></div>
                            <div class="resendCodeMessage"></div>
                        </div>

                        <div class="codeResend default2fa email2fa displayNone">
                            <span>Didn't receive the code?</span> <a href="#" id="resendVerificationCode" class="orangeText removeAdLink">Resend</a>                        </div>

                                                    <div class="contactSupport">
                                <span>Need help? Please</span> <a href="mailto:support@pornhub.com" class="orangeText contactSupportMail">Contact Support</a>                            </div>
                                            </form>
                            </div>
        </div>

                <div class="signUpWrap clearfix ssoWrapper" data-step="signUp">
            <div class="signUpRightWrapper">
                <div class="mainModalTitle signUpTitle">
                                            <span class="logoWrapper">
                            <img src="https://ei.phncdn.com/www-static/images//pornhub_logo_straight.png?cache=2026052109" class="logo" alt="Pornhub logo"/>
                            <i class="roundFlagIcon round-flag-"></i>
                        </span>
                                        <span class="headerWrapper">
                        Sign Up for Free to verify your age                    </span>
                </div>
                <div class="modal-body clearfix">
                    <v-create-account-form
                            token="MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8."
                            email-default=""
                            password-default=""
                            show-captcha=""
                            recaptcha-key="6LfyQRoUAAAAAApqS-inJxUwCOtvOHwKxJuZCsuv"
                            email-error="Invalid email format."
                            password-error="Password not long enough."
                            gcaptcha-error="Recaptcha required."
                            post-messages='[]'
                            is-mandatory-email-verification="1"
                            show-google-sso="1"
                            google-sso-button-html='
<div class="gsi-material-button-state"></div>
<div class="gsi-material-button-content-wrapper">
    <div class="gsi-material-button-icon">
        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" xmlns:xlink="http://www.w3.org/1999/xlink" style="display: block;">
            <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
            <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
            <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
            <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
            <path fill="none" d="M0 0h48v48H0z"></path>
        </svg>
    </div>
    <span class="gsi-material-button-contents">Sign up with Google</span>
    <span style="display: none;">Sign up with Google</span>
</div>

'
                            show-x-sso="1"
                            x-sso-button-html='<span class="ssoErrors js-ssoErrors displayNone"></span>
<div class="ssoSignBtns ">
            <button id="ssoGoogleSignupButton" type="button">
            <img src="https://ei.phncdn.com/www-static/images/google-sso-icon.svg?cache=2026052109" alt="Google SSO">
            <span>Sign up with Google</span>
        </button>
        <button id="ssoXSignupButton" type="button">
        <i class="ph-icon-twitterX"></i>
        <span>Sign up with X</span>
    </button>
    </div>
<div class="separator">
    <span class="separatorLine"></span>
    <span class="textChoose">or</span>
</div>
    <div class="emailPassSignButton aptOrangeButton js-toggleSignup">
        Sign up with email and password    </div>
'
                            translation="{&quot;createAccountUrl&quot;:&quot;https:\/\/www.pornhub.com\/signup&quot;,&quot;checkAccountUrl&quot;:&quot;https:\/\/www.pornhub.com\/api\/v1\/user\/create_account_check?token=MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8.&quot;,&quot;redirectUrl&quot;:&quot;RRqSCtD_1IREFSjpvOCzhh2TCdebtBBh99yizuxJ5IdE55c0RxvAvh2dTqXWPSXG4vjs2q5gZYbXHGEmeRKiGpt9GELuA9GEB5dJSspH9nIpQbJvCwJEvEtv7nXgB_pV0Gmbo7k9MFSzORpuApmfnVl7IFU=&quot;,&quot;resendConfirmationUrl&quot;:&quot;\/front\/resend_confirmation_email&quot;,&quot;emailHolder&quot;:&quot;Email&quot;,&quot;usernameHolder&quot;:&quot;Username (6+ characters)&quot;,&quot;passwordHolder&quot;:&quot;Password&quot;,&quot;submitLabel&quot;:&quot;Sign Up&quot;,&quot;gcaptchaExpired&quot;:&quot;Recaptcha expired.&quot;,&quot;or&quot;:&quot;Or&quot;,&quot;signin&quot;:&quot;Log in&quot;,&quot;terms&quot;:&quot;&lt;span&gt;By signing up, you agree to our &lt;\/span&gt;&lt;a href=\&quot;https:\/\/www.pornhub.com\/information#terms\&quot;&gt;Terms and Conditions&lt;\/a&gt;.&quot;,&quot;resend&quot;:&quot;Resend Confirmation Email&quot;,&quot;loginText1&quot;:&quot;Already have an account?&quot;,&quot;loginText2&quot;:&quot;Login&quot;,&quot;loginText3&quot;:&quot;here&quot;,&quot;passStrength&quot;:&quot;Strength:&quot;,&quot;checkPasswordUrl&quot;:&quot;\/api\/v1\/user\/password_challenge&quot;,&quot;backLabel&quot;:&quot;Back&quot;}"
                            dataPageAction= "show"
                            modal="true"
                            simplified-signup="1"
                            notice-url="https://help.pornhub.com/hc/en-us/articles/44854458951571-The-Steps-We-re-Taking-to-Stop-the-Publication-of-CSAM-and-NCM"
                            notice-text="Notice to Users"
                            notice-law-url="https://legalservice.aylo.com/legal/datarequest"
                            notice-law-text="Notice to Law enforcement"
                                                >
                    </v-create-account-form>
                </div>
            </div>
        </div>
        <div class="bodyText">
            <p class="footer-notice" data-i18n-html="page.body"></p>
            <div class="rtaDisclaimerWrapper">
                <a
                        href="https://www.rtalabel.org"
                        rel="noopener nofollow"
                        target="_blank"
                >
                    <div class="rta">
                        <img src="https://ei.phncdn.com/www-static/images/rta-logo-transparent.png?cache=2026052109" alt="RTA logo">
                    </div>
                </a>
            </div>
            <ul class="legalLinks">
                <li><a href="https://www.pornhub.com/information">Terms of Service</a></li>
                <li><a href="https://www.pornhub.com/information/privacy">Privacy Notice</a></li>
                <li><a href="https://www.pornhub.com/information/dmca">DMCA</a></li>
                <li><a href="https://www.pornhub.com/information/dmcaform">DMCA Form</a></li>
                                <li><a href="/support">Support</a></li>
                <li><a href="https://www.pornhub.com/information/2257">2257</a></li>
                <li><a href="/content-removal">Content Removal</a></li>
                <li><a href="https://help.pornhub.com/hc/en-us/articles/4419869793683" target="_blank" rel="nofollow">CSAM Policy</a></li>
                <li><a href="https://help.pornhub.com/hc/en-us/articles/4419871787027" target="_blank" rel="nofollow">NCC Policy</a></li>
                <li><a href="https://help.pornhub.com/hc/en-us" target="_blank" rel="nofollow">Help Center</a></li>
                <li><a href="https://help.pornhub.com/hc/en-us/categories/4419836212499" target="_blank" rel="nofollow">Trust and Safety</a></li>
            </ul>
        </div>
    </div>
</template>

<script>
    
    window.signinI18n = {"pageId":1161,"availableLanguages":{"1":{"id":1,"code":"en","name":"English"}},"selectedLanguage":1,"translatedContent":{"title":"SFW US States","published_at":"2026-03-12 09:44:04","language_name":"English","language_id":1,"language_code":"en","contents":{"page.subtitle":{"id":42,"content":"<p>Access your Pornhub account</p>","name":"page.subtitle","type":2},"label.availability":{"id":483,"content":"<p>Pornhub is not currently accepting new account registrations in your region.</p>","name":"label.availability","type":2},"button.notice_to_user":{"id":484,"content":"Notice to Users","name":"button.notice_to_user","type":1},"button.notice_to_law_enforcement":{"id":485,"content":"Notice to Law enforcement","name":"button.notice_to_law_enforcement","type":1},"page.body":{"id":3,"content":"<p style=\"margin-left:0px;text-align:center;\">Pornhub is dedicated to developing state-of-the-art security features to protect its community. Pornhub is fully <a href=\"https://www.rtalabel.org/\" target=\"_blank\" rel=\"noopener noreferrer\">RTA compliant</a>, which means that devices with appropriately configured parental controls will block access to our content. We encourage all platforms in the adult industry to use this technology, along with all available safety and security protocols. We also recommend that all parents and guardians use technology to prevent their children from accessing content not intended for minors.</p><p style=\"margin-left:0px;text-align:center;\">Our <a href=\"https://help.pornhub.com/hc/en-us/articles/4419885579795\" target=\"_blank\" rel=\"noopener noreferrer\">parental controls page</a> explains how you can easily block access to this site.</p>","name":"page.body","type":2}}},"randomPick":false,"variant":""};

    document.addEventListener('DOMContentLoaded', function () {
        const payload = window.signinI18n;
        if (!payload || typeof payload !== 'object') return;

        const langId = payload.selectedLanguage;
        if (langId === null || langId === undefined) return;

        const translated = payload.translatedContent;
        if (!translated || typeof translated !== 'object') return;

        const contents = translated.contents;
        if (!contents || typeof contents !== 'object' || Array.isArray(contents)) return;

        const dict = {};

        for (const [k, v] of Object.entries(contents)) {
            if (!v || typeof v !== 'object' || typeof v.content !== 'string') continue;
            dict[k] = v.content;
        }

        if (Object.keys(dict).length === 0) return;

        var tries = 0;
        var timer = setInterval(function () {
            tries++;

            var root = typeof signinbox !== 'undefined' && signinbox.container;
            if (!root) return;

            var container = document;
            if (container) {
                applyI18n(container, dict);
                clearInterval(timer);
            }
            if (tries > 50) clearInterval(timer);
        }, 50);
    });

    function applyI18n(root, dict) {
        root.querySelectorAll('[data-i18n-html]').forEach(function(el){
            var key = el.getAttribute('data-i18n-html');
            if (dict[key] != null) el.innerHTML = dict[key];
        });
    }

    if(typeof connectionModalData !== 'undefined'){
        Object.assign(connectionModalData.translations, {
            'toContinue': "To continue, we are required to verify that you are 18 or older, in line with the UK Online Safety Act. <span></span> To view your verification options, please visit our <a href=\"https://help.pornhub.com/hc/en-us/articles/42851050481811-UK-Online-Safety-Act\" target=\"_blank\" rel=\"nofollow\">Age Verification Page</a>. As part of this process, you will be asked to create a new account on Pornhub - this will automatically create a new account on AllpassTrust as well.<span></span> By proceeding, you acknowledge and agree to <a href=\"https://www.pornhub.com/information/privacy\">Pornhub’s</a> and <a href=\"https://www.allpasstrust.com/privacy\" target=\"_blank\" rel=\"nofollow\">AllpassTrust’s</a> Privacy Νotices and <a href=\"https://www.pornhub.com/information\">Pornhub’s</a> and <a href=\"https://www.allpasstrust.com/terms\" target=\"_blank\" rel=\"nofollow\">AllpassTrust’s</a> Terms & Conditions.<span></span>",
            'signupForFreeVerify': "Sign Up for Free to verify your age",
            'pornhubIsDedicated': "Pornhub is dedicated to developing state-of-the-art security features to protect its community. Pornhub is fully <a href=\"https://www.rtalabel.org/\" target=\"_blank\" rel=\"nofollow\" onclick=\"ga('send', 'event', 'Age disclaimer - Germany - step 1', 'click', 'Link - RTA');\">RTA compliant</a>, which means that devices with appropriately configured parental controls will block access to our content. We encourage all platforms in the adult industry to use this technology, along with all available safety and security protocols. We also recommend that all parents and guardians use technology to prevent their children from accessing content not intended for minors.",
            'parentalControl':"Our <a href=\"https://help.pornhub.com/hc/en-us/articles/4419885579795\" target=\"_blank\" rel=\"nofollow\">parental controls page</a> explains how you can easily block access to this site.",
            'rtaLogo': "RTA logo",
            'termsUrl': "https://www.pornhub.com/information",
            'termsLabel': "Terms of Service",
            'privacyUrl': "https://www.pornhub.com/information/privacy",
            'privacyLabel': "Privacy Notice",
            'dmcaUrl': "https://www.pornhub.com/information/dmca",
            'dmcaLabel': "DMCA",
            'dmcaFormUrl': "https://www.pornhub.com/information/dmcaform",
            'dmcaFormLabel': "DMCA Form",
            'eudsaUrl': "https://www.pornhub.com/information/eu_dsa",
            'supportUrl': "/support",
            'supportLabel': "Support",
            'btn2257Url': "https://www.pornhub.com/information/2257",
            'contentRemovalUrl': "/content-removal",
            'contentRemovalLabel': "Content Removal",
            'csamUrl': "https://help.pornhub.com/hc/en-us/articles/4419869793683",
            'csamLabel': "CSAM Policy",
            'nccUrl': "https://help.pornhub.com/hc/en-us/articles/4419871787027",
            'nccLabel': "NCC Policy",
            'helpCenter': "Help Center",
            'trustAndSafety': "Trust and Safety",
            'noticeToUsersUrl': "https://help.pornhub.com/hc/en-us/articles/44854458951571-The-Steps-We-re-Taking-to-Stop-the-Publication-of-CSAM-and-NCM",
            'noticeToUsersLabel': "Notice to Users",
            'noticeToLawUrl': "https://legalservice.aylo.com/legal/datarequest",
            'noticeToLaw': "Notice to Law enforcement",
            'aptFooterText': "<p style=\"margin-left:0px;text-align:center;\">Pornhub is dedicated to developing state-of-the-art security features to protect its community. Pornhub is fully <a href=\"https://www.rtalabel.org/\" target=\"_blank\" rel=\"noopener noreferrer\">RTA compliant</a>, which means that devices with appropriately configured parental controls will block access to our content. We encourage all platforms in the adult industry to use this technology, along with all available safety and security protocols. We also recommend that all parents and guardians use technology to prevent their children from accessing content not intended for minors.</p><p style=\"margin-left:0px;text-align:center;\">Our <a href=\"https://help.pornhub.com/hc/en-us/articles/4419885579795\" target=\"_blank\" rel=\"noopener noreferrer\">parental controls page</a> explains how you can easily block access to this site.</p>",
            'ageGateLegalText': {"pageId":1161,"availableLanguages":{"1":{"id":1,"code":"en","name":"English"}},"selectedLanguage":1,"translatedContent":{"title":"SFW US States","published_at":"2026-03-12 09:44:04","language_name":"English","language_id":1,"language_code":"en","contents":{"page.subtitle":{"id":42,"content":"<p>Access your Pornhub account</p>","name":"page.subtitle","type":2},"label.availability":{"id":483,"content":"<p>Pornhub is not currently accepting new account registrations in your region.</p>","name":"label.availability","type":2},"button.notice_to_user":{"id":484,"content":"Notice to Users","name":"button.notice_to_user","type":1},"button.notice_to_law_enforcement":{"id":485,"content":"Notice to Law enforcement","name":"button.notice_to_law_enforcement","type":1},"page.body":{"id":3,"content":"<p style=\"margin-left:0px;text-align:center;\">Pornhub is dedicated to developing state-of-the-art security features to protect its community. Pornhub is fully <a href=\"https://www.rtalabel.org/\" target=\"_blank\" rel=\"noopener noreferrer\">RTA compliant</a>, which means that devices with appropriately configured parental controls will block access to our content. We encourage all platforms in the adult industry to use this technology, along with all available safety and security protocols. We also recommend that all parents and guardians use technology to prevent their children from accessing content not intended for minors.</p><p style=\"margin-left:0px;text-align:center;\">Our <a href=\"https://help.pornhub.com/hc/en-us/articles/4419885579795\" target=\"_blank\" rel=\"noopener noreferrer\">parental controls page</a> explains how you can easily block access to this site.</p>","name":"page.body","type":2}}},"randomPick":false,"variant":""},
        });
        Object.assign(connectionModalData.configs, {
            'isForEudsa': "",
            'isApt': "true",
            'xSsoButtonHtml': "<span class=\"ssoErrors js-ssoErrors displayNone\"><\/span>\n<div class=\"ssoSignBtns \">\n            <button id=\"ssoGoogleSignupButton\" type=\"button\">\n            <img src=\"https:\/\/ei.phncdn.com\/www-static\/images\/google-sso-icon.svg?cache=2026052109\" alt=\"Google SSO\">\n            <span>Sign up with Google<\/span>\n        <\/button>\n        <button id=\"ssoXSignupButton\" type=\"button\">\n        <i class=\"ph-icon-twitterX\"><\/i>\n        <span>Sign up with X<\/span>\n    <\/button>\n    <\/div>\n<div class=\"separator\">\n    <span class=\"separatorLine\"><\/span>\n    <span class=\"textChoose\">or<\/span>\n<\/div>\n    <div class=\"emailPassSignButton aptOrangeButton js-toggleSignup\">\n        Sign up with email and password    <\/div>\n",
        });
    }
</script>
        
                    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-W32TNJK" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
        
        <div class="wrapper">
            <header itemscope itemtype="http://schema.org/WPHeader" id="header">
    <div id="headerWrapper">
        <div id="headerContainer" class="withCustomPromoBtn">
            <div class="headerContainerColumn">
                <div class="logo pornhub_logo_straight">
                    <div itemscope itemtype="http://schema.org/Organization" class="logoWrapper">
                        <a class="gtm-event-header"
                           data-event="header"
                           data-label="logo"
                           itemprop="url"
                           href="/"
                        >
                            <img
                                itemprop="logo"
                                title="Pornhub"
                                alt="Pornhub Porn Videos"
                                width="150"
                                height="26"
                                src="https://ei.phncdn.com/www-static/images/pornhub_logo_straight.svg?cache=2026052109"
                            />
                        </a>
                    </div>
                </div>
            </div>

            <div class="headerContainerColumn withSearch withCustomPromoBtn">
                <div class="headerSearchWrapper">
                    <form autocomplete="off"
                          id="search_form_sfw">
                        <fieldset class="fs-nf">
                            <div id="searchBarContainer">
                                <div id="btnSearch" role="button" aria-label="Search"><i class="ph-icon-search"></i></div>
                                <label for="search">
                                    <input
                                            id="searchInput"
                                            type="text"
                                            placeholder="Search Pornhub"
                                            maxlength="100"
                                            name="search"
                                            aria-label="Search"
                                            accesskey="?"
                                            autocomplete="off"
                                    />
                                </label>
                                <div id="clearInput" class="hidden">
                                    <span class="ph-icon-cancel"></span>
                                </div>
                                <div id="searchesWrapper" class="hidden">
                                </div>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>

                        <div class="headerContainerColumn">
                <div id="topRightProfileMenu" class="signOut">
                    <button id="sfwSignInBtn">Log In</button>
                </div>
            </div>
        </div>
    </div>

    <div id="headerMenuContainer">
        <div id="headerMainMenuInner">
            <div id="headerCampaignDiv">
                
<ul id="headerMainMenu">
                        
            <li itemprop="name"                id="menuItem1"
                tabindex="0"
                class="menu item-1 home" data-hover="0">
                                    <a itemprop="url"                        data-href="/"
                        href="/"
                        rel=""
                        class="js-topMenuLink"
                        target="_self"
                                                onclick="" >
                        <span class="itemName">Home<span class="activeLine"></span></span>
                    </a>
                                                    </li>
                        
            <li itemprop="name"                id="menuItem2"
                tabindex="0"
                class="menu item-2 videos" data-hover="0">
                                    <a itemprop="url"                        data-href="/video"
                        href="/video"
                        rel=""
                        class="js-topMenuLink"
                        target="_self"
                                                onclick="" >
                        <span class="itemName"><span class="arrowMenu">Porn Videos</span><span class="arrow arrowMenu"></span><span class="activeLine"></span></span>
                    </a>
                                                    </li>
                        
            <li itemprop="name"                id="menuItem3"
                tabindex="0"
                class="menu item-3 categories" data-hover="0">
                                    <a itemprop="url"                        data-href="/categories"
                        href="/categories"
                        rel=""
                        class="js-topMenuLink"
                        target="_self"
                                                onclick="" >
                        <span class="itemName"><span class="arrowMenu">Categories</span><span class="arrow arrowMenu"></span><span class="activeLine"></span></span>
                    </a>
                                                    </li>
                        
            <li itemprop="name"                id="menuItem4"
                tabindex="0"
                class="asyncLoad menu item-4 livesex" data-hover="0">
                                    <a itemprop="url"                        data-href="https://livehdcams.com/lander/v2/previewv3/?AFNO=1-41688&cz=10817"
                        href="https://livehdcams.com/lander/v2/previewv3/?AFNO=1-41688&cz=10817"
                        rel="nofollow"
                        class="js-topMenuLink gtm-event-header-paidtabs js-liveCam"
                        target="_blank"
                                                    data-label="Live Sex Tab"
                            data-label2="Live Cams"
                            data-value="live cams straight"
                                                onclick="" >
                        <span class="itemName"><span class="arrowMenu">LIVE CAMS</span><span class="arrow arrowMenu"></span><span class="activeLine"></span></span>
                    </a>
                                                    </li>
                        
            <li itemprop="name"                id="menuItem5"
                tabindex="0"
                class="menu item-5 pornstar" data-hover="0">
                                    <a itemprop="url"                        data-href="/pornstars"
                        href="/pornstars"
                        rel=""
                        class="js-topMenuLink"
                        target="_self"
                                                onclick="" >
                        <span class="itemName"><span class="arrowMenu">Pornstars</span><span class="arrow arrowMenu"></span><span class="activeLine"></span></span>
                    </a>
                                                    </li>
                        
            <li                 id="menuItem6"
                tabindex="0"
                class="menu item-6 realsex" data-hover="0">
                                    <a                         data-href="https://ads.trafficjunky.net/ads?zone_id=2514881&format=directLP&noc=0"
                        href="https://ads.trafficjunky.net/ads?zone_id=2514881&format=directLP&noc=0"
                        rel="nofollow noopener"
                        class="js-topMenuLink gtm-event-header-paidtabs"
                        target="_blank"
                                                    data-label="Real Sex Tab"
                            data-label2="Fuck Now"
                            data-value="live cams straight"
                                                onclick="" >
                        <span class="itemName">BRAZZERS 4K</span>
                    </a>
                                                    </li>
                        
            <li itemprop="name"                id="menuItem7"
                tabindex="0"
                class="menu item-7 community" data-hover="0">
                                    <a itemprop="url"                        data-href="/community"
                        href="/community"
                        rel=""
                        class="js-topMenuLink"
                        target="_self"
                                                onclick="" >
                        <span class="itemName"><span class="arrowMenu">Community</span><span class="arrow arrowMenu"></span><span class="activeLine"></span></span>
                    </a>
                                                    </li>
                        
            <li itemprop="name"                id="menuItem8"
                tabindex="0"
                class="menu item-8 photos" data-hover="0">
                                    <a itemprop="url"                        data-href="/albums"
                        href="/albums"
                        rel=""
                        class="js-topMenuLink"
                        target="_self"
                                                onclick="" >
                        <span class="itemName"><span class="arrowMenu">Photos & GIFs</span><span class="arrow arrowMenu"></span><span class="activeLine"></span></span>
                    </a>
                                                    </li>
        </ul>

<script>
    var MENU_MAIN_HEADER = {"communityUrl":"\/front\/menu_community?segment=straight&token=MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8.","liveSexUrl":"\/front\/menu_livesex?segment=straight&token=MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8.","photosUrl":"\/front\/menu_photos?segment=straight&token=MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8.","preloadImage":"https:\/\/ei.phncdn.com\/www-static\/images\/ajax-loader-small.gif?cache=2026052109","menuUrl":"\/front\/menu_all_cached?segment=straight&token=MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8."};
</script>
            </div>
        </div>
    </div>
</header>

            <div class="container">
                <div id="main-container" class="clearfix vpContainer">
    <script type="text/javascript">
        var VIDEO_SHOW = {};

        // Variable Object
        var isUtah = 0,
            isVideoPage = 1,
            isShowPage = 1,
            isVr = false,
            playerSource = 'videoPage',
            relatedVideos = [{"fields":{"id":475880815,"user_id":3157729341,"vkey":"68efa01cbbcb5","title":"EP8 Jasmine Banks | The Most Unexpected Feet Request Ever \ud83d\ude33","segment":1,"duration":1408,"privacy":"public","production":"professional","status":"active","show_bars":1,"approved_on":1760681415,"community_on":1760534854,"queued_on":0,"media_path":"\/202510\/15\/26380165\/","featured_on":0,"hq_vkey":221,"site_id":69525,"community_flag":1,"community_concern":2,"community_concern_date":"2025-10-16 13:47:06","thumb":0,"thumb_offset":0,"language":0,"hd":1,"is_me":0,"content_level":3,"geo_zone_id":0,"active_category":0,"premium":0,"white_label":0,"is_paid":"no","is_paid_view":"no","ip_address":1666855533},"errors":[],"fieldsChanged":[],"isVertical":null,"_streamingMediaHashedForIp":false,"_useCDNOptimizer":false,"contentVideoTypes":null,"icons":null},{"fields":{"id":444854471,"user_id":33474411,"vkey":"657cfaef0edc3","title":"Emma Rose: Getting Becoming a Top & Dating as a Trans Porn Star!","segment":41,"duration":2872,"privacy":"public","production":"professional","status":"active","show_bars":1,"approved_on":1707038416,"community_on":1706529602,"queued_on":0,"media_path":"\/202312\/16\/444854471\/","featured_on":0,"hq_vkey":83,"site_id":42091,"community_flag":1,"community_concern":2,"community_concern_date":"2024-10-09 17:14:38","thumb":0,"thumb_offset":0,"language":0,"hd":1,"is_me":0,"content_level":3,"geo_zone_id":0,"active_category":0,"premium":0,"white_label":0,"is_paid":"no","is_paid_view":"no","ip_address":1278390495},"errors":[],"fieldsChanged":[],"isVertical":null,"_streamingMediaHashedForIp":false,"_useCDNOptimizer":false,"contentVideoTypes":null,"icons":null},{"fields":{"id":222159451,"user_id":632615272,"vkey":"ph5cd030d434130","title":"I Disagree With The Ads Around This Video, Your Penis Size is Fine As Is","segment":1,"duration":11,"privacy":"public","production":"homemade","status":"active","show_bars":0,"approved_on":1594702584,"community_on":1557148495,"queued_on":0,"media_path":"\/201905\/06\/222159451\/","featured_on":0,"hq_vkey":221,"site_id":0,"community_flag":1,"community_concern":2,"community_concern_date":"2022-06-02 04:10:11","thumb":15,"thumb_offset":0,"language":0,"hd":1,"is_me":2,"content_level":3,"geo_zone_id":0,"active_category":1,"premium":0,"white_label":0,"is_paid":"no","is_paid_view":"no","ip_address":null},"errors":[],"fieldsChanged":[],"isVertical":null,"_streamingMediaHashedForIp":false,"_useCDNOptimizer":false,"contentVideoTypes":null,"icons":null},{"fields":{"id":303973002,"user_id":1563667141,"vkey":"ph5e971259d2a46","title":"See what Asa Akira does In the Kitchen! U WON'T BELIEVE IT","segment":1,"duration":177,"privacy":"public","production":"professional","status":"active","show_bars":0,"approved_on":1588545012,"community_on":1586959355,"queued_on":0,"media_path":"\/202004\/15\/303973002\/","featured_on":0,"hq_vkey":221,"site_id":53952,"community_flag":1,"community_concern":2,"community_concern_date":"2025-06-03 00:32:44","thumb":1,"thumb_offset":0,"language":0,"hd":1,"is_me":0,"content_level":3,"geo_zone_id":0,"active_category":0,"premium":0,"white_label":0,"is_paid":"no","is_paid_view":"no","ip_address":null},"errors":[],"fieldsChanged":[],"isVertical":null,"_streamingMediaHashedForIp":false,"_useCDNOptimizer":false,"contentVideoTypes":null,"icons":null},{"fields":{"id":478984625,"user_id":33474411,"vkey":"694b621d9be47","title":"Inside Sadie Summers: Confidence, Controversy & Saying What Everyone Else Won\u2019t","segment":1,"duration":3619,"privacy":"public","production":"professional","status":"active","show_bars":1,"approved_on":1772691008,"community_on":1771804802,"queued_on":0,"media_path":"\/202512\/24\/33649475\/","featured_on":0,"hq_vkey":221,"site_id":42091,"community_flag":1,"community_concern":2,"community_concern_date":"2026-02-27 15:40:13","thumb":0,"thumb_offset":0,"language":0,"hd":1,"is_me":0,"content_level":3,"geo_zone_id":0,"active_category":0,"premium":0,"white_label":0,"is_paid":"no","is_paid_view":"no","ip_address":1277230259},"errors":[],"fieldsChanged":[],"isVertical":null,"_streamingMediaHashedForIp":false,"_useCDNOptimizer":false,"contentVideoTypes":null,"icons":null},{"fields":{"id":431238401,"user_id":33474411,"vkey":"645ab8c01b680","title":"Lisa Ann: A Side of Her You've Never Seen","segment":1,"duration":4352,"privacy":"public","production":"professional","status":"active","show_bars":1,"approved_on":1769519413,"community_on":1683671634,"queued_on":0,"media_path":"\/202305\/10\/431238401\/","featured_on":0,"hq_vkey":221,"site_id":42091,"community_flag":1,"community_concern":2,"community_concern_date":"2026-01-21 18:43:05","thumb":0,"thumb_offset":0,"language":0,"hd":1,"is_me":0,"content_level":3,"geo_zone_id":0,"active_category":0,"premium":0,"white_label":0,"is_paid":"no","is_paid_view":"no","ip_address":416104269},"errors":[],"fieldsChanged":[],"isVertical":null,"_streamingMediaHashedForIp":false,"_useCDNOptimizer":false,"contentVideoTypes":null,"icons":null},{"fields":{"id":481431655,"user_id":3157729341,"vkey":"6995f6d931389","title":"EP26 | Nobody Tells You This About Being a Content Creator","segment":1,"duration":696,"privacy":"public","production":"professional","status":"active","show_bars":1,"approved_on":1771947011,"community_on":1771524004,"queued_on":0,"media_path":"\/202602\/18\/39724955\/","featured_on":0,"hq_vkey":221,"site_id":69525,"community_flag":1,"community_concern":2,"community_concern_date":"2026-02-24 13:24:37","thumb":0,"thumb_offset":0,"language":0,"hd":1,"is_me":0,"content_level":3,"geo_zone_id":0,"active_category":0,"premium":0,"white_label":0,"is_paid":"no","is_paid_view":"no","ip_address":3379322776},"errors":[],"fieldsChanged":[],"isVertical":null,"_streamingMediaHashedForIp":false,"_useCDNOptimizer":false,"contentVideoTypes":null,"icons":null},{"fields":{"id":472968245,"user_id":33474411,"vkey":"6897d7fc3a657","title":"Charlotte Sins Gets Real: From Her Wildest Scenes to Her Life Off-Camera","segment":1,"duration":4027,"privacy":"public","production":"professional","status":"active","show_bars":1,"approved_on":1759650618,"community_on":1757980803,"queued_on":0,"media_path":"\/202508\/09\/18766065\/","featured_on":0,"hq_vkey":221,"site_id":42091,"community_flag":1,"community_concern":2,"community_concern_date":"2025-10-03 15:27:50","thumb":0,"thumb_offset":0,"language":0,"hd":1,"is_me":0,"content_level":3,"geo_zone_id":0,"active_category":0,"premium":0,"white_label":0,"is_paid":"no","is_paid_view":"no","ip_address":1277230259},"errors":[],"fieldsChanged":[],"isVertical":null,"_streamingMediaHashedForIp":false,"_useCDNOptimizer":false,"contentVideoTypes":null,"icons":null},{"fields":{"id":480809265,"user_id":3157729341,"vkey":"69835e94c61db","title":"EP 24 MadeByHarry | Why NIGHT is Prime Time for Music Producers","segment":1,"duration":1318,"privacy":"public","production":"professional","status":"active","show_bars":1,"approved_on":1770407424,"community_on":1770314408,"queued_on":0,"media_path":"\/202602\/04\/38337715\/","featured_on":0,"hq_vkey":221,"site_id":69525,"community_flag":1,"community_concern":2,"community_concern_date":"2026-02-06 15:23:28","thumb":0,"thumb_offset":0,"language":0,"hd":1,"is_me":0,"content_level":3,"geo_zone_id":0,"active_category":0,"premium":0,"white_label":0,"is_paid":"no","is_paid_view":"no","ip_address":1238137019},"errors":[],"fieldsChanged":[],"isVertical":null,"_streamingMediaHashedForIp":false,"_useCDNOptimizer":false,"contentVideoTypes":null,"icons":null},{"fields":{"id":154536052,"user_id":1058918,"vkey":"ph5a83172ce5a31","title":"Happy Valentines Day From Pornhub Premium!","segment":1,"duration":31,"privacy":"public","production":"professional","status":"active","show_bars":1,"approved_on":1518558731,"community_on":1518540650,"queued_on":0,"media_path":"\/201802\/13\/154536052\/","featured_on":0,"hq_vkey":221,"site_id":34402,"community_flag":2,"community_concern":2,"community_concern_date":"2025-05-05 15:50:46","thumb":8,"thumb_offset":0,"language":0,"hd":1,"is_me":0,"content_level":3,"geo_zone_id":0,"active_category":0,"premium":0,"white_label":0,"is_paid":"no","is_paid_view":"no","ip_address":null},"errors":[],"fieldsChanged":[],"isVertical":null,"_streamingMediaHashedForIp":false,"_useCDNOptimizer":false,"contentVideoTypes":null,"icons":null},{"fields":{"id":479237995,"user_id":2706155571,"vkey":"6953f4a2191b0","title":"ALINA LOPEZ EXPOSED FOR CHEATING ON RYAN | LIE DETECOR TEST W\/ VIKING BARBIE","segment":1,"duration":4179,"privacy":"public","production":"professional","status":"active","show_bars":1,"approved_on":1767640216,"community_on":1767115189,"queued_on":0,"media_path":"\/202512\/30\/34298205\/","featured_on":0,"hq_vkey":221,"site_id":68351,"community_flag":1,"community_concern":2,"community_concern_date":"2026-01-05 16:49:44","thumb":0,"thumb_offset":0,"language":0,"hd":1,"is_me":0,"content_level":3,"geo_zone_id":0,"active_category":0,"premium":0,"white_label":0,"is_paid":"no","is_paid_view":"no","ip_address":1746687340},"errors":[],"fieldsChanged":[],"isVertical":null,"_streamingMediaHashedForIp":false,"_useCDNOptimizer":false,"contentVideoTypes":null,"icons":null},{"fields":{"id":249642651,"user_id":1058918,"vkey":"ph5d84d9d2be911","title":"Going Deep with Aria - Alien Searches","segment":1,"duration":116,"privacy":"public","production":"professional","status":"active","show_bars":1,"approved_on":1576933815,"community_on":1568987720,"queued_on":0,"media_path":"\/201909\/20\/249642651\/","featured_on":0,"hq_vkey":221,"site_id":7091,"community_flag":1,"community_concern":2,"community_concern_date":"2025-05-14 14:33:26","thumb":4,"thumb_offset":0,"language":0,"hd":1,"is_me":0,"content_level":3,"geo_zone_id":0,"active_category":0,"premium":0,"white_label":0,"is_paid":"no","is_paid_view":"no","ip_address":null},"errors":[],"fieldsChanged":[],"isVertical":null,"_streamingMediaHashedForIp":false,"_useCDNOptimizer":false,"contentVideoTypes":null,"icons":null},{"fields":{"id":300469722,"user_id":1563667141,"vkey":"ph5e89c34c13e58","title":"Goes Slow in His Afternoon\u00a0","segment":1,"duration":310,"privacy":"public","production":"homemade","status":"active","show_bars":0,"approved_on":1608175810,"community_on":1586086849,"queued_on":0,"media_path":"\/202004\/05\/300469722\/","featured_on":0,"hq_vkey":221,"site_id":53952,"community_flag":1,"community_concern":2,"community_concern_date":"2025-09-17 21:48:38","thumb":10,"thumb_offset":0,"language":0,"hd":1,"is_me":0,"content_level":3,"geo_zone_id":0,"active_category":0,"premium":0,"white_label":0,"is_paid":"no","is_paid_view":"no","ip_address":null},"errors":[],"fieldsChanged":[],"isVertical":null,"_streamingMediaHashedForIp":false,"_useCDNOptimizer":false,"contentVideoTypes":null,"icons":null},{"fields":{"id":215094362,"user_id":1058918,"vkey":"ph5c9a5362c61c6","title":"PYFT - Episode 3 with Dana DeArmond and Abella Danger","segment":1,"duration":324,"privacy":"public","production":"professional","status":"active","show_bars":1,"approved_on":1553865013,"community_on":1553617898,"queued_on":0,"media_path":"\/201903\/26\/215094362\/","featured_on":0,"hq_vkey":221,"site_id":7091,"community_flag":1,"community_concern":2,"community_concern_date":"2019-03-29 13:00:53","thumb":5,"thumb_offset":0,"language":0,"hd":1,"is_me":0,"content_level":3,"geo_zone_id":0,"active_category":0,"premium":0,"white_label":0,"is_paid":"no","is_paid_view":"no","ip_address":null},"errors":[],"fieldsChanged":[],"isVertical":null,"_streamingMediaHashedForIp":false,"_useCDNOptimizer":false,"contentVideoTypes":null,"icons":null},{"fields":{"id":297410511,"user_id":189697611,"vkey":"ph5e7e454490a71","title":"BANG Surprise Podcast #1 With Sara Jay","segment":1,"duration":1695,"privacy":"public","production":"professional","status":"active","show_bars":0,"approved_on":1585669814,"community_on":1585663214,"queued_on":0,"media_path":"\/202003\/27\/297410511\/","featured_on":0,"hq_vkey":221,"site_id":31841,"community_flag":1,"community_concern":2,"community_concern_date":"2021-06-17 15:06:07","thumb":9,"thumb_offset":0,"language":0,"hd":1,"is_me":0,"content_level":3,"geo_zone_id":0,"active_category":0,"premium":0,"white_label":0,"is_paid":"no","is_paid_view":"no","ip_address":null},"errors":[],"fieldsChanged":[],"isVertical":null,"_streamingMediaHashedForIp":false,"_useCDNOptimizer":false,"contentVideoTypes":null,"icons":null},{"fields":{"id":124932801,"user_id":1058918,"vkey":"ph596e113baf1a0","title":"Pornhub Cares Presents Nina Hartley\u2019s Old School: A Guide to 65+ Safe Sex","segment":1,"duration":908,"privacy":"public","production":"professional","status":"active","show_bars":1,"approved_on":1500565826,"community_on":1500385733,"queued_on":0,"media_path":"\/201707\/18\/124932801\/","featured_on":0,"hq_vkey":221,"site_id":26151,"community_flag":1,"community_concern":2,"community_concern_date":"2017-07-20 15:47:08","thumb":0,"thumb_offset":0,"language":0,"hd":1,"is_me":0,"content_level":3,"geo_zone_id":0,"active_category":0,"premium":0,"white_label":0,"is_paid":"no","is_paid_view":"no","ip_address":null},"errors":[],"fieldsChanged":[],"isVertical":null,"_streamingMediaHashedForIp":false,"_useCDNOptimizer":false,"contentVideoTypes":null,"icons":null},{"fields":{"id":475656465,"user_id":3157729341,"vkey":"68e92abfc0012","title":"EP7 | Reacting to the Wildest Comments from My PornHub Fans \ud83d\ude33","segment":1,"duration":971,"privacy":"public","production":"professional","status":"active","show_bars":1,"approved_on":1760471426,"community_on":1760111367,"queued_on":0,"media_path":"\/202510\/10\/25837715\/","featured_on":0,"hq_vkey":221,"site_id":69525,"community_flag":1,"community_concern":2,"community_concern_date":"2025-10-14 15:46:00","thumb":0,"thumb_offset":0,"language":0,"hd":1,"is_me":0,"content_level":3,"geo_zone_id":0,"active_category":0,"premium":0,"white_label":0,"is_paid":"no","is_paid_view":"no","ip_address":1666855533},"errors":[],"fieldsChanged":[],"isVertical":null,"_streamingMediaHashedForIp":false,"_useCDNOptimizer":false,"contentVideoTypes":null,"icons":null},{"fields":{"id":478965815,"user_id":2706155571,"vkey":"694abb86bfbca","title":"RACHEL W\/ TOURETTES ON PILLOW TALK","segment":1,"duration":3361,"privacy":"public","production":"professional","status":"active","show_bars":1,"approved_on":1767024622,"community_on":1766509589,"queued_on":0,"media_path":"\/202512\/23\/33602905\/","featured_on":0,"hq_vkey":221,"site_id":68351,"community_flag":1,"community_concern":2,"community_concern_date":"2025-12-29 16:02:46","thumb":0,"thumb_offset":0,"language":0,"hd":1,"is_me":0,"content_level":3,"geo_zone_id":0,"active_category":0,"premium":0,"white_label":0,"is_paid":"no","is_paid_view":"no","ip_address":1746687341},"errors":[],"fieldsChanged":[],"isVertical":null,"_streamingMediaHashedForIp":false,"_useCDNOptimizer":false,"contentVideoTypes":null,"icons":null},{"fields":{"id":315505791,"user_id":189697611,"vkey":"ph5ec4065f34e4e","title":"BANG! Ask Me Anything With Alina Lopez","segment":1,"duration":2437,"privacy":"public","production":"professional","status":"active","show_bars":0,"approved_on":1590161411,"community_on":1589905251,"queued_on":0,"media_path":"\/202005\/19\/315505791\/","featured_on":0,"hq_vkey":221,"site_id":33022,"community_flag":1,"community_concern":2,"community_concern_date":"2020-06-30 00:29:07","thumb":9,"thumb_offset":0,"language":0,"hd":1,"is_me":0,"content_level":3,"geo_zone_id":0,"active_category":0,"premium":0,"white_label":0,"is_paid":"no","is_paid_view":"no","ip_address":1387316678},"errors":[],"fieldsChanged":[],"isVertical":null,"_streamingMediaHashedForIp":false,"_useCDNOptimizer":false,"contentVideoTypes":null,"icons":null},{"fields":{"id":474562265,"user_id":33474411,"vkey":"68c8aa0bca3cb","title":"Holly Johnston on Leaving the Mormon Church for OnlyFans Fame","segment":1,"duration":3880,"privacy":"public","production":"professional","status":"active","show_bars":1,"approved_on":1759743020,"community_on":1757981438,"queued_on":0,"media_path":"\/202509\/16\/22852325\/","featured_on":0,"hq_vkey":221,"site_id":42091,"community_flag":1,"community_concern":2,"community_concern_date":"2025-10-03 15:20:56","thumb":0,"thumb_offset":0,"language":0,"hd":1,"is_me":0,"content_level":3,"geo_zone_id":0,"active_category":0,"premium":0,"white_label":0,"is_paid":"no","is_paid_view":"no","ip_address":1277230259},"errors":[],"fieldsChanged":[],"isVertical":null,"_streamingMediaHashedForIp":false,"_useCDNOptimizer":false,"contentVideoTypes":null,"icons":null}];
    </script>

    <div id="vpContentContainer">
        <div id="hd-leftColVideoPage">
            <div class="topSectionGrid">
                <div class="videoWrapModelInfo">
                    <div class="video-wrapper modelInfo">
                                                <div id="player" class="original mainPlayerDiv" data-video-id="474848195">
                                                                                        
<script type="text/javascript">
				var flashvars_474848195 = {"isVR":0,"experimentId":"experimentId unknown","searchEngineData":null,"maxInitialBufferLength":1,"disable_sharebar":0,"htmlPauseRoll":"true","htmlPostRoll":"false","autoplay":"true","autoreplay":"false","video_unavailable":"false","pauseroll_url":"","postroll_url":"","toprated_url":"https:\/\/www.pornhub.com\/video?o=tr&t=m","mostviewed_url":"https:\/\/www.pornhub.com\/video?o=mv&t=m","language":"en","isp":"microsoft azure","geo":"united states","customLogo":"https:\/\/ei.phncdn.com\/www-static\/images\/pornhub_logo_straight.svg?cache=2026052109","trackingTimeWatched":false,"tubesCmsPrerollConfigType":"new","adRollGlobalConfig":[{"delay":[900,2000,3000],"forgetUserAfter":1,"onNth":0,"skipDelay":4,"skippable":true,"vastSkipDelay":false,"json":"https:\/\/www.pornhub.com\/_xa\/ads?zone_id=2514921&site_id=2&preroll_type=json&channel%5Bcontext_tag%5D=interview%2Cfresh-out-of-jail%2Clexis-star%2Cteddy-tarantino%2Cmodels%2Camateur%2Ctalking%2Cadult-content%2Ctherapy%2Cproblems%2Clexi-star-show%2Cjerkmate%2Cconversation&channel%5Bcontext_category%5D=Celebrity%2CSFW%2CPodcast&channel%5Bcontext_pornstar%5D=&channel%5Binfo%5D=%7B%22actor_id%22%3A3157729341%2C%22content_type%22%3A%22partner%22%2C%22video_id%22%3A474848195%2C%22timestamp%22%3A1779558241%2C%22hash%22%3A%22e042778aac41f5606484d5382f1e17a1%22%2C%22session_id%22%3A%22922983257888595140%22%7D&noc=0&cache=1779558241&t_version=2026052109.ded8422&channel%5Bsite%5D=pornhub","user_accept_language":"","startPoint":0,"maxVideoTimeout":2000},{"delay":[900,2000,3000],"forgetUserAfter":1,"onNth":0,"skipDelay":4,"skippable":true,"vastSkipDelay":false,"json":"https:\/\/www.pornhub.com\/_xa\/ads?zone_id=2514921&site_id=2&preroll_type=json&channel%5Bcontext_tag%5D=interview%2Cfresh-out-of-jail%2Clexis-star%2Cteddy-tarantino%2Cmodels%2Camateur%2Ctalking%2Cadult-content%2Ctherapy%2Cproblems%2Clexi-star-show%2Cjerkmate%2Cconversation&channel%5Bcontext_category%5D=Celebrity%2CSFW%2CPodcast&channel%5Bcontext_pornstar%5D=&channel%5Binfo%5D=%7B%22actor_id%22%3A3157729341%2C%22content_type%22%3A%22partner%22%2C%22video_id%22%3A474848195%2C%22timestamp%22%3A1779558241%2C%22hash%22%3A%22e042778aac41f5606484d5382f1e17a1%22%2C%22session_id%22%3A%22922983257888595140%22%7D&noc=0&cache=1779558241&t_version=2026052109.ded8422&channel%5Bsite%5D=pornhub","user_accept_language":"","startPoint":100,"maxVideoTimeout":2000}],"embedCode":"<iframe src=\"https:\/\/www.pornhub.com\/embed\/68d18a4de7806\" frameborder=\"0\" width=\"560\" height=\"340\" scrolling=\"no\" allowfullscreen><\/iframe>","hidePostPauseRoll":false,"isHD":"true","video_duration":3091,"actionTags":"","link_url":"https:\/\/www.pornhub.com\/view_video.php?viewkey=68d18a4de7806","related_url":"https:\/\/www.pornhub.com\/api\/v1\/video\/player_related_datas?id=474848195","video_title":"EP5 Part 2 Teddy Tarantino | Jail Talks To 200 Employees!","image_url":"https:\/\/pix-cdn77.phncdn.com\/c6251\/videos\/202509\/22\/23608935\/original\/019986c1-5734-7796-8f71-b4d7171ec603.jpg\/plain\/rs:fit:640:360?hash=lCHkskUWwvAHQdFaEL-Ktbl6wF4=&validto=1779644641","defaultQuality":[720,480,240,1080],"vcServerUrl":"\/svvt\/add?stype=svv&svalue=474848195&snonce=rj2hvwwwfv3zq151&skey=01ccc662a94366a07bb8f3c581258c73078a8c80035059a337ec07ef6491bd41&stime=1779558241","service":"tubes_cdn_service,protrack","mediaPriority":"hls","mediaDefinitions":[{"group":1,"height":1080,"width":1920,"defaultQuality":false,"format":"hls","videoUrl":"https:\/\/ev-h.phncdn.com\/hls\/c6251\/videos\/202509\/22\/23608935\/1080P_4000K_23608935.mp4\/master.m3u8?validfrom=1779554641&validto=1779561841&ipa=1&hdl=-1&hash=8dbHh%2Bi67XfGQmzKHyJvxcatH64%3D","quality":"1080","segmentFormats":{"audio":"ts_aac","video":"mpeg2_ts"}},{"group":1,"height":240,"width":426,"defaultQuality":false,"format":"hls","videoUrl":"https:\/\/ev-h.phncdn.com\/hls\/c6251\/videos\/202509\/22\/23608935\/240P_1000K_23608935.mp4\/master.m3u8?validfrom=1779554641&validto=1779561841&ipa=1&hdl=-1&hash=25e0ce2l2wLuPhkOO%2FpIcTPp7Us%3D","quality":"240","segmentFormats":{"audio":"ts_aac","video":"mpeg2_ts"}},{"group":1,"height":480,"width":854,"defaultQuality":false,"format":"hls","videoUrl":"https:\/\/ev-h.phncdn.com\/hls\/c6251\/videos\/202509\/22\/23608935\/480P_2000K_23608935.mp4\/master.m3u8?validfrom=1779554641&validto=1779561841&ipa=1&hdl=-1&hash=lFb%2FtVBuw%2FCW%2FWjTl2Fqr5Q1Sj8%3D","quality":"480","segmentFormats":{"audio":"ts_aac","video":"mpeg2_ts"}},{"group":1,"height":720,"width":1280,"defaultQuality":true,"format":"hls","videoUrl":"https:\/\/ev-h.phncdn.com\/hls\/c6251\/videos\/202509\/22\/23608935\/720P_4000K_23608935.mp4\/master.m3u8?validfrom=1779554641&validto=1779561841&ipa=1&hdl=-1&hash=uQcN1Wsvba%2BmASwb1%2FBgpOhhU8k%3D","quality":"720","segmentFormats":{"audio":"ts_aac","video":"mpeg2_ts"}},{"group":1,"height":2160,"width":3840,"defaultQuality":false,"format":"mp4","videoUrl":"https:\/\/www.pornhub.com\/video\/get_media?s=eyJrIjoiNzYyYzY1YTBhMmUwYmNmMGRhY2Y3YTdlOTY0YzVkOGFkZDMxOWIzMjEwZDBjMjNlNzIxYzE3OGE4Mjk5NmQ5NSIsInQiOjE3Nzk1NTgyNDF9&v=68d18a4de7806&e=0&t=p","quality":[],"remote":true}],"isVertical":"false","video_unavailable_country":"false","mp4_seek":"ms","hotspots":[225,137,123,114,111,113,111,112,108,111,115,111,109,113,112,114,109,99,89,79,73,70,65,60,55,49,49,43,46,42,43,40,35,33,35,35,34,35,34,32,31,31,30,29,30,29,29,27,27,28,27,27,24,25,23,23,22,19,18,21,23,24,21,21,19,19,20,21,27,25,24,23,24,23,26,25,25,26,23,22,23,23,24,24,82,20,20,21,20,20,19,18,17,17,14,18,17,15,15,18,19,18,15,13,13,16,15,15,16,16,16,16,18,21,16,14,12,13,12,12,14,10,11,11,11,13,12,13,12,12,12,11,13,14,13,13,14,13,12,13,13,16,16,14,15,15,16,17,17,14,14,13,15,16,15,14,14,13,16,17,17,17,15,19,14,14,14,14,15,12,13,12,13,18,21,23,25,23,22,19,18,19,19,23,17,17,19,15,14,17,16,14,14,13,17,17,19,18,22,24,26,23,20,18,20,18],"thumbs":{"samplingFrequency":9,"type":"normal","cdnType":"regular","isVault":1,"urlPattern":"","spritePatterns":["https:\/\/pix-cdn77.phncdn.com\/c6371\/videos\/202509\/22\/23608935\/original_23608935.mp4\/plain\/rs:fill:800:450\/vtt:9:5:5:160:90\/vts:0?hash=GXQiYHxaW_4ejFZ21GOMXeIbDdQ=&validto=1779561841","https:\/\/pix-cdn77.phncdn.com\/c6371\/videos\/202509\/22\/23608935\/original_23608935.mp4\/plain\/rs:fill:800:450\/vtt:9:5:5:160:90\/vts:225?hash=bGs8RpUG4O0co9rG3NwBjzFPjNo=&validto=1779561841","https:\/\/pix-fl.phncdn.com\/c6371\/videos\/202509\/22\/23608935\/original_23608935.mp4\/plain\/rs:fill:800:450\/vtt:9:5:5:160:90\/vts:450?hdnea=st=1779558241~exp=1779644641~hdl=-1~hmac=b07c77f0213f43223e1bec472374578c891d7cff","https:\/\/pix-fl.phncdn.com\/c6371\/videos\/202509\/22\/23608935\/original_23608935.mp4\/plain\/rs:fill:800:450\/vtt:9:5:5:160:90\/vts:675?hdnea=st=1779558241~exp=1779644641~hdl=-1~hmac=b07c77f0213f43223e1bec472374578c891d7cff","https:\/\/pix-cdn77.phncdn.com\/c6371\/videos\/202509\/22\/23608935\/original_23608935.mp4\/plain\/rs:fill:800:450\/vtt:9:5:5:160:90\/vts:900?hash=kxhq8wxaGp40Tpwvfq3WMIimr9I=&validto=1779561841","https:\/\/pix-fl.phncdn.com\/c6371\/videos\/202509\/22\/23608935\/original_23608935.mp4\/plain\/rs:fill:800:450\/vtt:9:5:5:160:90\/vts:1125?hdnea=st=1779558241~exp=1779644641~hdl=-1~hmac=b07c77f0213f43223e1bec472374578c891d7cff","https:\/\/pix-cdn77.phncdn.com\/c6371\/videos\/202509\/22\/23608935\/original_23608935.mp4\/plain\/rs:fill:800:450\/vtt:9:5:5:160:90\/vts:1350?hash=zHhK0tcJEkLgXZR-l8GuAps8xkQ=&validto=1779561841","https:\/\/pix-cdn77.phncdn.com\/c6371\/videos\/202509\/22\/23608935\/original_23608935.mp4\/plain\/rs:fill:800:450\/vtt:9:5:5:160:90\/vts:1575?hash=UD-zLtqKdvRogebblWlIbuLHS0Y=&validto=1779561841","https:\/\/pix-cdn77.phncdn.com\/c6371\/videos\/202509\/22\/23608935\/original_23608935.mp4\/plain\/rs:fill:800:450\/vtt:9:5:5:160:90\/vts:1800?hash=HPLkowUR3YlBJ8sdYajp7S3rmaM=&validto=1779561841","https:\/\/pix-cdn77.phncdn.com\/c6371\/videos\/202509\/22\/23608935\/original_23608935.mp4\/plain\/rs:fill:800:450\/vtt:9:5:5:160:90\/vts:2025?hash=O73f2Q1drG5b2Y0s0WjgRAtTZZM=&validto=1779561841","https:\/\/pix-fl.phncdn.com\/c6371\/videos\/202509\/22\/23608935\/original_23608935.mp4\/plain\/rs:fill:800:450\/vtt:9:5:5:160:90\/vts:2250?hdnea=st=1779558241~exp=1779644641~hdl=-1~hmac=b07c77f0213f43223e1bec472374578c891d7cff","https:\/\/pix-fl.phncdn.com\/c6371\/videos\/202509\/22\/23608935\/original_23608935.mp4\/plain\/rs:fill:800:450\/vtt:9:5:5:160:90\/vts:2475?hdnea=st=1779558241~exp=1779644641~hdl=-1~hmac=b07c77f0213f43223e1bec472374578c891d7cff","https:\/\/pix-fl.phncdn.com\/c6371\/videos\/202509\/22\/23608935\/original_23608935.mp4\/plain\/rs:fill:800:450\/vtt:9:5:5:160:90\/vts:2700?hdnea=st=1779558241~exp=1779644641~hdl=-1~hmac=b07c77f0213f43223e1bec472374578c891d7cff","https:\/\/pix-fl.phncdn.com\/c6371\/videos\/202509\/22\/23608935\/original_23608935.mp4\/plain\/rs:fill:800:450\/vtt:9:5:5:160:90\/vts:2925?hdnea=st=1779558241~exp=1779644641~hdl=-1~hmac=b07c77f0213f43223e1bec472374578c891d7cff"],"thumbHeight":"90","thumbWidth":"160"},"options":"show","cdn":"haproxy","startLagThreshold":1000,"outBufferLagThreshold":2000,"appId":"1111","cdnProvider":"ht","nextVideo":{"thumb":"https:\/\/ei.phncdn.com\/videos\/202309\/05\/438839841\/original\/(m=qOI9JYYbecuKGgaaaa)(mh=gSzKqNstxtTvSX0y)0.jpg","duration":614,"title":"RICKYSROOM Love in an Ellevator with Elle Brooke","isHD":1,"nextUrl":"\/view_video.php?viewkey=64f78b271b815","vkey":"64f78b271b815","isJoinPageEntry":false,"channelTitle":"Rickys Room","views":"7M","viewsText":"views","rating":86,"uploaderLink":"<a href=\"\/channels\/rickys-room\" class=\"bolded\">Rickys Room<\/a>","badge":"channel-icon"},"chromecast":true,"autoFullscreen":true};
		var player_mp4_seek = "ms";

		var nextVideoPlaylistObject = flashvars_474848195['nextVideo'];
		playerObjList.playerDiv_474848195 = {
		'flashvars'	: {"embedId":474848195},
		'embedSWF'	: {"url":"https:\/\/ei.phncdn.com\/www-static\/flash\/","element":"playerDiv_474848195","width":"100%","height":"100%","version":"9.0.0"}	};
	
        </script>
    
                <div class="video-element-wrapper-js">
                <div
                    id="playerDiv_474848195"
                    class="playerFlvContainer"
                    data-enlarge="1"
                    data-showautoplayoption="1"
                    data-share="1"
                    data-currenttime="0"
                    data-shownextvideooption=""
                    data-platform="desktop"
                    data-platformfallback="desktop"
                >
                    <video style="width:100%; height:100%;" controls="controls" autobuffer="autobuffer" class="player-html5" preload="metadata"  >
                        <source src="" type="video/mp4">
                    </video>

                    <noscript>
                                                    <img
                                    src="https://pix-fl.phncdn.com/c6251/videos/202509/22/23608935/original/019986c1-5734-7796-8f71-b4d7171ec603.jpg/plain/rs:fit:320:180?hdnea=st=1779558241~exp=1779644641~hdl=-1~hmac=1581d7e6eac84d59406784526e61d8ddaa5dc4ec"
                                    class="videoElementPoster"
                                    width="320"
                                    height="180"
                                    alt="Video poster"/>
                                            </noscript>
                </div>
            </div>
                            <script>const PLAYER_SHOW_NEXT_BUTTON = true;</script>

<script>
    /**
     * Timer object to assist pinging
     * @method timer
     * @param callback {function} callback function
     * @param delay {int} millis to be applied as delay
     * @param id arguments to be passed to the setTimeout callback
     * @constructor
     */
    var Timer = function(callback, delay, id) {
        var timerId,
            start,
            remaining = delay,
            alternatingFlag; // prevent the change of 'remaining' var if 'pause' was hit 2 times consecutively (as in case of 'pause' and 'seek')

        this.pause = function() {
            window.clearTimeout(timerId);
            if(!alternatingFlag) {
                remaining -= Date.now() - start;
            }
            alternatingFlag = true;
        };

        this.resume = function() {
            start = Date.now();
            window.clearTimeout(timerId);
            timerId = window.setTimeout(callback, remaining, id);
            alternatingFlag = false;
        };

        this.resume();
    };

    /**
     * Common function used to provide data to player
     * @module PlayerWidgetCommonMethods
     * @return {Function} instance of class with singleton pattern
     */
    var PlayerWidgetCommonMethods = (function() {
        'use strict';

        var hasPingedVcServer = false,
            vcServerUrl = '';

        var vcPingsCache = {},
            vcServerUrlList = {};

        /**
         * Get the VcServer URL
         * @param id {string} gets specific url
         * @returns {string} VcServer URL
         */
        function getVcServerUrl(id) {
            if (typeof id === 'string') {
                return vcServerUrlList[id];
            } else {
                return vcServerUrl;
            }
        }

        /**
         * Sets the VcServer URL
         * @param url VcServer URL
         * @param id {string} sets url under specific id
         */
        function setVcServerUrl(url, id) {
            if (typeof id === 'string') {
                vcServerUrlList[id] = url;
            } else {
                vcServerUrl = url;
            }
        }

        /**
         * METHOD TO GET THE KEYS FROM THE JSON DATA OBJECT
         * @method getKeys
         * @param  {Object} obj [ JSon object to get an array with the keys ]
         * @return {Array} keys [ key list from the json Object ]
         */
        function getKeys(obj) {
            var keys = [],
                i;

            for (i in obj) {
                if (obj.hasOwnProperty(i)) {
                    keys.push(i);
                }
            }

            return keys;
        }

        /**
         * Pings VCS server after 5 seconds
         * @param id {string} if provided, will ping url saved with specified id
         * @method pingVCS
         * @void
         */
        function pingVCS(id) {
            if(typeof vcServerUrl !== 'undefined' || (typeof id === 'string' && vcServerUrlList[id]) ) {
                var svalue, pingUrl;
                if (id) {
                    svalue = getUrlParam('svalue', vcServerUrlList[id]);
                    pingUrl = vcServerUrlList[id];
                } else {
                    svalue = getUrlParam('svalue', vcServerUrl);
                    pingUrl = vcServerUrl;
                }
                if (!vcPingsCache[svalue] && pingUrl) {
                    hasPingedVcServer = true;
                    vcPingsCache[svalue] = true;
                    var request1 = new XMLHttpRequest();
                    request1.open("GET", pingUrl);
                    // Conditionally set the header
                    if (typeof liuIdOrNull !== 'undefined' && liuIdOrNull) {
                        request1.setRequestHeader('__m', liuIdOrNull);
                    }
                    request1.send();
                }
            } else {
                throw new Error("vcServerURL not set.");
            }
        }

        /**
         * function to format shown time on the video time slider (currently used in video manager and gif generator)
         * @method prettyTime
         * @param  {String} original_seconds [ time in seconds in string format]
         * @return {Number} time [ formatted time]
         */
        function prettyTime(original_seconds) {
            var sec_num = parseInt(original_seconds, 10);
            var hours   = Math.floor(sec_num / 3600);
            var minutes = Math.floor((sec_num - (hours * 3600)) / 60);
            var seconds = sec_num - (hours * 3600) - (minutes * 60);

            if (hours   < 10) {hours   = "0" + hours;}
            if (minutes < 10) {minutes = "0" + minutes;}
            if (seconds < 10) {seconds = "0" + seconds;}

            var time 	= (parseInt(hours) > 0 ? hours + ':' : '') + minutes + ':' + seconds;
            return time;
        }

        /**
         * function to set Adaptive flag in player config true/false depending on browsers
         * @method isVideoAdaptive
         * @return {boolean}
         */
        function isVideoAdaptive() {
            /*var ieRegex     = /(?:WOW64.+rv:|MSIE\s)(\d+\.*\d*)(?!.*Firefox)/,
                edgeRegex   = /(?:Edge\/)(\d+\.\d+\.*\d*)/,
                userAgent   = navigator.userAgent;

            return (
                typeof isAdaptive != 'undefined' &&
                isAdaptive &&
                !userAgent.match(ieRegex) &&
                !userAgent.match(edgeRegex)
            );*/

            return (typeof isAdaptive != 'undefined' && isAdaptive);
        }

        /**
         * function to return ios version
         * @method iOSversion
         * @return {number} [version of ios]
         */
        function iOSversion() {
            if (/iP(hone|od|ad)/.test(navigator.userAgent)) {
                // supports iOS 2.0 and later: <http://bit.ly/TJjs1V>
                var v = (navigator.appVersion).match(/OS (\d+)_(\d+)_?(\d+)?/);
                return parseInt(v[1]);
            } else {
                return 0;
            }
        }

        /**
         * function to set type of player to load depending on browser
         * @method getPlayerUsageOrder
         * @return {Array} [string array with player name]
         */
        function getPlayerUsageOrder() {
            var playerUsageOrder = []
            if(iOSversion() > 11 && !isVideoAdaptive()){
                playerUsageOrder.push('basicHTML_1.4.0');
            }

            return playerUsageOrder;
        }

        /**
         * function to check if VcServer was pinged or not
         * @method hasVcServerPinged
         * @return {boolean}
         */
        function hasVcServerPinged() {
            return hasPingedVcServer;
        }

        function clearMgpAdrollStorage() {
            const mgpStorageKey = 'mgp_player',
                ls = window.localStorage,
                mgpStorage = ls.getItem(mgpStorageKey),
                maxDate = new Date('2023-06-30T23:59:59').getTime(),
                currentTime = new Date().getTime();
            if (!mgpStorage || currentTime > maxDate) {
                return false;
            }
            try {
                const parsedStorage = JSON.parse(mgpStorage) || {},
                    { adrolls, wiped = {} } = parsedStorage,
                    prerollCommonTime = adrolls[0] && adrolls[0].commonTime || 0;
                if (!adrolls || wiped.adrolls || prerollCommonTime > currentTime / 1000) {
                    return false;
                }
                delete parsedStorage.adrolls;
                parsedStorage.wiped = { adrolls: true };
                ls.setItem(mgpStorageKey, JSON.stringify(parsedStorage));
                return true;
            }
            catch (err) {
                console.warn('*** MGP Adroll ***\nError parsing MGP storage key from custom script.');
                return false;
            }
        }

        return {
            pingVCS: pingVCS,
            getKeys: getKeys,
            prettyTime: prettyTime,
            hasVcServerPinged: hasVcServerPinged,
            getVcServerUrl: getVcServerUrl,
            setVcServerUrl: setVcServerUrl,
            clearMgpAdrollStorage: clearMgpAdrollStorage
        };
    })();

    function getCookie(name) {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        if (parts.length === 2) return parts.pop().split(';').shift();
        return null;
    }

    function getUrlParam(name, url) {
        if(url === 'undefined') {
            url = window.location.href
        }
        name = name.replace(/[\[\]]/g, '\\$&');
        var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, ' '));
    }

    var PH_PlayerComponent = function() {
        var Self = this,
            defaults = {
                playerFlvContainerClass: '.playerFlvContainer',
                playerFlvContainer: null,
                premiumFlag: typeof premiumFlag != 'undefined' ? premiumFlag : false,
                videoPlaceholder: document.getElementById('videoPlayerPlaceholder'),
                urlParams: [],
                hasPingedVcServer: false,
                isPrerollPlaying: false,
                prePlayerInitTime: null,
                isPlaylist: (typeof WIDGET_SHOW_PLAYLIST_BAR !== 'undefined'),
                ccExperimentValue: '',
                ccExperimentEnabled: false,
                playerConfig: null,
                problemStatusResent: false,
                platform: '',
                platformFallback: '',
                autoNextEnabled: false,
                isShowPageValue: (typeof isShowPage !== 'undefined'),
                isUtahDomainValue: (typeof isUtah === 'undefined' || !isUtah),
                isVrVideoValue: (typeof isVr !== 'undefined' && isVr),
                vrPropsValue: (typeof vrProps !== 'undefined') ? vrProps : '',
                videoKeyValue: (typeof VIDEO_SHOW != 'undefined') ? VIDEO_SHOW.vkey : '',
                playerEnvironmentValue: typeof playerEnvironment != 'undefined' ? playerEnvironment : '',
                isSafari5Value: false,
                showNextVideoOption: '',
                uniqueId: '',
                isIOS: (/iP(hone|od|ad)/.test(navigator.userAgent)) ? true : false,
                isIPad: (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 0) ? true : false,
                isAndroid: (/Android/.test(navigator.userAgent)) ? true : false,
                orientationLandscape: false,
                relatedGridEnabled: false,
                phIntroLength: (typeof VIDEO_SHOW != 'undefined' && VIDEO_SHOW.phIntroLength !== null) ? VIDEO_SHOW.phIntroLength : 0,
            }

        Self.initializePlayer = function(){
            defaults.playerFlvContainer = document.querySelector(defaults.playerFlvContainerClass);
            if(defaults.playerFlvContainer){
                Self.setData();
                Self.loadVideoPlayer();
            }
        }

        //mounted
        Self.loadVideoPlayer = function(){
            if(defaults.videoPlaceholder) defaults.videoPlaceholder.style.display = "block";
            defaults.prePlayerInitTime = new Date().getTime();
            setTimeout(function(){
                Self.loadPlayer();
            }, 0);
        };

        //methods
        Self.setData = function() {
            Self.setUrlParamsVars();

            defaults.platform = defaults.playerFlvContainer.dataset.platform ? defaults.playerFlvContainer.dataset.platform : 'desktop';
            defaults.platformFallback = defaults.playerFlvContainer.dataset.platformfallback ? defaults.playerFlvContainer.dataset.platformfallback : 'desktop';
            defaults.showNextVideoOption = defaults.playerFlvContainer.dataset.shownextvideooption ? defaults.playerFlvContainer.dataset.shownextvideooption : null;
            defaults.isSafari5Value = Self.isSafari5();
            defaults.uniqueId = defaults.playerFlvContainer.id;
            defaults.premiumFlag = Self.isPremium();
            defaults.relatedGridEnabled = defaults.platform !== 'desktop' && typeof VIDEO_SHOW !== 'undefined' && VIDEO_SHOW.playerRelatedVideosEnabled;
        };

        Self.setUrlParamsVars = function() {
            window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
                defaults.urlParams[key] = value;
            })
        };

        Self.chargePbBlock = function(){
            var newText = document.getElementById('pb_template');
            if (!newText) return;
            var div = document.querySelector('.mgp_container');
            div.appendChild(newText);
        };

        Self.togglePlayerSizeHD = function() {
            var isChrome69 = /chrome\/([6][9])\./.test(navigator.userAgent.toLowerCase());
            if(isChrome69) {
                setTimeout(function(){
                    page_params.chrome_69_bandaid = {
                        iframes: []
                    };
                    document.querySelectorAll('iframe').forEach( function(item){
                        page_params.chrome_69_bandaid.iframes.push({
                            element : item,
                            h : item.getBoundingClientRect().height
                        });
                    });
                    for (var i=0; i< page_params.chrome_69_bandaid.iframes.length; i++) {
                        var el = page_params.chrome_69_bandaid.iframes[i];
                        el.element.height = el.h + 1 + 'px';
                    }
                }, 300);
            }

            var player             = document.querySelector('.mainPlayerDiv'),
                playerFlvContainer   = document.querySelector('.playerFlvContainer'),
                underplayerAd        = document.querySelector('.hd'),
                relatedVideos        = document.querySelector('.js-relatedVideos'),
                recommendedVideos    = document.querySelector('.js-recommendedVideos'),
                commentReplacement   = document.querySelector('.js-commentReplacement'),
                underPlayerPlaylists = document.getElementById('under-player-playlists'),
                leftPlayerColumn     = document.getElementById('hd-leftColVideoPage'),
                sectionRelateds      = document.querySelector('.section-relateds'),
                sectionP2V           = document.querySelector('.section-p2v'),
                nextVideoSection     = document.querySelector('.nextVideoSection'),
                rightColumn          = document.getElementById('hd-rightColVideoPage'),
                rightSidebar         = rightColumn ? rightColumn : leftPlayerColumn.parentNode.children[1],
                sideColumn           = document.querySelector('.sideColumn'),
                modelInfo            = document.querySelector('.videoWrapModelInfo'),
                viewMoreCtasBtn      = document.querySelector('.show-more-btn');
            let allElements          = [player, playerFlvContainer, underplayerAd, relatedVideos, recommendedVideos, commentReplacement, underPlayerPlaylists, rightSidebar, sectionP2V, sectionRelateds, viewMoreCtasBtn, nextVideoSection, sideColumn, modelInfo];

            allElements = allElements.filter(function (item) { return item != null; });
            if (MG_Utils.hasClass(player, 'original')) {
                MG_Utils.addClassMultiple(allElements, 'wide');
                MG_Utils.removeClassMultiple(allElements, 'original');
            } else {
                MG_Utils.addClassMultiple(allElements, 'original');
                MG_Utils.removeClassMultiple(allElements, 'wide');
            }

            if(rightSidebar && VIDEO_SHOW.isTrailerVideo && VIDEO_SHOW.canShowAds) {
                MG_Utils.addClass(rightSidebar, 'trailerVideoAd');
            }

            if (typeof thumbsLayoutUpdate !== 'undefined' && thumbsLayoutUpdate) {
                document.dispatchEvent(new Event('togglePlayerSize'));
            }
        };

        Self.appendCTAs = function(eventData) {
            var { likeDislike } = eventData;
            if (!likeDislike) return;
            var likeDislikeContainer = document.querySelector(likeDislike);
            if (likeDislikeContainer && typeof VIDEO_SHOW !== 'undefined') {
                if (VIDEO_SHOW.playerAvatar) {
                    let uploaderAvatarUrl = VIDEO_SHOW.playerAvatarUrl ? VIDEO_SHOW.playerAvatarUrl : '',
                        uploaderName = VIDEO_SHOW.playerAvatarName ? VIDEO_SHOW.playerAvatarName : '';
                    if (uploaderAvatarUrl) likeDislikeContainer.insertAdjacentHTML('beforeend', `<img class="mgp-avatar" src="${uploaderAvatarUrl}" alt="${uploaderName} avatar">`);
                }
                if (VIDEO_SHOW.playerSubscribe) {
                    if (VIDEO_SHOW.playerSubscribeCTA) likeDislikeContainer.insertAdjacentHTML('beforeend', VIDEO_SHOW.playerSubscribeCTA);
                }
                if (VIDEO_SHOW.playerLike) likeDislikeContainer.insertAdjacentHTML('beforeend', '<button class="ph-icon-thumb-up js-thumbs-up mgp-rate"></button>');
                if (VIDEO_SHOW.playerDislike) likeDislikeContainer.insertAdjacentHTML('beforeend', '<button class="ph-icon-thumb-down js-thumbs-down mgp-rate"></button>');
                if (VIDEO_SHOW.playerFav && !VIDEO_SHOW.isClipShowPage) {
                    let activeFav = VIDEO_SHOW.isFavourite ? ' active' : '';
                    likeDislikeContainer.insertAdjacentHTML('beforeend', `<button class="ph-icon-favorite js-favorite-btn mgp-rate${activeFav}"></button>`);
                }
            }
        };

        Self.toggleCTAs = function() {
            var rateCTAs = document.querySelectorAll('.mgp-rate');
            if (defaults.relatedGridEnabled && rateCTAs.length) {
                defaults.orientationLandscape ? MG_Utils.removeClassMultiple(rateCTAs, 'displayNone') : MG_Utils.addClassMultiple(rateCTAs, 'displayNone');
            }
        };

        Self.destroyPlayer = function(playerContainerId) {
            MG_Utils.addEventHandler(window, 'beforeunload', function(e) {
                MGP.destroyPlayer(playerContainerId);
            });
        };

        Self.disablePopOnControls = function() {
            var playerControls = document.querySelector('.mhp1138_controlBar'),
                playerSoundBtn = document.querySelector('.mhp1138_sound');

            if (playerControls && playerSoundBtn) {
                MG_Utils.addClass(playerControls, 'js-pop');
                MG_Utils.addClass(playerSoundBtn, 'js-pop');
            }
        };

        Self.triggerFullScreenDisplay = function(playerId) {
            var playerContainer = document.getElementById(playerId);
            if(playerContainer){
                MG_Utils.addClass(playerContainer, 'fullscreen');
            }
        };

        Self.getUpsellFlag = function(upsellBEFlag) {
            var upsellFlag = [];
            if (defaults.isVrVideoValue) {
                upsellFlag = (upsellBEFlag && !defaults.premiumFlag) ? [2160] : [];
            } else {
                upsellFlag = (upsellBEFlag) ? [1080] : [];
            }

            return upsellFlag;
        };

        Self.getUpsellLinkcode = function(resolution) {
            if(!resolution) return false;
            return 'Player' + resolution + 'pUpsell';
        };

        Self.isAdBlockOff = function() {
            return ((defaults.platform == 'desktop' &&
                typeof page_params.holiday_promo_prem != 'undefined') ||
                defaults.platform != 'desktop');
        };

        Self.showPreroll = function(prerollObj) {
            return (
                typeof prerollObj !== 'undefined' &&
                Self.isAdBlockOff() &&
                !defaults.isVrVideoValue
            )
        };

        /**
         * Appends screen width and height to preroll config URL for fingerprinting
         * @method appendScreenDimensionsToPreroll
         * @param {Array} prerollArr [preroll config array from BE]
         * @return {Array} prerollArr with screen dimensions appended to json URL
         */
        Self.appendScreenDimensionsToPreroll = function(prerollArr) {
            if (!prerollArr || prerollArr.length === 0) {
                return prerollArr;
            }
            var screenWidth = (window && window.screen && window.screen.width) ? window.screen.width : '';
            var screenHeight = (window && window.screen && window.screen.height) ? window.screen.height : '';
            if (screenWidth && screenHeight) {
                prerollArr.forEach(prerollObj => {
                    if (!prerollObj.json) return;
                    var separator = prerollObj.json.indexOf('?') !== -1 ? '&' : '?';
                    prerollObj.json = prerollObj.json + separator + 'width=' + screenWidth + '&height=' + screenHeight;
                });
            }
            return prerollArr;
        };

        Self.nextVideoBtnConfig = function (nextVideoObj) {
            if (Object.keys(nextVideoObj).length !== 0) {
                var nextVideoOption = {
                    title: nextVideoObj.title, // title of next video
                    url: nextVideoObj.nextUrl, // url to be triggered on click of next button
                    button: {
                        duration: nextVideoObj.duration, // duration of next video
                        enabled:  !VIDEO_SHOW.isClipShowPage,
                        thumb: nextVideoObj.thumb, // thumb of next video
                        video: nextVideoObj.video, // webm video URL to show instead of the thumb
                    },
                    overlay: {
                        enabled: false,
                        channel: nextVideoObj.channelTitle || '', // channel of next video
                        timeout: 10, // timeout before redirect
                    },
                };

                if (nextVideoObj.isJoinPageEntry &&
                    (typeof VIDEO_SHOW !== 'undefined')) {
                    const xhr = new XMLHttpRequest(),
                        params = `entry_code=${encodeURIComponent('VidPg-premVid-default')}&segment=${encodeURIComponent(VIDEO_SHOW.segment)}&viewkey=${encodeURIComponent(nextVideoObj.vkey)}`;
                    
                    xhr.open('GET', VIDEO_SHOW.getBuildJoinPageUrl + '?' + params, true);
                    xhr.onload = () => {
                        if (xhr.status >= 200 && xhr.status < 300) {
                            const data = JSON.parse(xhr.responseText);
                            if(data.success == "PASS" && data.url) {
                                nextVideoOption.nextUrl = data.url;
                            }
                        }
                    };
                    xhr.send();
                }
                return nextVideoOption;
            }
            return {};
        };

        Self.buildPrerollObj = function(prerollObj) {
            var vastArray = [], vastObject = {};
            [].forEach.call(prerollObj.campaigns, function(campaign){
                var clickArea = {};
                if (campaign.clickableAreasByPlatform) {
                    var defaultValues = {
                        video: true,
                        link: true
                    }
                    clickArea = campaign.clickableAreasByPlatform.pc ?
                        campaign.clickableAreasByPlatform.pc : defaultValues;
                }

                vastObject = {
                    xml: campaign.vastXml, //backend value from CMS
                    vastSkipDelay: false,
                    rollSettings: {
                        onNth: campaign.on_nth, //backend value from CMS
                        skipDelay: campaign.skip_delay, //backend value from CMS
                        siteName: 'Pornhub',
                        forgetUserAfter: campaign.forgetUserAfter, //backend value from CMS
                        campaignName: campaign.campaign_name,
                        skippable: campaign.skippable, //backend value from CMS
                        clickableAreas: clickArea, //The objects or areas on the screen that the user can click to visit the url
                        campaignWeight: campaign.percentChance
                    }
                };
                vastArray.push(vastObject);
            });

            return vastArray;
        };

        Self.getLegacyEventsConfig = function(eventsConfig) {
            var legacyNamesMap = {
                'buttons.collapse': 'collapsePlayer',
                'buttons.expand': 'expandPlayer',
                'layout.horizontal': 'horizontalPlayer',
                'layout.vertical': 'verticalPlayer',
                'fullscreen.changed': 'onFullscreen',
                'playback.paused': 'onPause',
                'player.ready': 'onReady',
                'player.rolls.hide': 'hideRoll',
                'player.rolls.pause': 'showPauseRoll',
                'player.rolls.post': 'showPostRoll',
                'playback.ended': 'onEnd',
                'playback.playing': 'onPlay',
                'playback.seek.started': 'onSeek',
                'playback.time.changed': 'onTimeChange',
                'preroll.ended': 'hidePreRoll',
                'preroll.started': 'showPreRoll'
            };

            return Object.entries(eventsConfig).reduce(function (acc, arr) {
                var obj = {},
                    fileName = legacyNamesMap[arr[0]] || arr[0];

                obj[fileName] = function (i, e, o) {
                    arr[1](o, i, e);
                };

                return Object.assign({}, acc, obj);
            }, {});
        };

        Self.setSrcVideoSource = function(element, url) {
            var source = document.querySelector('#' + element + ' video > source');
            source.src = url;
        };

        Self.showHideRemoveAddBtn = function(action) {
            var button = document.querySelector('.adsRemoveButtonWrapper.prerollAd');
            var adText = document.querySelector('.mgp_adRollTitleText');

            if (!button) return;

            if (action === 'show') {
                button.classList.remove('displayNone');
                if (adText) adText.style.visibility = 'hidden';
            }
            else if (action === 'hide') {
                button.classList.add('displayNone');
                if (adText) adText.style.visibility = 'visible';
            }
        };


        Self.registerPlayerEvents = function(flashvars) {
            var vcServerUrl = flashvars.vcServerUrl || null,
                vcTimersCache = {},
                events = {
                    //Googlebot crawling of video
                    "source.quality.ready": function(o, i, e) {
                        if(defaults.platform == 'mobile'
                            && typeof flashvars['googleCrawlUrl'] !== "undefined") {
                            Self.setSrcVideoSource(i, flashvars['googleCrawlUrl']);
                        }
                    },
                    // Video page collapse flash playersite-speed
                    "buttons.collapse": function() {
                        Self.togglePlayerSizeHD();
                    },
                    // Video page expand flash player
                    "buttons.expand": function() {
                        Self.togglePlayerSizeHD();
                    },
                    // General seek function
                    "playback.seek.started": function() {
                        if (typeof htTrack != 'undefined') htTrack.ptrack();
                    },
                    // Video is ready
                    "player.ready": function(o, i, e) {
                        if (typeof initVrPlayer == 'function') {
                            // Load script and intialize player for VR
                            initVrPlayer();
                        }

                        if (defaults.isShowPageValue) Self.chargePbBlock();

                        Self.disablePopOnControls();

                        if(defaults.autoNextEnabled) Self.attachAutoNextCustomEvents(i, e, o);

                        //clearTimeout(self.playerLoadingTimer);

                        Self.disablePlaceholderImage();

                        if(typeof AWARDS_OBJ !== 'undefined') {
                            let videoElement = document.querySelector('#' + i + ' .mgp_videoWrapper video');
                            if (!o.started && videoElement.paused) {
                                let playerAPI = MGP.players[i];
                                playerAPI.play();
                                videoElement.muted = true;
                            }
                        }

                        defaults.orientationLandscape = defaults.playerFlvContainer.classList.contains('mgp_orientation-landscape');
                    },
                    // On Video Fulscreen -  HTML5 video feed trick
                    "fullscreen.changed": function(o, i) {
                        if (defaults.isShowPageValue) Self.triggerFullScreenDisplay(i);
                        Self.toggleCTAs();
                        if (VIDEO_SHOW.displayFakeFullscreenPlayer && !o.fullscreen) Self.handleFullscreenChange(o);
                    },
                    // Video page pause/pre roll show Ad
                    "player.rolls.pause": function() {
                        if(typeof trailerPauseRoleInstance !== 'undefined') {
                            trailerPauseRoleInstance.openAdBlock();
                        } else {
                            if (typeof Pb_block !== 'undefined') Pb_block.openAdBlock();
                        }
                    },
                    // Video page pause/pre roll show Ad
                    "player.rolls.post": function() {
                        const autoplayCookie = getCookie('autoplay');

                        if (typeof Pb_block !== 'undefined') {
                            Pb_block.params.showBlock = true;
                            Pb_block.openAdBlock();
                        }

                        if (autoplayCookie && autoplayCookie === 'on' &&
                            typeof VueUpNextVideo !== 'undefined') {
                            VueUpNextVideo.showOverlay();
                        }
                    },
                    // Fire an event when the preroll is showing
                    "preroll.started": function() {
                        defaults.isPrerollPlaying = true;
                        const page_params = page_params ||
                            (typeof page_extra_params != 'undefined' ? page_extra_params : null);
                        if(page_params) {
                            page_params.prerollFired = true;
                            if (defaults.isShowPageValue) {
                                for (var key in page_params.zoneDetails) {
                                    if (!page_params.zoneDetails.hasOwnProperty(key)) continue;
                                    let obj = page_params.zoneDetails[key],
                                        frameElement = document.getElementById(obj.frameId);
                                    if (typeof obj.preroll_change_url !== 'undefined') {
                                        frameElement && frameElement.setAttribute('src', obj.preroll_change_url);
                                    }
                                }
                            }
                        }
                    },
                    "preroll.ended": function() {
                        defaults.isPrerollPlaying = false;
                    },
                    "playback.playing": function(o, id) {
                        var container = document.getElementById(id),
                            currentTimeInSeconds = container &&
                                container.querySelector('video').currentTime;

                        if (typeof VIDEO_SHOW !== 'undefined' && VIDEO_SHOW.isQrCode) {
                            if (VIDEO_SHOW.feelIsUserConnected) {
                                $feel.subs.play(currentTimeInSeconds);
                            }
                        }

                        if (vcTimersCache[id]) {
                            vcTimersCache[id].resume();
                        } else {
                            PlayerWidgetCommonMethods.setVcServerUrl(vcServerUrl, id);
                            vcTimersCache[id] = new Timer(PlayerWidgetCommonMethods.pingVCS, 10000, id);
                        }

                        Self.hidePauseRoll();
                    },
                    "playback.ended": function(o, id) {
                        const autoNext = typeof MGP.players[id].autoNext != 'undefined' ?
                            MGP.players[id].autoNext() : null;

                        window.dispatchEvent(new CustomEvent('videoEnded'));
                    },
                    "playback.paused": function(o, id) {
                        if (typeof VIDEO_SHOW !== 'undefined' && VIDEO_SHOW.isQrCode) {
                            if (VIDEO_SHOW.feelIsUserConnected) {
                                $feel.subs.stop();
                            }
                        }

                        if (vcTimersCache[id]) { vcTimersCache[id].pause(); }
                    },
                    "playback.time.changed": function(o, id) {
                        const container = document.getElementById(id),
                            currentTimeInSeconds = container && container.querySelector('video').currentTime,
                            duration = container && container.querySelector('video').duration,
                            countdown = document.querySelector('.countdown'),
                            fixedDelay = 5,
                            currTime = Math.floor(currentTimeInSeconds);

                        if (typeof VIDEO_SHOW !== 'undefined' && VIDEO_SHOW.isQrCode) {
                            if (VIDEO_SHOW.feelIsUserConnected) {
                                $feel.subs.timeupdate(currentTimeInSeconds);
                            }
                        }
                        if(duration - currTime > fixedDelay) {
                            if (typeof VIDEO_SHOW !== 'undefined') VIDEO_SHOW.delay = 5;
                            countdown && countdown.classList.add('displayNone');
                        }
                        if (typeof VueUpNextVideo !== 'undefined') {
                            VueUpNextVideo.detectTime(currTime);
                        }
                    },
                    'adroll.started': function(eventData) {
                        const { eudsaId, eudsaUrl } = eventData,
                         showAdsLinkUngated = typeof VIDEO_SHOW !== 'undefined' ? VIDEO_SHOW.showAdsLink : false;

                        if(!eudsaUrl || !showAdsLinkUngated) {
                            const eudsaContainer = document.querySelector("[data-eudsa-url]");
                            eudsaContainer && eudsaContainer.parentElement && eudsaContainer.parentElement.classList.add('noStyleChange');
                        }else if(eudsaId && eudsaUrl && showAdsLinkUngated){
                            const eudsaContainer = document.querySelector("[data-eudsa-url]"),
                                eudsaWrapper = document.createElement("div"),
                                eudsaLinkContainer = document.createElement("a"),
                                eudsaBigContainer = document.createElement("div");

                            eudsaWrapper.classList = "eudsaWrapper";
                            eudsaLinkContainer.id= 'eudsa-banner-container-link';
                            eudsaBigContainer.id= 'eudsa-banner-container-big';
                            eudsaBigContainer.innerHTML = 'Ad by TrafficJunky';
                            eudsaLinkContainer.appendChild(eudsaBigContainer);
                            eudsaWrapper.appendChild(eudsaLinkContainer);
                            eudsaContainer && eudsaContainer.after(eudsaWrapper);
                            eudsaContainer.classList = 'hidden';
                            if(eudsaContainer.parentElement) {

                                eudsaContainer.parentElement.style.zIndex = '10';
                                eudsaContainer.parentElement.style.display = 'flex';
                                eudsaContainer.parentElement.style.alignItems = 'center';
                                eudsaContainer.parentElement.style.marginBottom = '5px';
                            }

                            const isMobileDevice = defaults.isIOS || defaults.isIPad || defaults.isAndroid;
                            eudsaLinkContainer && eudsaLinkContainer.addEventListener(defaults.platform == 'mobile' && isMobileDevice ? 'touchend' : 'click', () => window.open(eudsaUrl, "_blank"));
                        }
                        if(document.querySelector('.clipsEditor__clipsButtonBlock')) {
                            document.querySelector('.clipsEditor__clipsButtonBlock').classList.add('displayNone');
                        }
                        Self.showHideRemoveAddBtn('show');
                    },
                    'adroll.ready': () => {window.isPlayingAdroll = true},
                    'adroll.ended': () => {
                        window.isPlayingAdroll = false;
                        if(document.querySelector('.clipsEditor__clipsButtonBlock')) {
                            document.querySelector('.clipsEditor__clipsButtonBlock').classList.remove('displayNone');
                        }
                        Self.showHideRemoveAddBtn('hide');
                    },
                    'adroll.aborted': () => {window.isPlayingAdroll = false},
                    'skin.ready': function(eventData) {
                        Self.appendCTAs(eventData);
                    },
                    'grid.related.clicked': function(eventData) {
                        if (eventData.value === 'ViewMore') {
                            let relatedSection = document.querySelector('#related'),
                                relatedTab = document.querySelector('#tabFilters #js-relatedTab');
                            setTimeout(function() {
                                relatedTab && relatedTab.click();
                                relatedSection && window.scrollTo(0, relatedSection.offsetTop - 110);
                            }, 300);
                        }
                    },
                    'orientation.changed': function(eventData) {
                        defaults.orientationLandscape = eventData.orientation === 'landscape';
                        Self.toggleCTAs();
                    }
                },
                playerVersion = MGP && MGP.buildInfo.playerVersion;

            return parseFloat(playerVersion) < 6.1 ? Self.getLegacyEventsConfig(events) : events;
        };

        Self.getPlayerConfig = function(playerId, flashvars) {
            var hideEmbedOption = typeof VIDEO_SHOW !== 'undefined' ? VIDEO_SHOW.hideEmbedOption : null,
                showPrerollVar = typeof VIDEO_EDITOR == 'undefined' && typeof VIDEO_MANAGE == 'undefined',
                showNextVideoBtn = (defaults.platform !== 'desktop') ? !PLAYER_SHOW_NEXT_BUTTON : true,
                newRelatedVideosData = defaults.platform === 'desktop' || typeof relatedVideosData === 'undefined' ? [] : relatedVideosData,
                playerVideoPreviewEnabled = typeof VIDEO_SHOW !== 'undefined' ? VIDEO_SHOW.playerVideoPreviewEnabled : false;

            var preventAutoplayForAVModal = (document.getElementById("avModalTemplate") && !getCookie('av_modal')) ||
                (document.getElementById('js-ageDisclaimerModal') && !getCookie('accessAgeDisclaimerPH')) ||
                (document.getElementById('age-verification-wrapper') && !getCookie('age_verified')) ||
                document.getElementById('mandatoryDobFlag');

            var displayFakeFullscreenPlayer = null;

            var configJSON = {
                seekParams: { mp4 : flashvars.mp4_seek,  flv : 'fv' },
                deviceType: defaults.platform,
                autoPlayVideo:{enabler:false},
                quickSetup: "pornhub",
                locale: flashvars.language,
                autoplay: {
                    enabled: (defaults.isShowPageValue && defaults.isUtahDomainValue && defaults.platform == 'desktop' && !preventAutoplayForAVModal) ? JSON.parse(flashvars.autoplay) : (typeof AWARDS_OBJ !== 'undefined'), // Value is determined in settings.js
                    initialState: true,
                    retryOnFailure: false,
                    switch: 'buttonbar', // 'menu' || 'buttonbar' || 'none'
                },
                startOffset: defaults.urlParams['t'] ? defaults.urlParams['t'] : 0,
                hotspots: {
                    data: flashvars.hotspots ? flashvars.hotspots : []
                },
                nextVideo : (defaults.showNextVideoOption && showNextVideoBtn ) ? Self.nextVideoBtnConfig(flashvars.nextVideo) : {},
                mainRoll: {
                    adaptive: {
                        prebufferGoal: 40,
                    },
                    actionTags: flashvars.actionTags,
                    mediaPriority: flashvars.mediaPriority,
                    mediaDefinition: flashvars.mediaDefinitions,
                    poster: flashvars.image_url,
                                        timelineOffset: Boolean(Number(flashvars?.thumbs?.isVault)) ? defaults.phIntroLength : 0,
                    thumbs: {
                        isVault: flashvars.thumbs.isVault,
                        urlPattern: flashvars.thumbs.urlPattern,
                        spritePatterns: flashvars.thumbs.spritePatterns,
                        samplingFrequency: flashvars.thumbs.samplingFrequency,
                        thumbWidth: flashvars.thumbs.thumbWidth,
                        thumbHeight: flashvars.thumbs.thumbHeight,
                        cdnType: flashvars.thumbs.cdnType
                    },
                    videoUrl: flashvars.link_url,
                    duration: flashvars.video_duration,
                    title: flashvars.video_title,
                    videoUnavailable: false,
                    qualityUpsell: Self.getUpsellFlag(flashvars.display_hd_upsell),
                    closedCaptions: flashvars.closedCaptionsFile,
                    vertical: (flashvars.isVertical == 'true' || flashvars.isVertical === true),
                    textLinks: ((typeof TEXTLINKS !== 'undefined') ? TEXTLINKS : []),
                },
                hlsConfig: {
                    maxInitialBufferLength: flashvars.maxInitialBufferLength,
                    maxBufferLength: defaults.premiumFlag ? 60 : 20,
                    maxMaxBufferLength: defaults.premiumFlag ? 60 : 20
                },
                type: defaults.platform,
                priority: 'hls',
                menu: {
                    relatedUrl: flashvars.related_url,
                    relatedData: newRelatedVideosData,
                    showOnPause: false,
                    slideout: {
                        enabled: defaults.relatedGridEnabled
                    }
                },
                holdToFfd: {
                    enabled: true,
                    threshold: 1000,
                    ffdRate: 2,
                },
                features: {
                    ccVisible: defaults.ccExperimentEnabled,
                    ccMenu : defaults.ccExperimentEnabled,
                    themeColor: '#f6921e',
                    embedCode: hideEmbedOption ? '' : flashvars.embedCode,
                    showHotspots: true,
                    chromecast: (typeof flashvars.chromecast != "undefined") ? flashvars.chromecast : true,
                    autoFullscreen: (typeof flashvars.autoFullscreen != "undefined") ? flashvars.autoFullscreen : true,
                    cinema: playerId.getAttribute('data-enlarge') ? true : false,// Toggle size check set though player widget - player.phtml
                    ignorePreferences: (defaults.isShowPageValue && defaults.isUtahDomainValue) ? false : true,
                    iosAutoFullscreen: (defaults.platform == 'mobile'),
                    options: true,//New feature since LS2.4.0 allow to show the
                    showAutoplayOption: playerId.getAttribute('data-showautoplayoption') ? true : false,//Showing the autoplayoption on video page only not feed
                    hideControlsTimeout: 2, //Hide the bar option after the aumount of time mentionned on the option
                    speed: true, //enables/disables video motion rate
                    nextVideo:  true, //enables/disables next video feature
                    share: false, //share menu
                    topBar: false, //player's topBar=> title
                    volume: true, //volume
                    seekPreviewBlur: false,
                    chromecastSkin: false,
                    oneHand: false,
                    qualityInControlBar: true,
                    grid: defaults.relatedGridEnabled
                },
                flashSettings: {
                    postRollUrl: defaults.premiumFlag ? '' : flashvars.postroll_url,
                    pauseRollUrl: defaults.premiumFlag ? '' : flashvars.pauseroll_url,
                    htmlPauseRoll : defaults.premiumFlag ? 'false' : 'true',
                    htmlPostRoll  : defaults.premiumFlag ? 'false' : 'true',
                    extraFlashvars: {
                        oldFlash: {
                            hidePostPauseRoll: defaults.premiumFlag
                        },
                        fourPlay: {
                            "tracking": [{
                                "reportType":"qosevents",
                                "rollType":"video",
                                "rollTiming":"main",
                                "cdn":flashvars.cdn,
                                "startLagThreshold":flashvars.startLagThreshold,
                                "outBufferLagThreshold":flashvars.outBufferLagThreshold
                            }]
                        }
                    }
                },
                eventTracking: {
                    params: {
                        cdn: flashvars.cdn,
                        isp: flashvars.isp,
                        geo: flashvars.geo,
                        videoId: typeof flashvars['playbackTracking'] !== 'undefined' ? flashvars['playbackTracking'].video_id : '',
                        playerSource: typeof playerSource !== 'undefined' ? playerSource : 'other'
                    },
                    viewed: {
                        threshold : 60, // Poking the server after 60 seconds to track if user stayed at least one minute
                        url: flashvars.viewedRequestURL
                    },
                },
                events: Self.registerPlayerEvents.call(this, flashvars),
                adRolls: Self.showPreroll(flashvars.adRollGlobalConfig) && showPrerollVar ? Self.appendScreenDimensionsToPreroll(flashvars.adRollGlobalConfig) : [],
                isVideoPage: defaults.isShowPageValue,
                vrProps: defaults.vrPropsValue, //Flag the vrProps
                isVr: defaults.isVrVideoValue ? true : false, // 6.2.0 expects bool

                theme: {
                    themeCode: "pornhub",
                    customColor: "#FF9000",
                    customLogo: flashvars.customLogo
                },
                pip: {
                    enabled: false
                },
                seekPreview: {
                    enabled: true,
                    videoPreview: playerVideoPreviewEnabled || false,
                }
            }

            if(typeof TFE_IOSPLAYER_SWIPEFULLSCREEN !== 'undefined'){
                configJSON.fullscreen = {
                    enabled: (typeof flashvars.autoFullscreen != "undefined") ? flashvars.autoFullscreen : true,
                    nativeControls: (defaults.isIOS || defaults.isIPad) ? !displayFakeFullscreenPlayer : false,
                    autoFullscreen: {
                        android: defaults.isAndroid,
                        ios: (defaults.isIOS || defaults.isIPad),
                    }
                }
            }else{
                configJSON.fullscreen = {
                    enabled: (typeof flashvars.autoFullscreen != "undefined") ? flashvars.autoFullscreen : true,
                    nativeControls: (defaults.isIOS || defaults.isIPad) ? true : false,
                    autoFullscreen: {
                        android: defaults.isAndroid,
                        ios: (defaults.isIOS || defaults.isIPad),
                    }
                }
            }

            if(typeof flashvars['playbackTracking'] !== "undefined" && flashvars['playbackTracking'].app_id && flashvars['playbackTracking'].eventName && flashvars['playbackTracking'].munged_session_id
                && flashvars['playbackTracking'].hostname && (flashvars['playbackTracking'].video_id || flashvars['playbackTracking'].vid) && (flashvars['playbackTracking'].video_duration || flashvars['playbackTracking'].cd)
                && flashvars['playbackTracking'].video_timestamp && flashvars['playbackTracking'].watch_session && flashvars['playbackTracking'].sample_size) {
                configJSON.eventTracking.playback = {
                    appId: flashvars['playbackTracking'].app_id,
                    eventName: flashvars['playbackTracking'].eventName,
                    mungedSessionId: flashvars['playbackTracking'].munged_session_id,
                    trackingUrl: "https://etahub.com/events",
                    hostname: flashvars['playbackTracking'].hostname,
                    videoId: flashvars['playbackTracking'].video_id,
                    videoDuration: flashvars['playbackTracking'].video_duration,
                    videoTimestamp: flashvars['playbackTracking'].video_timestamp,
                    watchSession: flashvars['playbackTracking'].watch_session,
                    sampleSize: flashvars['playbackTracking'].sample_size
                };
                if (flashvars['playbackTracking'].cid) {
                    configJSON.eventTracking.params['clipId'] = flashvars['playbackTracking'].cid;
                    configJSON.eventTracking.params['originalDuration'] = flashvars['playbackTracking'].video_duration;
                    configJSON.eventTracking.params['videoDuration'] = flashvars['playbackTracking'].vd;
                }
            }

            if (typeof Etahub !== "undefined") {
                var searchEngineCookie = Etahub.getCookie(defaults.videoKeyValue);
                if (searchEngineCookie) {
                    var searchEngineData = Etahub.translate(searchEngineCookie);
                    configJSON.eventTracking.params['customData'] = searchEngineData;
                }
            }

            if(defaults.platform == 'mobile') configJSON.hlsConfig['autoLevelCapping'] = 720;

            // captionType:  1 - VIDEO_AUTO_GENERATED_CAPTION, 0 - VIDEO_USER_GENERATED_CAPTION
            if (typeof flashvars != 'undefined' && flashvars.captionType != 'undefined' && flashvars.captionType == 1) {
                configJSON.mainRoll.closedCaptions = {
                    en: {
                        url: flashvars.closedCaptionsFile,
                        label: 'English (auto-generated)'
                    }
                };
            }
            return configJSON
        };

        Self.loadPlayer = function() {
            if(playerObjList.hasOwnProperty(defaults.uniqueId)) {
                var embedId = playerObjList[defaults.uniqueId].flashvars.embedId,
                    flashvars = window['flashvars_' + embedId],
                    playerContainerId = 'playerDiv_' + embedId,
                    playerId = window[playerContainerId],
                    playerElement = document.getElementById(playerContainerId);

                // Add crawler data to flashvars for mobile
                                flashvars.video_title = "EP5 Part 2 Teddy Tarantino | Jail Talks To 200 Employees!";
                                                
                defaults.playerConfig = JSON.parse(JSON.stringify(flashvars));

                if (typeof flashvars !== 'undefined' && typeof playerId !== 'undefined' && typeof MGP != "undefined") {
                    if (!playerId.getAttribute('data-processed')) {
                        playerId.setAttribute('data-processed', 1);

                        if (defaults.isSafari5Value && playerElement) {
                            playerElement.classList.add('unsupported-safari');
                        }

                        if(!!flashvars.closedCaptionsFile) {
                            Self.setCcExperimentValues();
                        }

                        PlayerWidgetCommonMethods.clearMgpAdrollStorage();

                        MGP.createPlayer(playerContainerId, Self.getPlayerConfig.call(this, playerId, flashvars));

                        // Set poster and title on mgp_videoElement for crawlers
                        if (flashvars && (flashvars.video_title || flashvars.googleCrawlUrl)) {
                            setTimeout(function() {
                                var mgpVideo = document.querySelector('#' + playerContainerId + ' video.mgp_videoElement');
                                if (mgpVideo) {
                                    // Try to get poster from flashvars first (PC)
                                    if (flashvars.poster_url) {
                                        mgpVideo.setAttribute('poster', flashvars.poster_url);
                                    } else {
                                        // Fallback: copy poster from player-html5 element (mobile)
                                        var fallbackVideo = document.querySelector('#' + playerContainerId + ' video.player-html5');
                                        if (fallbackVideo && fallbackVideo.getAttribute('poster')) {
                                            mgpVideo.setAttribute('poster', fallbackVideo.getAttribute('poster'));
                                        }
                                    }
                                    if (flashvars.video_title) {
                                        mgpVideo.setAttribute('title', flashvars.video_title);
                                    }
                                    // Update video source for crawlers
                                    var mgpSource = mgpVideo.querySelector('source');
                                    if (mgpSource && flashvars.googleCrawlUrl) {
                                        mgpSource.setAttribute('src', flashvars.googleCrawlUrl);
                                    }
                                }
                            }, 100);
                        }
                    }

                    if(defaults.platform === 'desktop'){
                        Self.destroyPlayer(playerContainerId);
                    }
                }
            }
        };

        Self.setCcExperimentValues = function() {
            if(typeof PH_Storage != 'undefined') {
                var playerData = PH_Storage.getItem('mhp1138_player'),
                    hasCcData = playerData ? playerData['closedCaptions'] : null;

                if(hasCcData) {
                    defaults.ccExperimentEnabled = hasCcData.visible;
                    defaults.ccExperimentValue = hasCcData.visible ? "forcedClosedCaptionsOn" : "forcedClosedCaptionsOff";
                } else {
                    defaults.ccExperimentEnabled = true;
                    defaults.ccExperimentValue = "forcedClosedCaptionsOn";
                }
            }
        };

        Self.attachAutoNextCustomEvents = function (playerId, element, object) {
            var autoNext = typeof MGP.players[playerId] != 'undefined' && typeof MGP.players[playerId].autoNext != 'undefined' ?
                MGP.players[playerId].autoNext() : null;

            if(autoNext) {
                //pause autoNext count when user performs any other action outside player element
                document.addEventListener('click', function(e) {
                    autoNext.hide();
                });
                //pause autoNext count when user switches current tab
                window.addEventListener('blur', function(e) {
                    autoNext.hide();
                });
            }
        };

        Self.disablePlaceholderImage = function() {
            const closestImage = defaults.playerFlvContainer.parentElement.parentElement.querySelector('.videoElementPoster');
            if(closestImage) {
                closestImage.classList.add('displayNone');
            }
        };

        Self.hidePauseRoll = function() {
            if(typeof trailerPauseRoleInstance !== 'undefined') {
                trailerPauseRoleInstance.closeAdBlock();
            } else {
                if (typeof Pb_block !== 'undefined') {
                    Pb_block.closeAdBlock();
                }
            }
        };

        Self.handleFullscreenChange = function(playerObject) {
            var orientationSnackbar = document.querySelector('.js-orientationSnackbar');
            var orientationSnackbarReason = document.querySelector('.js-orientationSnackbarReason');

            if(playerObject.action === 'address-bar' || playerObject.action === 'multi-tabs'){
                orientationSnackbarReason.innerHTML = (VIDEO_SHOW.fakeFullscreenReasons[playerObject.action] !== undefined && VIDEO_SHOW.fakeFullscreenReasons[playerObject.action] !== null)
                    ? VIDEO_SHOW.fakeFullscreenReasons[playerObject.action]
                    : '';
                orientationSnackbar.classList.add('is-shown');

                setTimeout(function() {
                    orientationSnackbar.className = orientationSnackbar.className.replace(/\bis-shown\b/, '').trim();
                }, 4000);
            }
        }

        //computed
        Self.isSafari5 = function() { return !!navigator.userAgent.match(' Safari/') && !navigator.userAgent.match(' Chrom') && !!navigator.userAgent.match(' Version/5.'); };
        Self.isPremium = function() { return defaults.premiumFlag == true };
    };
    var phPlayerComponent = new PH_PlayerComponent();

    /**
     * Module for Setting the right format of the Delight VR video player
     * @module VrFormatFinder
     * @return {Function} setVrFormat,pingVcsHandler
     */
    var VrFormatFinder = (function() {
        'use strict';

        /**
         * Function to set correct format depending on projection and streotype
         * @method findFormat
         * @param {Number} projection
         * @param {Number} stereoType
         * @return {String} vrFormat [streotype 360/180 degree left right/top bottom]
         */
        function findFormat(projection, stereoType) {
            var vrFormat;

            switch(stereoType) {
                case 1:
                    vrFormat = (projection == 2) ? "STEREO_360_LR" : "STEREO_180_LR";
                    break;
                case 2:
                    vrFormat = (projection == 2) ? "STEREO_360_TB" : "STEREO_180_TB";
                    break;
                case 3:
                    vrFormat = (projection == 2) ? "STEREO_360_LR" : "STEREO_FLAT_LR";
                    break;
                case 4:
                    vrFormat = (projection == 2) ? "STEREO_360_TB" : "STEREO_FLAT_TB";
                    break;
                case 'MONO':
                    vrFormat = (projection == 1) ? "MONO_FLAT" : "MONO_360";
                    break;
                default:
                    vrFormat = "MONO_360";
            }

            return vrFormat;
        }

        /**
         * Function setting Setting any variable in fallback url
         * @method updateQueryStringParameter
         * @param {String} key [key of the url param]
         * @param {String} value [vlalue of key of the url param]
         * @param {String} uri [actual url]
         * @return {String} url with added new params
         */
        function updateQueryStringParameter(key, value, uri) {
            var re = new RegExp("([?&])" + key + "=.*?(&|#|$)", "i");
            if( value === undefined ) {
                if (uri.match(re)) {
                    return uri.replace(re, '$1$2');
                } else {
                    return uri;
                }
            } else {
                if (uri.match(re)) {
                    return uri.replace(re, '$1' + key + "=" + value + '$2');
                } else {
                    var hash =  '';
                    if( uri.indexOf('#') !== -1 ){
                        hash = uri.replace(/.*#/, '#');
                        uri = uri.replace(/#.*/, '');
                    }
                    var separator = uri.indexOf('?') !== -1 ? "&" : "?";
                    return uri + separator + key + "=" + value + hash;
                }
            }
        }

        /**
         * Function to add vr format attributes in delight player
         * @method setVrFormat
         * @param {Element} delightElement [delight video player element]
         * @void
         */
        function setVrFormat(delightElement) {
            if(delightElement) {
                var format = findFormat(vrProps.projection, vrProps.stereoType),
                    fallbackCOR = delightElement.getAttribute('cors-fallback-url'),
                    formattedCorUrl = updateQueryStringParameter('format', format  , fallbackCOR);

                // Sending the right format to video attribute
                delightElement.setAttribute('format', format);

                // Sending the right format to fallback url format params
                delightElement.setAttribute('cors-fallback-url', formattedCorUrl);
            }
        }

        /**
         * Function to play vcs server when player is played
         * @method pingVcsHandler
         * @param {Element} delightElement [delight video player element]
         * @void
         */
        function pingVcsHandler(delightElement) {
            if(delightElement) {
                var myKeyList = PlayerWidgetCommonMethods.getKeys(playerObjList),
                    embedId   = playerObjList[myKeyList[0]].flashvars.embedId,
                    flashvars = window['flashvars_' + embedId],
                    vcServerUrl = flashvars.vcServerUrl || null;

                delightElement.addEventListener('play', function(e){
                    PlayerWidgetCommonMethods.setVcServerUrl(vcServerUrl);
                    PlayerWidgetCommonMethods.pingVCS;
                });
            }
        }

        return {
            setVrFormat: setVrFormat,
            pingVcsHandler: pingVcsHandler
        };
    })();

    // Ping VcServer for vr videos
    (function() {
        var videoPlaceHolder = document.getElementById('videoPlayerPlaceholder'),
            delightElement = document.querySelector('dl8-video');

        if (typeof VIDEO_SHOW != 'undefined' && VIDEO_SHOW.isVr  && delightElement) {
            videoPlaceHolder ? videoPlaceHolder.style.display = "block" : '';
            VrFormatFinder.setVrFormat(delightElement);

            if(!VIDEO_SHOW.isPremium)
                VrFormatFinder.pingVcsHandler(delightElement);
        } else {
            phPlayerComponent.initializePlayer();
        }
    })();
</script>
    
                                                                <div id="pb_template">
                                    <div id="pb_block">
                                        <div id="pb_top_bar">
                                            <span id="pb_header_button_block">
                                                <span id="pb_tj_logo" class="pb-block-sprite-bg" data-url="/information/advertising"></span>
                                                <span id="pb_close_button" role="button" aria-label="close pause role">
                                                    <span class="icon pb-block-sprite-bg"></span>
                                                </span>
                                            </span>
                                        </div>
                                        <div id="pb_content">
                                            <div id="pb_iframe"></div>
                                            <div class="reset"></div>
                                        </div>
                                        <div id="resume_button" role="button" aria-label="resume video">
                                            <span id="resume_arrow"></span>
                                            <span id="resume_text">Resume</span>
                                        </div>
                                    </div>
                                </div>
                                <script type="text/javascript">
                                    var ad_segment_id   = 'straight',
                                        segment         = 2517111,
                                        iframe_url      = "<ins class='adsbytrafficjunky' data-spot-id='2517111' data-height='250' data-width='300'  style='width:300;height:250;display:block;margin:0 auto;'></ins>";
                                        ad_player_id    = '474848195';
                                        isTrailerVideo  = false;
                                </script>
                                                    </div>

                                                <div class="empty_uBlock"></div>

                                                <div class="p52np1uwwwz1r p52np1uwwwz1u hd clear">
                            <div>
                                <ins class='adsbytrafficjunky' data-spot-id='2517121' data-height='90' data-width='970'  style='width:970;height:90;display:block;margin:0 auto;'></ins>                            </div>
                        </div>

                                                <div class="title-container">
                            



    <h1  class="title">

                <span class="inlineFree">EP5 Part 2 Teddy Tarantino | Jail Talks To 200 Employees!</span>
    </h1>
                                <div class="clear"></div>
                        </div>

                                                                                <div class="video-actions-menu ctasActionMenu">
                                                                <div class="ratingInfo">
        <div class="views"><span class="count">56.2K</span> Views</div>
            <div class="videoInfo">7 months ago</div>
    </div>

                                                                <div class="allActionsContainer">
                                <div id="js-shareData" class="tab-menu-wrapper-table" data-duration="3091" data-share-url="https://www.pornhub.com/view_video.php?viewkey=68d18a4de7806">
    <div class="tab-menu-wrapper-row">

                    <div class="tab-menu-wrapper-cell videoCtaPill">
                <div
                    id="addToTab"
                    class="gtm-event-video-underplayer tab-menu-item tooltipTrig"
                    data-event="video_underplayer" data-label="add_to_tab"
                    data-tab="add-to-tab"
                    data-title="Add to"
                    role="button"
                    aria-label="add to playlist button"
                    tabindex="0"
                >
                                            <svg class="addToIcon" width="20" height="21" viewBox="0 0 20 21">
    <mask id="path-1-inside-1_24452_2541">
        <path d="M0.833328 7.16419C0.833328 3.85048 3.51962 1.16418 6.83333 1.16418H13.1667C16.4804 1.16418 19.1667 3.85048 19.1667 7.16419V13.4975C19.1667 16.8112 16.4804 19.4975 13.1667 19.4975H6.83333C3.51962 19.4975 0.833328 16.8112 0.833328 13.4975V7.16419Z"/>
    </mask>
    <path d="M6.83333 2.16418H13.1667V0.164185H6.83333V2.16418ZM18.1667 7.16419V13.4975H20.1667V7.16419H18.1667ZM13.1667 18.4975H6.83333V20.4975H13.1667V18.4975ZM1.83333 13.4975V7.16419H-0.166672V13.4975H1.83333ZM6.83333 18.4975C4.07191 18.4975 1.83333 16.2589 1.83333 13.4975H-0.166672C-0.166672 17.3635 2.96734 20.4975 6.83333 20.4975V18.4975ZM18.1667 13.4975C18.1667 16.2589 15.9281 18.4975 13.1667 18.4975V20.4975C17.0327 20.4975 20.1667 17.3635 20.1667 13.4975H18.1667ZM13.1667 2.16418C15.9281 2.16418 18.1667 4.40276 18.1667 7.16419H20.1667C20.1667 3.29819 17.0327 0.164185 13.1667 0.164185V2.16418ZM6.83333 0.164185C2.96734 0.164185 -0.166672 3.29819 -0.166672 7.16419H1.83333C1.83333 4.40276 4.07191 2.16418 6.83333 2.16418V0.164185Z" mask="url(#path-1-inside-1_24452_2541)"/>
    <path d="M14.1667 11.4419H11.1111V14.4975C11.1111 15.0577 10.6528 15.516 10.0926 15.516C9.53241 15.516 9.07407 15.0577 9.07407 14.4975V11.4419H6.01852C5.45833 11.4419 5 10.9836 5 10.4234C5 9.86322 5.45833 9.40488 6.01852 9.40488H9.07407V6.34933C9.07407 5.78914 9.53241 5.33081 10.0926 5.33081C10.6528 5.33081 11.1111 5.78914 11.1111 6.34933V9.40488H14.1667C14.7269 9.40488 15.1852 9.86322 15.1852 10.4234C15.1852 10.9836 14.7269 11.4419 14.1667 11.4419Z"/>
</svg>
                                        <span>Add to</span>
                </div>
            </div>
        
                    <div class="tab-menu-wrapper-cell videoCtaPill">
                <div
                    id="jsShare"
                    data-event="video_underplayer" data-label="share_tab"
                    class="gtm-event-video-underplayer tab-menu-item shareTrig js-triggerShare shareTabBtn"
                    data-tab="share-tab"
                    data-title=""
                    role="button"
                    aria-label="share video"
                >
                                            <svg class="shareIcon" width="20" height="21" viewBox="0 0 20 21">
    <path d="M17.7022 7.47156L11.6337 2.11807C11.5625 2.05498 11.4764 2.01529 11.3854 2.00361C11.2944 1.99193 11.2023 2.00873 11.1197 2.05208C11.0371 2.09543 10.9674 2.16354 10.9186 2.24853C10.8699 2.33351 10.8441 2.43189 10.8443 2.53227V5.2724C10.8441 5.3336 10.8228 5.39245 10.7847 5.43714C10.7465 5.48183 10.6943 5.50904 10.6386 5.51331C8.28515 5.72281 6.08985 6.89519 4.48925 8.79732C2.88865 10.6995 2 13.192 2 15.7793V17.7643C2.00142 17.8212 2.02109 17.8758 2.05554 17.9184C2.08999 17.961 2.13703 17.9889 2.18841 17.9973C2.23979 18.0057 2.29224 17.9941 2.33654 17.9643C2.38084 17.9346 2.41418 17.8887 2.43071 17.8348C2.99095 15.8856 4.06732 14.163 5.52306 12.8857C6.9788 11.6083 8.7482 10.834 10.6065 10.6611C10.6369 10.6586 10.6674 10.663 10.6962 10.674C10.725 10.685 10.7514 10.7025 10.7737 10.7253C10.7961 10.748 10.8139 10.7756 10.826 10.8063C10.8382 10.8369 10.8444 10.87 10.8443 10.9034V13.7549C10.8441 13.8552 10.8699 13.9536 10.9186 14.0386C10.9674 14.1236 11.0371 14.1917 11.1197 14.235C11.2023 14.2784 11.2944 14.2952 11.3854 14.2835C11.4764 14.2718 11.5625 14.2321 11.6337 14.1691L17.7022 8.81557C17.795 8.73554 17.87 8.63348 17.9216 8.51707C17.9732 8.40067 18 8.27296 18 8.14356C18 8.01416 17.9732 7.88644 17.9216 7.77003C17.87 7.65363 17.795 7.55158 17.7022 7.47156Z"/>
</svg>
                                        <span>Share</span>
                </div>
            </div>
        
                    <div class="tab-menu-wrapper-cell videoCtaPill">
                <div
                    id="video_flag"
                    class="gtm-event-video-underplayer flag-btn tab-menu-item tooltipTrig"
                    data-event="video_underplayer" data-label="report"
                    data-tab="report-tab"
                    data-title="Report this content"
                    role="button"
                    aria-label="report video"
                    tabindex="0"
                >
                                            <svg class="reportIcon" width="21" height="20" viewBox="0 0 21 20">
    <path d="M12.0097 5.09798L12.0901 5.49992H12.5H16.3333C16.5155 5.49992 16.6667 5.65106 16.6667 5.83325V12.4999C16.6667 12.6821 16.5155 12.8333 16.3333 12.8333H12.0167C11.8494 12.8333 11.7196 12.7217 11.6911 12.5725L11.6911 12.5725L11.6903 12.5685L11.4903 11.5685L11.4099 11.1666H11H6.33332H5.83332V11.6666V16.6666C5.83332 16.8488 5.68218 16.9999 5.49999 16.9999C5.3178 16.9999 5.16666 16.8488 5.16666 16.6666V4.16659C5.16666 3.98439 5.3178 3.83325 5.49999 3.83325H11.4833C11.6458 3.83325 11.7805 3.94887 11.8093 4.09592L11.8093 4.09593L11.8097 4.09798L12.0097 5.09798Z"/>
</svg>
                                        <span>Report</span>
                </div>
            </div>
        
    </div>
</div>
<script>
    var WIDGET_VIDEOS_SHOW_TABS = {"loggedInUser":false}</script>

                                

                                                                        
<div class="votes-fav-wrap">
<div class="videoCtaPill ratingWrap">
	<div class="gtm-event-video-underplayer js-voteUp icon-wrapper thumbs-upBtn tooltipTrig likeEnabled"
         data-title="I Like This"
         data-event="video_underplayer" data-label="upvote"
        role="button"
        aria-label="vote up button"
        tabindex="0"
    >
                    <svg xmlns="http://www.w3.org/2000/svg" class="thumbUpIcon"  width="21" height="20" viewBox="0 0 19 17" fill="none">
    <path d="M1.66699 6.65332C2.30722 6.6535 2.83275 7.17913 2.83301 7.81934V14.4863C2.83301 15.1267 2.30737 15.6531 1.66699 15.6533C1.02647 15.6533 0.5 15.1269 0.5 14.4863V7.81934C0.500253 7.17902 1.02662 6.65332 1.66699 6.65332ZM10.0996 0.370117L10.457 0.720703C10.7433 0.429572 11.2095 0.424675 11.5078 0.717773C11.6843 0.896157 11.7595 1.14788 11.71 1.40137L10.9189 5.21777L10.7939 5.81934H16.1162C17.5478 5.81934 18.5166 7.28555 17.9561 8.60742L15.2422 14.9443C15.0537 15.374 14.6313 15.6532 14.167 15.6533H6.66699C6.02647 15.6533 5.5 15.1269 5.5 14.4863V6.16113C5.50009 5.85049 5.62362 5.55314 5.83691 5.33984L10.4531 0.723633L10.0996 0.370117Z" stroke="#C6C6C6"/>
</svg>
                		<span class="votesUp" data-rating="15">15</span>
	</div>
            <span class="divider">|</span>
    	<div class="gtm-event-video-underplayer js-voteDown icon-wrapper tooltipTrig"
         data-title="I Dislike This"
         data-event="video_underplayer" data-label="downvote"
         role="button"
         aria-label="vote down button"
         tabindex="0"
    >
                    <svg class="thumbDownIcon" width="21" height="20" viewBox="0 0 21 20">
    <path d="M9.21311 17.9297L9.2131 17.9297L9.2101 17.9328C8.92431 18.2235 8.45871 18.2283 8.16035 17.9365C7.98241 17.7576 7.90619 17.5044 7.95665 17.2495C7.95675 17.249 7.95685 17.2485 7.95696 17.248L8.74791 13.4348L8.87269 12.8333L8.25833 12.8333L3.55 12.8333C2.11862 12.8333 1.14989 11.3678 1.70993 10.0461C1.71005 10.0458 1.71017 10.0455 1.71029 10.0452L4.4246 3.70901C4.42486 3.70843 4.42512 3.70784 4.42537 3.70725C4.61421 3.27833 5.03617 2.99994 5.5 2.99994L13 2.99994C13.6405 2.99994 14.1667 3.52609 14.1667 4.16661L14.1667 12.4916C14.1667 12.8024 14.0431 13.0997 13.8298 13.3131L9.21311 17.9297ZM16.8333 4.16661C16.8333 3.52609 17.3595 2.99994 18 2.99994C18.6405 2.99994 19.1667 3.52609 19.1667 4.16661L19.1667 10.8333C19.1667 11.4738 18.6405 11.9999 18 11.9999C17.3595 11.9999 16.8333 11.4738 16.8333 10.8333L16.8333 4.16661Z"/>
</svg>
            </div>

    </div>
                        <div class="gtm-event-video-underplayer js-favoriteBtn videoCtaPill icon-wrapper favorite-wrapper tooltipTrig" data-event="video_underplayer" data-label="favorite" data-title="Login or sign up to add to favorites">
                                    <svg class="favIcon" width="21" height="20" viewBox="0 0 21 20">
    <path d="M11.2861 16.6929L11.2845 16.6944C10.8436 17.1029 10.167 17.1028 9.72596 16.6883L9.72358 16.6861L9.63195 16.6011L9.63108 16.6003C7.43412 14.572 5.66015 12.931 4.4424 11.3907C3.23216 9.85995 2.62079 8.48861 2.66936 7.00544C2.7143 5.71016 3.3657 4.47417 4.40418 3.75269L4.40445 3.7525C6.35758 2.39366 8.78892 3.01259 10.1164 4.59806L10.4998 5.05592L10.8831 4.59806C12.2117 3.01133 14.6425 2.38645 16.594 3.75176L16.5954 3.75269C17.634 4.47425 18.2854 5.71043 18.3302 7.00588L18.3302 7.00626C18.3826 8.48872 17.7718 9.85965 16.5602 11.3929C15.3454 12.9303 13.5775 14.5693 11.3907 16.5967L11.3694 16.6164L11.3677 16.618L11.2861 16.6929Z"/>
</svg>
                <span>Favorites</span>
                    </div>
    
        </div>

    <div id="favoriteConfirmation" class="ctas">
        <i class="ph-icon-favorite"></i>
        <span class="confirmationMsg">Added to your Favorites</span>
        <button class="js-triggerFavorite">Undo</button>
    </div>

    <div id="js-videoLikedSnackbar" class="videoLikedSnackbar ctas">
        <i class="ph-icon-thumb-up"></i>
        <span class="confirmationMsg default">Video Liked</span>
        <a href="https://www.pornhub.com/likedvideos" target="_blank" class="viewVideosLink default gtm-event-likedvideos" data-event="liked_videos" data-label="snackbar">View liked videos</a>
        <span class="confirmationMsg limited displayNone">Video Liked! Sign up to store more Liked Videos</span>
        <a onclick="signinbox.show({step:'signUpVideoLikedWatchPage'}); return false;" href="/signup?redirect=Zo1UrMlP8WXMmeizBJHvsje53-jfuXHkVklg4GNrk2Lwh26z5EmtKv9pLxXVUWSLmVTRplWIwVat_1F59oKlg2oQaVdf-MmdBv4MiXdRRNFbtuyt9dmDm9kxKABqe8or-zFdK2zoBjbcPrZY9klznKTdHQI%3D" class="viewVideosLink limited displayNone gtm-event-likedvideos" data-event="liked_videos" data-label="snackbar_signup">Sign up</a>
    </div>

<script type="text/javascript">
	var WIDGET_RATINGS_LIKE_FAV = {"controller":"video","controllerUc":"Video","favouriteUrl":"\/video\/favourite","itemId":474848195,"itemIdNum":474848195,"isFavourite":0,"loggedIn":0,"text1":"Liked","spinnerUrl":"https:\/\/ei.phncdn.com\/www-static\/images\/ajax-loader-1B1B1B.gif","voteUrl":"\/api\/v1\/video\/rate?id=474848195&token=MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8.","currentUp":15,"currentDown":7,"canVote":true,"canDownVoteBlocker":true,"saleVideo":null,"voteModalText":"You need to log in and purchase this video<\/br> in order to vote.","isViewshare":null,"isPremium":false,"translation":{"warningMsg":"Warning","tooltipMsg1":"Remove from favorites","tooltipMsg2":"Add to Favorites"},"userVotedVideoDetail":null,"useFetch":false,"token":"MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8.","canCreateClip":false};

    </script>

                                </div>
                                <div class="reset"></div>
                            </div>

                                                        <div class="video-actions-container">
                                                                <div class="video-actions-tabs">
                                <div class="video-action-tab share-tab">
    <div class="video-actions-sub-menu">
        <div class="gtm-event-video-underplayer tab-sub-menu-item active js-triggerShare" data-event="video_underplayer" data-label="share_with_your_friends" data-tab="social">
            <span>With your friends</span>
        </div>

                    <div class="gtm-event-video-underplayer tab-sub-menu-item" data-event="video_underplayer" data-label="share_embed" data-tab="embed">
                <span>Embed</span>
            </div>
                <div class="reset"></div>
    </div>
    <div id="js-tabData" class="video-actions-sub-tabs"
         data-default="&amp;lt;iframe src=&amp;quot;https://www.pornhub.com/embed/68d18a4de7806&amp;quot; frameborder=&amp;quot;0&amp;quot; width=&amp;quot;560&amp;quot; height=&amp;quot;315&amp;quot; scrolling=&amp;quot;no&amp;quot; allowfullscreen&amp;gt;&amp;lt;/iframe&amp;gt;"
         data-small="&amp;lt;iframe src=&amp;quot;https://www.pornhub.com/embed/68d18a4de7806&amp;quot; frameborder=&amp;quot;0&amp;quot; width=&amp;quot;640&amp;quot; height=&amp;quot;360&amp;quot; scrolling=&amp;quot;no&amp;quot; allowfullscreen&amp;gt;&amp;lt;/iframe&amp;gt;"
         data-large="&amp;lt;iframe src=&amp;quot;https://www.pornhub.com/embed/68d18a4de7806&amp;quot; frameborder=&amp;quot;0&amp;quot; width=&amp;quot;1200&amp;quot; height=&amp;quot;720&amp;quot; scrolling=&amp;quot;no&amp;quot; allowfullscreen&amp;gt;&amp;lt;/iframe&amp;gt;"
         data-medium="&amp;lt;iframe src=&amp;quot;https://www.pornhub.com/embed/68d18a4de7806&amp;quot; frameborder=&amp;quot;0&amp;quot; width=&amp;quot;853&amp;quot; height=&amp;quot;480&amp;quot; scrolling=&amp;quot;no&amp;quot; allowfullscreen&amp;gt;&amp;lt;/iframe&amp;gt;"
         data-url="/video/share?vkey=68d18a4de7806&token=MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8.">
        <div class="video-action-sub-tab social active">
            <div class="share-sites-thumbs">
            <script type="text/template" class="js_shareListItems">
    <ul class="shareIcons clearfix">
        <li><a data-event="video_underplayer" data-label="twitter" target="_blank" rel="noopener noreferrer nofollow" href="//twitter.com/intent/tweet?utm_source=twitter&utm_medium=social&text=EP5%20Part%202%20Teddy%20Tarantino%20%7C%20Jail%20Talks%20To%20200%20Employees%21" class="gtm-event-video-underplayer twitterX" ><i class="ph-icon-square-twitterX twitterX-icon tooltipTrig" data-title="Post to X"><span class="path1"></span><span class="path2"></span></i></a></li>
        <li><a data-event="video_underplayer" data-label="reddit" target="_blank" rel="noopener noreferrer nofollow" href="//www.reddit.com/submit?url=&title=EP5 Part 2 Teddy Tarantino | Jail Talks To 200 Employees!" class="gtm-event-video-underplayer sharesLink sharesReddit tooltipTrig" data-title="Send to Reddit"><span>Reddit</span></a></li>
    </ul>
</script>


<script type="text/javascript">
	var WIDGET_SHARE = {"shareButtonsLoaded":false,"urlShare":null,"shareTitle":"EP5 Part 2 Teddy Tarantino | Jail Talks To 200 Employees!"}</script>
            </div>

            <div class="share-link-container">
                <input type="text" id="share-link" onclick="$j(this).select();" />
                <input type="checkbox" id="chkShareLinkStartTime" />
                <span class="checkbox js-fakeCheck"></span>
                <input type="text" id="share-link-start-time" placeholder="0:00" />
                <button class="copy js-copy">Copy</button>
            </div>

            <div class="reset"></div>
        </div>
        
        <div class="video-action-sub-tab embed">
            <textarea onclick="this.select()"></textarea>

            <div class="embedSizeFilter">
                <label>Video size:</label>
                <div class="filters">
                    <div class="dropdownTrigger">
                        <div>
                            <span class="textFilter">560 x 315</span>
                            <span class="arrowFilters"></span>
                        </div>
                        <ul class="filterListItem dropdownWrapper" style="display: none;">
                            <li class="active alpha" data-size-x="560" data-size-y="315"><span>560 x 315</span></li>
                            <li data-size-x="640" data-size-y="360"><span>640 x 360</span></li>
                            <li data-size-x="853" data-size-y="480"><span>853 x 480</span></li>
                            <li class="omega" data-size-x="1200" data-size-y="720"><span>1200 x 720</span></li>
                        </ul>
                    </div>
                </div>
                <div class="reset"></div>
            </div>
        </div>

        <div class="video-action-sub-tab share-to-my-stream">
            <form id="shareToStream" method="post">
                <input name="table" type="hidden" value="stream_posts_videos">
                <input name="attachment" type="hidden" id="attachment" value="474848195">

                
                <textarea name="caption" placeholder="Say something..." cols="30" rows="10"></textarea>
                <div class="thumbnail">
                    <img loading="lazy" src="https://pix-cdn77.phncdn.com/c6251/videos/202509/22/23608935/original/019986c1-5734-7796-8f71-b4d7171ec603.jpg/plain/rs:fit:320:240?hash=8qblwJ7_43hfhuF2gORaafOgCh8=&validto=1779644641" alt="EP5 Part 2 Teddy Tarantino | Jail Talks To 200 Employees!">
                </div>
                <div class="title">EP5 Part 2 Teddy Tarantino | Jail Talks To 200 Employees!</div>
                <div class="from">
                    From:

	<div class="usernameWrap clearfix" data-type="user" data-userid="3157729341" data-liu-user="0" data-disable-popover="0">

						<span class="usernameBadgesWrapper"><a rel="rel="nofollow"" href="/users/lexisstarshow"  class="bolded">lexisstarshow</a><i class="bg-sprite-icons-profile producer-icon userBadges spriteUi" data-title="Content Partner" ></i></span>					<div class="avatarPosition"></div>
	</div>

                </div>
                <hr>
                                    <button onclick="signinbox.show({step:'signUp'});">Post to My Stream</button>
                            </form>
        </div>
    </div>
    <div class="closeActionTab js-closeActionTab">
        Close    </div>
</div>

                                <div class="video-action-tab add-to-tab">
                    <div class="video-actions-sub-menu">
                <div data-event="video_underplayer" data-label="add_to_playlist" class="gtm-event-video-underplayer js-subItem tab-sub-menu-item js-playlistSpan active" data-tab="playlist-tab">
                    <span data-tab="playlist-tab">Add to playlist</span>
                </div>

                                <div class="reset"></div>
            </div>

            <div class="video-actions-sub-tabs js-videoTabs">
                <div class="video-action-sub-tab playlist-tab active js-playlist-tab">
                                            <div class="notLoggedIn">
                            <a href="javascript:signinbox.show({'origin_item_id':'add-to-playlist', head: 'playlist'});">
                                Login                            </a>
                            or                            <a href="javascript:void(0)" onclick="signinbox.show({step:'signUp', head: 'playlist'});userClogTracking(currentDomain, 'signup-open', originPart, originUrl, 'add-to-playlist', newModal);">
                                Sign Up                            </a>
                            now to add this video!                        </div>
                                    </div>
                <div class="video-action-sub-tab stream-tab addToStream js-stream-tab clearfix">
                                            <div class="notLoggedIn">
                            <a href="javascript:signinbox.show({'origin_item_id':'add-to-stream'});">
                                Login                            </a>
                            or                            <a href="javascript:void(0)" onclick="signinbox.show({step:'signUp'});userClogTracking(currentDomain, 'signup-open', originPart, originUrl, 'add-to-playlist', newModal);">
                                Sign Up                            </a>
                            now to add this video to stream!                        </div>
                                    </div>
            </div>
        
    <div class="closeActionTab js-closeActionTab" tabindex="0">
        Close    </div>
</div>

                                <div class="video-action-tab jump-to-tab clearfix">
    <div class="title">Jump to your favorite action</div>

    <div class="reset"></div>
                <div class="sortBy seconds">
            <ul class="display-grid actionTagList">
                            </ul>
        </div>
            <div class="sortBy tag">
            <ul class="display-grid actionTagList">
                            </ul>
        </div>
    
    <div class="closeActionTab js-closeActionTab" tabindex="0">
        Close    </div>
</div>

                                    <div class="video-detailed-info">
                                                                                    <div class="video-info-row userRow">
                                                <div class="userInfoBlock">
                                                                                                            <div class="userAvatar">
                                                            <a href="/users/lexisstarshow" class="userAvatarLink">
                                                                <img loading="lazy" src="https://ei.phncdn.com/pics/users/default/pornhub/(m=bJWsSeKlbyaT)(mh=4N6NZAtseWL0p9UF)male.jpg" alt="avatar">
                                                            </a>
                                                        </div>
                                                                                                        <div class="userInfo">
                                                                                                                    

	<div class="usernameWrap clearfix" data-type="user" data-userid="3157729341" data-liu-user="0" data-disable-popover="1">

						<span class="usernameBadgesWrapper"><a rel="rel="nofollow"" href="/users/lexisstarshow"  class="bolded">lexisstarshow</a><i class="bg-sprite-icons-profile producer-icon userBadges spriteUi" data-title="Content Partner" ></i></span>					<div class="avatarPosition"></div>
	</div>

                                                                                                                <span>118 Videos</span>
                                                        <span class="line"></span>
                                                        <span>31 Subscribers</span>
                                                    </div>
                                                </div>
                                            </div>
                                                                            </div>
                                </div>
                                <div class="clear"></div>
                            </div>
                                            </div>
                </div>
                <div class="sideColumn">
                                            <div class="extraRelatedVid latestThumbDesign">
                            <ul class="videos">
                                                                                                                                                                                                                                                                                                                                                                                                                        <li class="pcVideoListItem js-pop videoblock fixedSizeThumbContainer"
                    id="v105683592"
        data-video-id="105683592"
    data-type="video"
    data-video-vkey="ph589e1e99719a7"
    data-id="105683592"
    data-segment="straight"
    data-entrycode="VidPg-premVid"
        tabindex="0"
    data-event-label=""
>
    <div class="wrap flexibleHeight">
                    <div class="phimage"
                            >
                                                    <div class="preloadLine"></div>
                                                                                            <a data-event="thumb_click" data-label="side_video_container" data-label2="1" href="/view_video.php?viewkey=ph589e1e99719a7" title="Pornhub Aria Gets Nasty with Comedians Bobby Slayton &amp; Brad Williams"                        class="latestThumb fade  videoPreviewBg gtm-event-thumb-click linkVideoThumb js-linkVideoThumb img "
                        data-related-url="/api/v1/video/ajax_related_video?vkey=ph589e1e99719a7"
                        data-video-id="105683592"
                        data-label3="thumbnail"                                            >
                        
                                                                                                                                                    <img
                                src="https://ei.phncdn.com/videos/201702/10/105683592/original/(m=edLTGgaaaa)(mh=ynCmFRvPMQjHj0fQ)9.jpg"
                                alt="Pornhub Aria Gets Nasty with Comedians Bobby Slayton &amp; Brad Williams"
                                data-pix=""                                loading="lazy"
                                                                    data-mediumthumb="https://ei.phncdn.com/videos/201702/10/105683592/original/(m=edLTGgaaaa)(mh=ynCmFRvPMQjHj0fQ)9.jpg"
                                                                                                                                    data-mediabook="https://kw.phncdn.com/videos/201702/10/105683592/180P_312K_105683592.webm?hdnea=st=1779557883~exp=1779561483~hdl=-1~hmac=e164c49b717be124c43c52b6d689bb86d44f94b8"
                                                                class=" js-pop js-videoThumb js-videoThumbFlip thumb js-videoPreview"
                                width="320" height="180"
                                                                title="Pornhub Aria Gets Nasty with Comedians Bobby Slayton &amp; Brad Williams" />
                                                                                                                        
                        <div class="marker-overlays js-noFade">
                                                            <var class="bgShadeEffect duration tooltipTrig" data-title="Video Duration">5:23</var>
                                                        
                                                                                                                                                                                                                            </div>

                                                                    </a>
            </div>
                            <div class="thumbnail-info-wrapper clearfix">
                                    <div class="videoUploaderBlock">
                        <div class="usernameWrapper">
                            <div class="usernameWrap">
                                                                                                                                            <a href="/channels/pornhubtv" class="bolded gtm-event-watch-page" data-event="watch_page" data-label="thumb_username">Pornhub TV</a>
                                                                                                </div>
                                                            <span class="channel-icon main-sprite searchPageIcon"></span>
                                                        </div>
                        <div class="videoDetailBlock">
                                                                                            <span class="views"><i class="ph-icon-view-on tooltipTrig" data-title="Total Views"></i><var>116K</var></span>
                                                                                            
                                                        <var class="added">9 years ago</var>
                        </div>
                    </div>
                                <div class="vidTitleWrapper">
                    <span class="title">
                                                                                    <a data-event="thumb_click" data-label="side_video_container" data-label2="1" href="/view_video.php?viewkey=ph589e1e99719a7" title="Pornhub Aria Gets Nasty with Comedians Bobby Slayton &amp; Brad Williams" class="thumbnailTitle  gtm-event-thumb-click"                                                                        data-label3="title"                                >
                                    Pornhub Aria Gets Nasty with Comedians Bobby Slayton &amp; Brad Williams                                </a>
                                                                        </span>
                                            <div class="rightAlign moreActionMenuButton gtm-event-actionmenu"
                             data-video-id="105683592"
                             data-token="MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8."
                             data-event="action_menu_watchpage"
                             data-label="menu_open"
                             data-menu-id="105683592" data-menu-can-add-to-playlist="1" data-menu-added-to-playlist="0" data-menu-is-private-member="0" data-menu-is-blocked="0" data-menu-is-pornhub="0" data-menu-is-channel="1" data-menu-is-content-partner="0" data-menu-is-subscribed="0" data-menu-is-compilation="false" data-menu-subscribe-id="7091" data-menu-can-subscribe="1" data-menu-title="Pornhub TV"                        >
                            <span class="ph-icon-kebab-menu"></span>
                        </div>
                                    </div>
                            </div>
                    </div>
    </li>

<li class="pcVideoListItem js-pop videoblock fixedSizeThumbContainer"
                    id="v479247305"
        data-video-id="479247305"
    data-type="video"
    data-video-vkey="6954458f83d0f"
    data-id="479247305"
    data-segment="straight"
    data-entrycode="VidPg-premVid"
        tabindex="0"
    data-event-label=""
>
    <div class="wrap flexibleHeight">
                    <div class="phimage"
                            >
                                                    <div class="preloadLine"></div>
                                                                                            <a data-event="thumb_click" data-label="side_video_container" data-label2="2" href="/view_video.php?viewkey=6954458f83d0f" title="Leilani Li Unfiltered: Confidence, Curiosity &amp; Crossing Every Line"                        class="latestThumb fade  videoPreviewBg gtm-event-thumb-click linkVideoThumb js-linkVideoThumb img "
                        data-related-url="/api/v1/video/ajax_related_video?vkey=6954458f83d0f"
                        data-video-id="479247305"
                        data-label3="thumbnail"                                            >
                        
                                                                                                                                                    <img
                                src="https://pix-cdn77.phncdn.com/c6251/videos/202512/30/34335285/original/019cbfd4-ab82-7d76-9ece-16db5541fcbc.jpg/plain/rs:fit:323:182?hash=RPxM89HDQR7SsOt7pb5ePgq9A5s=&validto=1779644131"
                                alt="Leilani Li Unfiltered: Confidence, Curiosity &amp; Crossing Every Line"
                                data-pix=""                                loading="lazy"
                                                                    data-mediumthumb="https://pix-cdn77.phncdn.com/c6251/videos/202512/30/34335285/original/019cbfd4-ab82-7d76-9ece-16db5541fcbc.jpg/plain/rs:fit:323:182?hash=RPxM89HDQR7SsOt7pb5ePgq9A5s=&validto=1779644131"
                                                                                                                                    data-mediabook="https://kw.phncdn.com/c6251/videos/202512/30/34335285/180P_225K_34335285.webm?hdnea=st=1779557731~exp=1779561331~hdl=-1~hmac=22497ec7b223aeeccc5452d0f29aed8293dae519"
                                                                class=" js-pop js-videoThumb js-videoThumbFlip thumb js-videoPreview"
                                width="320" height="180"
                                                                title="Leilani Li Unfiltered: Confidence, Curiosity &amp; Crossing Every Line" />
                                                                                                                        
                        <div class="marker-overlays js-noFade">
                                                            <var class="bgShadeEffect duration tooltipTrig" data-title="Video Duration">51:59</var>
                                                        
                                                                                                                                                                                                                            </div>

                                                                    </a>
            </div>
                            <div class="thumbnail-info-wrapper clearfix">
                                    <div class="videoUploaderBlock">
                        <div class="usernameWrapper">
                            <div class="usernameWrap">
                                                                                                                                            <a href="/channels/holly-randall" class="bolded gtm-event-watch-page" data-event="watch_page" data-label="thumb_username">Holly Randall</a>
                                                                                                </div>
                                                            <span class="channel-icon main-sprite searchPageIcon"></span>
                                                        </div>
                        <div class="videoDetailBlock">
                                                                                            <span class="views"><i class="ph-icon-view-on tooltipTrig" data-title="Total Views"></i><var>30.1K</var></span>
                                                                                            
                                                        <var class="added">2 months ago</var>
                        </div>
                    </div>
                                <div class="vidTitleWrapper">
                    <span class="title">
                                                                                    <a data-event="thumb_click" data-label="side_video_container" data-label2="2" href="/view_video.php?viewkey=6954458f83d0f" title="Leilani Li Unfiltered: Confidence, Curiosity &amp; Crossing Every Line" class="thumbnailTitle  gtm-event-thumb-click"                                                                        data-label3="title"                                >
                                    Leilani Li Unfiltered: Confidence, Curiosity &amp; Crossing Every Line                                </a>
                                                                        </span>
                                            <div class="rightAlign moreActionMenuButton gtm-event-actionmenu"
                             data-video-id="479247305"
                             data-token="MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8."
                             data-event="action_menu_watchpage"
                             data-label="menu_open"
                             data-menu-id="479247305" data-menu-can-add-to-playlist="1" data-menu-added-to-playlist="0" data-menu-is-private-member="0" data-menu-is-blocked="0" data-menu-is-pornhub="0" data-menu-is-channel="1" data-menu-is-content-partner="0" data-menu-is-subscribed="0" data-menu-is-compilation="false" data-menu-subscribe-id="42091" data-menu-can-subscribe="1" data-menu-title="Holly Randall"                        >
                            <span class="ph-icon-kebab-menu"></span>
                        </div>
                                    </div>
                            </div>
                    </div>
    </li>

<li class="pcVideoListItem js-pop videoblock fixedSizeThumbContainer"
                    id="v474848195"
        data-video-id="474848195"
    data-type="video"
    data-video-vkey="68d18a4de7806"
    data-id="474848195"
    data-segment="straight"
    data-entrycode="VidPg-premVid"
        tabindex="0"
    data-event-label=""
>
    <div class="wrap flexibleHeight">
                    <div class="phimage"
                            >
                                                    <div class="preloadLine"></div>
                                                                                            <a data-event="thumb_click" data-label="side_video_container" data-label2="3" href="/view_video.php?viewkey=68d18a4de7806" title="EP5 Part 2 Teddy Tarantino | Jail Talks To 200 Employees!"                        class="latestThumb fade  videoPreviewBg gtm-event-thumb-click linkVideoThumb js-linkVideoThumb img "
                        data-related-url="/api/v1/video/ajax_related_video?vkey=68d18a4de7806"
                        data-video-id="474848195"
                        data-label3="thumbnail"                                            >
                        
                                                                                                                                                    <img
                                src="https://pix-cdn77.phncdn.com/c6251/videos/202509/22/23608935/original/019986c1-5734-7796-8f71-b4d7171ec603.jpg/plain/rs:fit:323:182?hash=lFlBc3o2VnbnDsPC9FCRQEnqCRU=&validto=1779644452"
                                alt="EP5 Part 2 Teddy Tarantino | Jail Talks To 200 Employees!"
                                data-pix=""                                loading="lazy"
                                                                    data-mediumthumb="https://pix-cdn77.phncdn.com/c6251/videos/202509/22/23608935/original/019986c1-5734-7796-8f71-b4d7171ec603.jpg/plain/rs:fit:323:182?hash=lFlBc3o2VnbnDsPC9FCRQEnqCRU=&validto=1779644452"
                                                                                                                                    data-mediabook="https://kw.phncdn.com/c6251/videos/202509/22/23608935/180P_225K_23608935.webm?hdnea=st=1779558052~exp=1779561652~hdl=-1~hmac=d08b09203cd488a175eaef814010a7d4cf908887"
                                                                class=" js-pop js-videoThumb js-videoThumbFlip thumb js-videoPreview"
                                width="320" height="180"
                                                                title="EP5 Part 2 Teddy Tarantino | Jail Talks To 200 Employees!" />
                                                                                                                        
                        <div class="marker-overlays js-noFade">
                                                            <var class="bgShadeEffect duration tooltipTrig" data-title="Video Duration">51:31</var>
                                                        
                                                                                                                                                                                                                            </div>

                                                                    </a>
            </div>
                            <div class="thumbnail-info-wrapper clearfix">
                                    <div class="videoUploaderBlock">
                        <div class="usernameWrapper">
                            <div class="usernameWrap">
                                                                                                                                            <a href="/channels/lexis-star-show" class="bolded gtm-event-watch-page" data-event="watch_page" data-label="thumb_username">Lexis Star Show</a>
                                                                                                </div>
                                                            <span class="channel-icon main-sprite searchPageIcon"></span>
                                                        </div>
                        <div class="videoDetailBlock">
                                                                                            <span class="views"><i class="ph-icon-view-on tooltipTrig" data-title="Total Views"></i><var>56.2K</var></span>
                                                                                            
                                                        <var class="added">7 months ago</var>
                        </div>
                    </div>
                                <div class="vidTitleWrapper">
                    <span class="title">
                                                                                    <a data-event="thumb_click" data-label="side_video_container" data-label2="3" href="/view_video.php?viewkey=68d18a4de7806" title="EP5 Part 2 Teddy Tarantino | Jail Talks To 200 Employees!" class="thumbnailTitle  gtm-event-thumb-click"                                                                        data-label3="title"                                >
                                    EP5 Part 2 Teddy Tarantino | Jail Talks To 200 Employees!                                </a>
                                                                        </span>
                                            <div class="rightAlign moreActionMenuButton gtm-event-actionmenu"
                             data-video-id="474848195"
                             data-token="MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8."
                             data-event="action_menu_watchpage"
                             data-label="menu_open"
                             data-menu-id="474848195" data-menu-can-add-to-playlist="1" data-menu-added-to-playlist="0" data-menu-is-private-member="0" data-menu-is-blocked="0" data-menu-is-pornhub="0" data-menu-is-channel="1" data-menu-is-content-partner="0" data-menu-is-subscribed="0" data-menu-is-compilation="false" data-menu-subscribe-id="69525" data-menu-can-subscribe="1" data-menu-title="Lexis Star Show"                        >
                            <span class="ph-icon-kebab-menu"></span>
                        </div>
                                    </div>
                            </div>
                    </div>
    </li>

                            </ul>
                        </div>
                                    </div>
            </div>

                        <div class="video-wrapper js-relatedRecommended js-relatedVideos relatedVideos js-videosTabContent latestThumbDesign" data-tab-content="related">
                <ul class="videos underplayer-thumbs fixedSizeThumbsVideosListing" data-gaBlockName="Related Video Container" id="relatedVideosListing">
                                                                                                <li class="pcVideoListItem js-pop videoblock fixedSizeThumbContainer"
                    id="v475880815"
        data-video-id="475880815"
    data-type="video"
    data-video-vkey="68efa01cbbcb5"
    data-id="475880815"
    data-segment="straight"
    data-entrycode="VidPg-premVid"
        tabindex="0"
    data-event-label="Safe for Work"
>
    <div class="wrap flexibleHeight">
                    <div class="phimage"
                            >
                                                    <div class="preloadLine"></div>
                                                                                            <a href="/view_video.php?viewkey=68efa01cbbcb5" title="EP8 Jasmine Banks | The Most Unexpected Feet Request Ever 😳"                        class="latestThumb fade  videoPreviewBg linkVideoThumb js-linkVideoThumb img "
                        data-related-url="/api/v1/video/ajax_related_video?vkey=68efa01cbbcb5"
                        data-video-id="475880815"
                                                                    >
                        
                                                                                                                                                    <img
                                src="https://pix-fl.phncdn.com/c6251/videos/202510/15/26380165/original/0199ea76-4a7f-7bbb-94d5-c24f6fbf7f39.jpg/plain/rs:fit:320:180?hdnea=st=1779558068~exp=1779644468~hdl=-1~hmac=87960eb9eb56d8719779983cf7b94bf62310dd85"
                                alt="EP8 Jasmine Banks | The Most Unexpected Feet Request Ever 😳"
                                data-pix=""                                loading="lazy"
                                                                    data-mediumthumb="https://pix-fl.phncdn.com/c6251/videos/202510/15/26380165/original/0199ea76-4a7f-7bbb-94d5-c24f6fbf7f39.jpg/plain/rs:fit:320:180?hdnea=st=1779558068~exp=1779644468~hdl=-1~hmac=87960eb9eb56d8719779983cf7b94bf62310dd85"
                                                                                                                                    data-mediabook="https://kw.phncdn.com/c6251/videos/202510/15/26380165/180P_225K_26380165.webm?hdnea=st=1779558068~exp=1779561668~hdl=-1~hmac=6afb5a55b08bc70ebbe7289e78e41807961ea041"
                                                                class=" js-pop js-videoThumb js-videoThumbFlip thumb js-videoPreview"
                                width="320" height="180"
                                                                title="EP8 Jasmine Banks | The Most Unexpected Feet Request Ever 😳" />
                                                                                                                        
                        <div class="marker-overlays js-noFade">
                                                            <var class="bgShadeEffect duration tooltipTrig" data-title="Video Duration">23:28</var>
                                                        
                                                                                                                                                                                                                            </div>

                                                                    </a>
            </div>
                            <div class="thumbnail-info-wrapper clearfix">
                                    <div class="videoUploaderBlock">
                        <div class="usernameWrapper">
                            <div class="usernameWrap">
                                                                                                                                            <a href="/channels/lexis-star-show" class="bolded gtm-event-watch-page" data-event="watch_page" data-label="thumb_username">Lexis Star Show</a>
                                                                                                </div>
                                                            <span class="channel-icon main-sprite searchPageIcon"></span>
                                                        </div>
                        <div class="videoDetailBlock">
                                                                                            <span class="views"><i class="ph-icon-view-on tooltipTrig" data-title="Total Views"></i><var>39.3K</var></span>
                                                                                            
                                                        <var class="added">7 months ago</var>
                        </div>
                    </div>
                                <div class="vidTitleWrapper">
                    <span class="title">
                                                                                    <a href="/view_video.php?viewkey=68efa01cbbcb5" title="EP8 Jasmine Banks | The Most Unexpected Feet Request Ever 😳" class="thumbnailTitle "                                                                                                        >
                                    EP8 Jasmine Banks | The Most Unexpected Feet Request Ever 😳                                </a>
                                                                        </span>
                                            <div class="rightAlign moreActionMenuButton gtm-event-actionmenu"
                             data-video-id="475880815"
                             data-token="MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8."
                             data-event="action_menu_watchpage"
                             data-label="menu_open"
                             data-menu-id="475880815" data-menu-can-add-to-playlist="1" data-menu-added-to-playlist="0" data-menu-is-private-member="0" data-menu-is-blocked="0" data-menu-is-pornhub="0" data-menu-is-channel="1" data-menu-is-content-partner="0" data-menu-is-subscribed="0" data-menu-is-compilation="false" data-menu-subscribe-id="69525" data-menu-can-subscribe="1" data-menu-title="Lexis Star Show"                        >
                            <span class="ph-icon-kebab-menu"></span>
                        </div>
                                    </div>
                            </div>
                    </div>
    </li>

                                                                                                                            <li class='tjListItem js_promoItem'>
        <ins class='adsbytrafficjunky' data-spot-id='2514911' data-type='native' data-height='340px' data-width='480px' data-inbanlabel='false' data-default-image='https://ei.phncdn.com/videos/202312/16/444854471/original/(m=qS15H4YbedLTGgaaaa)(mh=Gm4GueeeT6-i_qSt)0.jpg' data-default-url='/view_video.php?viewkey=657cfaef0edc3'  style='width:480px;height:340px;display:block;margin:0 auto;'></ins>            </li>

                                                                                                                        <li class="pcVideoListItem js-pop videoblock fixedSizeThumbContainer"
                    id="v222159451"
        data-video-id="222159451"
    data-type="video"
    data-video-vkey="ph5cd030d434130"
    data-id="222159451"
    data-segment="straight"
    data-entrycode="VidPg-premVid"
        tabindex="0"
    data-event-label="Safe for Work"
>
    <div class="wrap flexibleHeight">
                    <div class="phimage"
                            >
                                                    <div class="preloadLine"></div>
                                                                                            <a href="/view_video.php?viewkey=ph5cd030d434130" title="I Disagree With The Ads Around This Video, Your Penis Size is Fine As Is"                        class="latestThumb fade  videoPreviewBg linkVideoThumb js-linkVideoThumb img "
                        data-related-url="/api/v1/video/ajax_related_video?vkey=ph5cd030d434130"
                        data-video-id="222159451"
                                                                    >
                        
                                                                                                                                                    <img
                                src="https://ei.phncdn.com/videos/201905/06/222159451/original/(m=eafTGgaaaa)(mh=AoYJa0c4pmAsKTwD)15.jpg"
                                alt="I Disagree With The Ads Around This Video, Your Penis Size is Fine As Is"
                                data-pix=""                                loading="lazy"
                                                                    data-mediumthumb="https://ei.phncdn.com/videos/201905/06/222159451/original/(m=eafTGgaaaa)(mh=AoYJa0c4pmAsKTwD)15.jpg"
                                                                                                                                    data-mediabook="https://kw.phncdn.com/videos/201905/06/222159451/180P_225K_222159451.webm?hdnea=st=1779558171~exp=1779561771~hdl=-1~hmac=e66ed5f6b42984723daefe394de206b6aef06d83"
                                                                class=" js-pop js-videoThumb js-videoThumbFlip thumb js-videoPreview"
                                width="320" height="180"
                                                                title="I Disagree With The Ads Around This Video, Your Penis Size is Fine As Is" />
                                                                                                                        
                        <div class="marker-overlays js-noFade">
                                                            <var class="bgShadeEffect duration tooltipTrig" data-title="Video Duration">0:11</var>
                                                        
                                                                                                                                                                                                                            </div>

                                                                    </a>
            </div>
                            <div class="thumbnail-info-wrapper clearfix">
                                    <div class="videoUploaderBlock">
                        <div class="usernameWrapper">
                            <div class="usernameWrap">
                                                                                                    <a rel="" href="/model/ryancreamer"  title="RyanCreamer" data-event="watch_page" data-label="thumb_username" class="gtm-event-watch-page">RyanCreamer</a>                                                            </div>
                                                                                                <span class="verified-icon main-sprite tooltipTrig" data-title="Verified Model"></span>
                                                                                    </div>
                        <div class="videoDetailBlock">
                                                                                            <span class="views"><i class="ph-icon-view-on tooltipTrig" data-title="Total Views"></i><var>491K</var></span>
                                                                                            
                                                        <var class="added">5 years ago</var>
                        </div>
                    </div>
                                <div class="vidTitleWrapper">
                    <span class="title">
                                                                                    <a href="/view_video.php?viewkey=ph5cd030d434130" title="I Disagree With The Ads Around This Video, Your Penis Size is Fine As Is" class="thumbnailTitle "                                                                                                        >
                                    I Disagree With The Ads Around This Video, Your Penis Size is Fine As Is                                </a>
                                                                        </span>
                                            <div class="rightAlign moreActionMenuButton gtm-event-actionmenu"
                             data-video-id="222159451"
                             data-token="MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8."
                             data-event="action_menu_watchpage"
                             data-label="menu_open"
                             data-menu-id="222159451" data-menu-can-add-to-playlist="1" data-menu-added-to-playlist="0" data-menu-is-private-member="0" data-menu-is-blocked="0" data-menu-is-pornhub="0" data-menu-is-channel="0" data-menu-is-content-partner="0" data-menu-is-subscribed="0" data-menu-is-compilation="false" data-menu-subscribe-id="632615272" data-menu-can-subscribe="1" data-menu-title="RyanCreamer"                        >
                            <span class="ph-icon-kebab-menu"></span>
                        </div>
                                    </div>
                            </div>
                    </div>
    </li>

                                                                                                                            <li class='tjListItem js_promoItem'>
        <ins class='adsbytrafficjunky' data-spot-id='2514911' data-type='native' data-height='340px' data-width='480px' data-inbanlabel='false' data-default-image='https://ei.phncdn.com/videos/202004/15/303973002/original/(m=edLTGgaaaa)(mh=rti8Up3dQlLTBU6T)1.jpg' data-default-url='/view_video.php?viewkey=ph5e971259d2a46'  style='width:480px;height:340px;display:block;margin:0 auto;'></ins>            </li>

                                                                                                                        <li class="pcVideoListItem js-pop videoblock fixedSizeThumbContainer"
                    id="v478984625"
        data-video-id="478984625"
    data-type="video"
    data-video-vkey="694b621d9be47"
    data-id="478984625"
    data-segment="straight"
    data-entrycode="VidPg-premVid"
        tabindex="0"
    data-event-label="Safe for Work"
>
    <div class="wrap flexibleHeight">
                    <div class="phimage"
                            >
                                                    <div class="preloadLine"></div>
                                                                                            <a href="/view_video.php?viewkey=694b621d9be47" title="Inside Sadie Summers: Confidence, Controversy &amp; Saying What Everyone Else Won’t"                        class="latestThumb fade  videoPreviewBg linkVideoThumb js-linkVideoThumb img "
                        data-related-url="/api/v1/video/ajax_related_video?vkey=694b621d9be47"
                        data-video-id="478984625"
                                                                    >
                        
                                                                                                                                                    <img
                                src="https://pix-fl.phncdn.com/c6251/videos/202512/24/33649475/original/019b5285-a7fc-7b0b-89d6-ccb314cf5335.png/plain/rs:fit:320:180?hdnea=st=1779557891~exp=1779644291~hdl=-1~hmac=0915f3c913092e3f8a09c1aba1ad5207c8ddba4f"
                                alt="Inside Sadie Summers: Confidence, Controversy &amp; Saying What Everyone Else Won’t"
                                data-pix=""                                loading="lazy"
                                                                    data-mediumthumb="https://pix-fl.phncdn.com/c6251/videos/202512/24/33649475/original/019b5285-a7fc-7b0b-89d6-ccb314cf5335.png/plain/rs:fit:320:180?hdnea=st=1779557891~exp=1779644291~hdl=-1~hmac=0915f3c913092e3f8a09c1aba1ad5207c8ddba4f"
                                                                                                                                    data-mediabook="https://kw.phncdn.com/c6251/videos/202512/24/33649475/180P_225K_33649475.webm?hdnea=st=1779557892~exp=1779561492~hdl=-1~hmac=7e285e3bb752940e3684facac5494658830f6032"
                                                                class=" js-pop js-videoThumb js-videoThumbFlip thumb js-videoPreview"
                                width="320" height="180"
                                                                title="Inside Sadie Summers: Confidence, Controversy &amp; Saying What Everyone Else Won’t" />
                                                                                                                        
                        <div class="marker-overlays js-noFade">
                                                            <var class="bgShadeEffect duration tooltipTrig" data-title="Video Duration">60:19</var>
                                                        
                                                                                                                                                                                                                            </div>

                                                                    </a>
            </div>
                            <div class="thumbnail-info-wrapper clearfix">
                                    <div class="videoUploaderBlock">
                        <div class="usernameWrapper">
                            <div class="usernameWrap">
                                                                                                                                            <a href="/channels/holly-randall" class="bolded gtm-event-watch-page" data-event="watch_page" data-label="thumb_username">Holly Randall</a>
                                                                                                </div>
                                                            <span class="channel-icon main-sprite searchPageIcon"></span>
                                                        </div>
                        <div class="videoDetailBlock">
                                                                                            <span class="views"><i class="ph-icon-view-on tooltipTrig" data-title="Total Views"></i><var>35.6K</var></span>
                                                                                            
                                                        <var class="added">2 months ago</var>
                        </div>
                    </div>
                                <div class="vidTitleWrapper">
                    <span class="title">
                                                                                    <a href="/view_video.php?viewkey=694b621d9be47" title="Inside Sadie Summers: Confidence, Controversy &amp; Saying What Everyone Else Won’t" class="thumbnailTitle "                                                                                                        >
                                    Inside Sadie Summers: Confidence, Controversy &amp; Saying What Everyone Else Won’t                                </a>
                                                                        </span>
                                            <div class="rightAlign moreActionMenuButton gtm-event-actionmenu"
                             data-video-id="478984625"
                             data-token="MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8."
                             data-event="action_menu_watchpage"
                             data-label="menu_open"
                             data-menu-id="478984625" data-menu-can-add-to-playlist="1" data-menu-added-to-playlist="0" data-menu-is-private-member="0" data-menu-is-blocked="0" data-menu-is-pornhub="0" data-menu-is-channel="1" data-menu-is-content-partner="0" data-menu-is-subscribed="0" data-menu-is-compilation="false" data-menu-subscribe-id="42091" data-menu-can-subscribe="1" data-menu-title="Holly Randall"                        >
                            <span class="ph-icon-kebab-menu"></span>
                        </div>
                                    </div>
                            </div>
                    </div>
    </li>

                                                                                                                            <li class='tjListItem js_promoItem'>
        <ins class='adsbytrafficjunky' data-spot-id='2514911' data-type='native' data-height='340px' data-width='480px' data-inbanlabel='false' data-default-image='https://ei.phncdn.com/videos/202305/10/431238401/original/(m=q8129LYbedLTGgaaaa)(mh=jLaaARLAdrXsLk4D)0.jpg' data-default-url='/view_video.php?viewkey=645ab8c01b680'  style='width:480px;height:340px;display:block;margin:0 auto;'></ins>            </li>

                                                                                                                        <li class="pcVideoListItem js-pop videoblock fixedSizeThumbContainer"
                    id="v481431655"
        data-video-id="481431655"
    data-type="video"
    data-video-vkey="6995f6d931389"
    data-id="481431655"
    data-segment="straight"
    data-entrycode="VidPg-premVid"
        tabindex="0"
    data-event-label="Safe for Work"
>
    <div class="wrap flexibleHeight">
                    <div class="phimage"
                            >
                                                    <div class="preloadLine"></div>
                                                                                            <a href="/view_video.php?viewkey=6995f6d931389" title="EP26 | Nobody Tells You This About Being a Content Creator"                        class="latestThumb fade  videoPreviewBg linkVideoThumb js-linkVideoThumb img "
                        data-related-url="/api/v1/video/ajax_related_video?vkey=6995f6d931389"
                        data-video-id="481431655"
                                                                    >
                        
                                                                                                                                                    <img
                                src="https://pix-cdn77.phncdn.com/c6251/videos/202602/18/39724955/original/019c8be7-7f85-7e16-a6e5-f9ead9de676e.jpg/plain/rs:fit:320:180?hash=6CEHr39pKivdGXqUCNvOOJyKf_Q=&validto=1779644495"
                                alt="EP26 | Nobody Tells You This About Being a Content Creator"
                                data-pix=""                                loading="lazy"
                                                                    data-mediumthumb="https://pix-cdn77.phncdn.com/c6251/videos/202602/18/39724955/original/019c8be7-7f85-7e16-a6e5-f9ead9de676e.jpg/plain/rs:fit:320:180?hash=6CEHr39pKivdGXqUCNvOOJyKf_Q=&validto=1779644495"
                                                                                                                                    data-mediabook="https://kw.phncdn.com/c6251/videos/202602/18/39724955/180P_225K_39724955.webm?hdnea=st=1779558095~exp=1779561695~hdl=-1~hmac=9a6f63129bb1a286dbe7835b78423045e6e8ecd6"
                                                                class=" js-pop js-videoThumb js-videoThumbFlip thumb js-videoPreview"
                                width="320" height="180"
                                                                title="EP26 | Nobody Tells You This About Being a Content Creator" />
                                                                                                                        
                        <div class="marker-overlays js-noFade">
                                                            <var class="bgShadeEffect duration tooltipTrig" data-title="Video Duration">11:36</var>
                                                        
                                                                                                                                                                                                                            </div>

                                                                    </a>
            </div>
                            <div class="thumbnail-info-wrapper clearfix">
                                    <div class="videoUploaderBlock">
                        <div class="usernameWrapper">
                            <div class="usernameWrap">
                                                                                                                                            <a href="/channels/lexis-star-show" class="bolded gtm-event-watch-page" data-event="watch_page" data-label="thumb_username">Lexis Star Show</a>
                                                                                                </div>
                                                            <span class="channel-icon main-sprite searchPageIcon"></span>
                                                        </div>
                        <div class="videoDetailBlock">
                                                                                            <span class="views"><i class="ph-icon-view-on tooltipTrig" data-title="Total Views"></i><var>30.3K</var></span>
                                                                                            
                                                        <var class="added">2 months ago</var>
                        </div>
                    </div>
                                <div class="vidTitleWrapper">
                    <span class="title">
                                                                                    <a href="/view_video.php?viewkey=6995f6d931389" title="EP26 | Nobody Tells You This About Being a Content Creator" class="thumbnailTitle "                                                                                                        >
                                    EP26 | Nobody Tells You This About Being a Content Creator                                </a>
                                                                        </span>
                                            <div class="rightAlign moreActionMenuButton gtm-event-actionmenu"
                             data-video-id="481431655"
                             data-token="MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8."
                             data-event="action_menu_watchpage"
                             data-label="menu_open"
                             data-menu-id="481431655" data-menu-can-add-to-playlist="1" data-menu-added-to-playlist="0" data-menu-is-private-member="0" data-menu-is-blocked="0" data-menu-is-pornhub="0" data-menu-is-channel="1" data-menu-is-content-partner="0" data-menu-is-subscribed="0" data-menu-is-compilation="false" data-menu-subscribe-id="69525" data-menu-can-subscribe="1" data-menu-title="Lexis Star Show"                        >
                            <span class="ph-icon-kebab-menu"></span>
                        </div>
                                    </div>
                            </div>
                    </div>
    </li>

                                                                                                                            <li class='tjListItem js_promoItem'>
        <ins class='adsbytrafficjunky' data-spot-id='2514911' data-type='native' data-height='340px' data-width='480px' data-inbanlabel='false' data-default-image='https://pix-cdn77.phncdn.com/c6251/videos/202508/09/18766065/original/0198e259-9ca3-769c-8ab9-12e8731ee2e3.png/plain/rs:fit:323:182?hash=nYRGAn19XFf_IH300nAtfHv4JTw=&validto=1779644291' data-default-url='/view_video.php?viewkey=6897d7fc3a657'  style='width:480px;height:340px;display:block;margin:0 auto;'></ins>            </li>

                                                                                                                                                    <li class="pcVideoListItem videoblock fixedSizeThumbContainer mockNsfwThumb">
                                <div class="wrap flexibleHeight">
                                    <div class="phimage">
                                        <a href="javascript:void(0)" class="latestThumb img">
                                            <img src="https://ei.phncdn.com/www-static/images/sfw_video_thumb_mock/1.png"
                                                 alt="Amateur Couple’s First Time Filming"
                                                 loading="lazy"
                                                 class="thumb"
                                                 width="320"
                                                 height="180" />
                                            <div class="marker-overlays js-noFade">
                                                <var class="bgShadeEffect duration tooltipTrig" data-title="Video Duration">8:27</var>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="thumbnail-info-wrapper clearfix">
                                        <div class="videoUploaderBlock">
                                            <div class="usernameWrapper">
                                                <div class="usernameWrap">
                                                    <a href="javascript:void(0)" class="username">
                                                        Pornhub                                                    </a>
                                                </div>
                                                <span class="channel-icon main-sprite tooltipTrig" data-title="Channel"></span>
                                            </div>
                                            <div class="videoDetailBlock">
                                    <span class="views">
                                        <i class="ph-icon-view-on tooltipTrig" data-title="Total Views"></i>
                                        <var>2.3M</var>
                                    </span>
                                            </div>
                                        </div>
                                        <div class="vidTitleWrapper">
                                <span class="title">
                                    <a href="javascript:void(0)" class="thumbnailTitle">
                                        Amateur Couple’s First Time Filming                                    </a>
                                </span>
                                            <div class="rightAlign moreActionMenuButton gtm-event-actionmenu" data-video-id="478376045" data-event="action_menu_homepage" data-label="menu_open">
                                                <span class="ph-icon-kebab-menu"></span>
                                                                                                <v-more-action-menu id="478376045" can-add-to-playlist="1" added-to-playlist="0" is-private-member="0" is-blocked="0" is-pornhub="0" is-channel="1" is-content-partner="0" is-subscribed="0" subscribe-id="69525" title="Pornhub" can-subscribe="1" vce-ready="">
                                                    <div class="moreActionMenu displayNone">
                                                        <a data-name="Add to Watch Later" data-video-added="0" data-video-id="478376045" data-label="watch_later" data-event="action_menu_homepage" class="moreActionLink addToWatchLaterLink gtm-event-actionmenu">
                                                            <span class="icon ph-icon-playlist-add"></span>
                                                            <span class="label">Add to Watch Later</span>
                                                        </a>
                                                        <a data-name="Subscribe to Uploader" data-is-pornhub="0" data-content-partner="0" data-channel="1" data-subscribed="0" data-id="69525" data-title="Pornhub" data-label="subscribe" data-event="action_menu_homepage" class="moreActionLink subscribeToLink gtm-event-actionmenu">
                                                            <span class="ph-icon-add-friend"></span>
                                                            <span class="label">Subscribe to Pornhub</span></a>
                                                        <a data-name="Not Interested" data-video-id="478376045" data-type="video" data-label="not_interested" data-event="action_menu_homepage" class="moreActionLink notInterestedLink gtm-event-actionmenu">
                                                            <span class="ph-icon-cancel"></span>
                                                            <span class="label">Not interested</span>
                                                        </a>
                                                    </div>
                                                </v-more-action-menu>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                                                                                                                                                        <li class='tjListItem js_promoItem'>
        <ins class='adsbytrafficjunky' data-spot-id='2514911' data-type='native' data-height='340px' data-width='480px' data-inbanlabel='false' data-default-image='https://ei.phncdn.com/videos/201802/13/154536052/original/(m=edLTGgaaaa)(mh=LAkt2S6Q69RULS_S)8.jpg' data-default-url='/view_video.php?viewkey=ph5a83172ce5a31'  style='width:480px;height:340px;display:block;margin:0 auto;'></ins>            </li>

                                                                                                                        <li class="pcVideoListItem js-pop videoblock fixedSizeThumbContainer"
                    id="v479237995"
        data-video-id="479237995"
    data-type="video"
    data-video-vkey="6953f4a2191b0"
    data-id="479237995"
    data-segment="straight"
    data-entrycode="VidPg-premVid"
        tabindex="0"
    data-event-label="Safe for Work"
>
    <div class="wrap flexibleHeight">
                    <div class="phimage"
                            >
                                                    <div class="preloadLine"></div>
                                                                                            <a href="/view_video.php?viewkey=6953f4a2191b0" title="ALINA LOPEZ EXPOSED FOR CHEATING ON RYAN | LIE DETECOR TEST W/ VIKING BARBIE"                        class="latestThumb fade  videoPreviewBg linkVideoThumb js-linkVideoThumb img "
                        data-related-url="/api/v1/video/ajax_related_video?vkey=6953f4a2191b0"
                        data-video-id="479237995"
                                                                    >
                        
                                                                                                                                                    <img
                                src="https://pix-cdn77.phncdn.com/c6251/videos/202512/30/34298205/original/019c5100-e55c-72bf-bf24-c14d6a7376d8.jpg/plain/rs:fit:320:180?hash=PHwnTErM4VBRdvi7gL6Yc3Dbpl0=&validto=1779644537"
                                alt="ALINA LOPEZ EXPOSED FOR CHEATING ON RYAN | LIE DETECOR TEST W/ VIKING BARBIE"
                                data-pix=""                                loading="lazy"
                                                                    data-mediumthumb="https://pix-cdn77.phncdn.com/c6251/videos/202512/30/34298205/original/019c5100-e55c-72bf-bf24-c14d6a7376d8.jpg/plain/rs:fit:320:180?hash=PHwnTErM4VBRdvi7gL6Yc3Dbpl0=&validto=1779644537"
                                                                                                                                    data-mediabook="https://kw.phncdn.com/c6251/videos/202512/30/34298205/180P_225K_34298205.webm?hdnea=st=1779558137~exp=1779561737~hdl=-1~hmac=6fab83daf07e595fd956a95ecacfe224ca37c3f8"
                                                                class=" js-pop js-videoThumb js-videoThumbFlip thumb js-videoPreview"
                                width="320" height="180"
                                                                title="ALINA LOPEZ EXPOSED FOR CHEATING ON RYAN | LIE DETECOR TEST W/ VIKING BARBIE" />
                                                                                                                        
                        <div class="marker-overlays js-noFade">
                                                            <var class="bgShadeEffect duration tooltipTrig" data-title="Video Duration">69:39</var>
                                                        
                                                                                                                                                                                                                            </div>

                                                                    </a>
            </div>
                            <div class="thumbnail-info-wrapper clearfix">
                                    <div class="videoUploaderBlock">
                        <div class="usernameWrapper">
                            <div class="usernameWrap">
                                                                                                                                            <a href="/channels/pillow-talk" class="bolded gtm-event-watch-page" data-event="watch_page" data-label="thumb_username">Pillow Talk</a>
                                                                                                </div>
                                                            <span class="channel-icon main-sprite searchPageIcon"></span>
                                                        </div>
                        <div class="videoDetailBlock">
                                                                                            <span class="views"><i class="ph-icon-view-on tooltipTrig" data-title="Total Views"></i><var>120K</var></span>
                                                                                            
                                                        <var class="added">4 months ago</var>
                        </div>
                    </div>
                                <div class="vidTitleWrapper">
                    <span class="title">
                                                                                    <a href="/view_video.php?viewkey=6953f4a2191b0" title="ALINA LOPEZ EXPOSED FOR CHEATING ON RYAN | LIE DETECOR TEST W/ VIKING BARBIE" class="thumbnailTitle "                                                                                                        >
                                    ALINA LOPEZ EXPOSED FOR CHEATING ON RYAN | LIE DETECOR TEST W/ VIKING BARBIE                                </a>
                                                                        </span>
                                            <div class="rightAlign moreActionMenuButton gtm-event-actionmenu"
                             data-video-id="479237995"
                             data-token="MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8."
                             data-event="action_menu_watchpage"
                             data-label="menu_open"
                             data-menu-id="479237995" data-menu-can-add-to-playlist="1" data-menu-added-to-playlist="0" data-menu-is-private-member="0" data-menu-is-blocked="0" data-menu-is-pornhub="0" data-menu-is-channel="1" data-menu-is-content-partner="0" data-menu-is-subscribed="0" data-menu-is-compilation="false" data-menu-subscribe-id="68351" data-menu-can-subscribe="1" data-menu-title="Pillow Talk"                        >
                            <span class="ph-icon-kebab-menu"></span>
                        </div>
                                    </div>
                            </div>
                    </div>
    </li>

                                                                                                                            <li class='tjListItem js_promoItem'>
        <ins class='adsbytrafficjunky' data-spot-id='2514911' data-type='native' data-height='340px' data-width='480px' data-inbanlabel='false' data-default-image='https://ei.phncdn.com/videos/201909/20/249642651/original/(m=edLTGgaaaa)(mh=_PuaZv2puldwik2I)4.jpg' data-default-url='/view_video.php?viewkey=ph5d84d9d2be911'  style='width:480px;height:340px;display:block;margin:0 auto;'></ins>            </li>

                                                                                                                        <li class="pcVideoListItem js-pop videoblock fixedSizeThumbContainer"
                    id="v300469722"
        data-video-id="300469722"
    data-type="video"
    data-video-vkey="ph5e89c34c13e58"
    data-id="300469722"
    data-segment="straight"
    data-entrycode="VidPg-premVid"
        tabindex="0"
    data-event-label="Safe for Work"
>
    <div class="wrap flexibleHeight">
                    <div class="phimage"
                            >
                                                    <div class="preloadLine"></div>
                                                                                            <a href="/view_video.php?viewkey=ph5e89c34c13e58" title="Goes Slow in His Afternoon "                        class="latestThumb fade  videoPreviewBg linkVideoThumb js-linkVideoThumb img "
                        data-related-url="/api/v1/video/ajax_related_video?vkey=ph5e89c34c13e58"
                        data-video-id="300469722"
                                                                    >
                        
                                                                                                                                                    <img
                                src="https://ei.phncdn.com/videos/202004/05/300469722/original/(m=eafTGgaaaa)(mh=_vnr76KRQR7xewLC)10.jpg"
                                alt="Goes Slow in His Afternoon "
                                data-pix=""                                loading="lazy"
                                                                    data-mediumthumb="https://ei.phncdn.com/videos/202004/05/300469722/original/(m=eafTGgaaaa)(mh=_vnr76KRQR7xewLC)10.jpg"
                                                                                                                                    data-mediabook="https://kw.phncdn.com/videos/202004/05/300469722/180P_225K_300469722.webm?hdnea=st=1779558135~exp=1779561735~hdl=-1~hmac=addfa1fdd752e6b371eea77b53d19565cb2afc2d"
                                                                class=" js-pop js-videoThumb js-videoThumbFlip thumb js-videoPreview"
                                width="320" height="180"
                                                                title="Goes Slow in His Afternoon " />
                                                                                                                        
                        <div class="marker-overlays js-noFade">
                                                            <var class="bgShadeEffect duration tooltipTrig" data-title="Video Duration">5:10</var>
                                                        
                                                                                                                                                                                                                            </div>

                                                                    </a>
            </div>
                            <div class="thumbnail-info-wrapper clearfix">
                                    <div class="videoUploaderBlock">
                        <div class="usernameWrapper">
                            <div class="usernameWrap">
                                                                                                                                            <a href="/channels/scrubhub" class="bolded gtm-event-watch-page" data-event="watch_page" data-label="thumb_username">Scrubhub</a>
                                                                                                </div>
                                                            <span class="channel-icon main-sprite searchPageIcon"></span>
                                                        </div>
                        <div class="videoDetailBlock">
                                                                                            <span class="views"><i class="ph-icon-view-on tooltipTrig" data-title="Total Views"></i><var>49K</var></span>
                                                                                            
                                                        <var class="added">5 years ago</var>
                        </div>
                    </div>
                                <div class="vidTitleWrapper">
                    <span class="title">
                                                                                    <a href="/view_video.php?viewkey=ph5e89c34c13e58" title="Goes Slow in His Afternoon " class="thumbnailTitle "                                                                                                        >
                                    Goes Slow in His Afternoon                                 </a>
                                                                        </span>
                                            <div class="rightAlign moreActionMenuButton gtm-event-actionmenu"
                             data-video-id="300469722"
                             data-token="MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8."
                             data-event="action_menu_watchpage"
                             data-label="menu_open"
                             data-menu-id="300469722" data-menu-can-add-to-playlist="1" data-menu-added-to-playlist="0" data-menu-is-private-member="0" data-menu-is-blocked="0" data-menu-is-pornhub="0" data-menu-is-channel="1" data-menu-is-content-partner="0" data-menu-is-subscribed="0" data-menu-is-compilation="false" data-menu-subscribe-id="53952" data-menu-can-subscribe="1" data-menu-title="Scrubhub"                        >
                            <span class="ph-icon-kebab-menu"></span>
                        </div>
                                    </div>
                            </div>
                    </div>
    </li>

                                                                                                                            <li class='tjListItem js_promoItem'>
        <ins class='adsbytrafficjunky' data-spot-id='2514911' data-type='native' data-height='340px' data-width='480px' data-inbanlabel='false' data-default-image='https://ei.phncdn.com/videos/201903/26/215094362/original/(m=edLTGgaaaa)(mh=Wu7JpKQhj-bmzuxg)5.jpg' data-default-url='/view_video.php?viewkey=ph5c9a5362c61c6'  style='width:480px;height:340px;display:block;margin:0 auto;'></ins>            </li>

                                                                                                                        <li class="pcVideoListItem js-pop videoblock fixedSizeThumbContainer"
                    id="v297410511"
        data-video-id="297410511"
    data-type="video"
    data-video-vkey="ph5e7e454490a71"
    data-id="297410511"
    data-segment="straight"
    data-entrycode="VidPg-premVid"
        tabindex="0"
    data-event-label="Safe for Work"
>
    <div class="wrap flexibleHeight">
                    <div class="phimage"
                            >
                                                    <div class="preloadLine"></div>
                                                                                            <a href="/view_video.php?viewkey=ph5e7e454490a71" title="BANG Surprise Podcast #1 With Sara Jay"                        class="latestThumb fade  videoPreviewBg linkVideoThumb js-linkVideoThumb img "
                        data-related-url="/api/v1/video/ajax_related_video?vkey=ph5e7e454490a71"
                        data-video-id="297410511"
                                                                    >
                        
                                                                                                                                                    <img
                                src="https://ei.phncdn.com/videos/202003/27/297410511/original/(m=eafTGgaaaa)(mh=m26jpSQcgDd5BYnG)9.jpg"
                                alt="BANG Surprise Podcast #1 With Sara Jay"
                                data-pix=""                                loading="lazy"
                                                                    data-mediumthumb="https://ei.phncdn.com/videos/202003/27/297410511/original/(m=eafTGgaaaa)(mh=m26jpSQcgDd5BYnG)9.jpg"
                                                                                                                                    data-mediabook="https://kw.phncdn.com/videos/202003/27/297410511/221010_0900_180P_225K_297410511.webm?hdnea=st=1779557786~exp=1779561386~hdl=-1~hmac=16f7b2160bf99e00af660dd9884934be13e147fa"
                                                                class=" js-pop js-videoThumb js-videoThumbFlip thumb js-videoPreview"
                                width="320" height="180"
                                                                title="BANG Surprise Podcast #1 With Sara Jay" />
                                                                                                                        
                        <div class="marker-overlays js-noFade">
                                                            <var class="bgShadeEffect duration tooltipTrig" data-title="Video Duration">28:15</var>
                                                        
                                                                                                                                                                                                                            </div>

                                                                    </a>
            </div>
                            <div class="thumbnail-info-wrapper clearfix">
                                    <div class="videoUploaderBlock">
                        <div class="usernameWrapper">
                            <div class="usernameWrap">
                                                                                                                                            <a href="/channels/bang-casting" class="bolded gtm-event-watch-page" data-event="watch_page" data-label="thumb_username">Bang Casting</a>
                                                                                                </div>
                                                            <span class="channel-icon main-sprite searchPageIcon"></span>
                                                        </div>
                        <div class="videoDetailBlock">
                                                                                            <span class="views"><i class="ph-icon-view-on tooltipTrig" data-title="Total Views"></i><var>791K</var></span>
                                                                                            
                                                        <var class="added">6 years ago</var>
                        </div>
                    </div>
                                <div class="vidTitleWrapper">
                    <span class="title">
                                                                                    <a href="/view_video.php?viewkey=ph5e7e454490a71" title="BANG Surprise Podcast #1 With Sara Jay" class="thumbnailTitle "                                                                                                        >
                                    BANG Surprise Podcast #1 With Sara Jay                                </a>
                                                                        </span>
                                            <div class="rightAlign moreActionMenuButton gtm-event-actionmenu"
                             data-video-id="297410511"
                             data-token="MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8."
                             data-event="action_menu_watchpage"
                             data-label="menu_open"
                             data-menu-id="297410511" data-menu-can-add-to-playlist="1" data-menu-added-to-playlist="0" data-menu-is-private-member="0" data-menu-is-blocked="0" data-menu-is-pornhub="0" data-menu-is-channel="1" data-menu-is-content-partner="0" data-menu-is-subscribed="0" data-menu-is-compilation="false" data-menu-subscribe-id="31841" data-menu-can-subscribe="1" data-menu-title="Bang Casting"                        >
                            <span class="ph-icon-kebab-menu"></span>
                        </div>
                                    </div>
                            </div>
                    </div>
    </li>

                                                                                                                            <li class='tjListItem js_promoItem'>
        <ins class='adsbytrafficjunky' data-spot-id='2514911' data-type='native' data-height='340px' data-width='480px' data-inbanlabel='false' data-default-image='https://ei.phncdn.com/videos/201707/18/124932801/original/(m=edLTGgaaaa)(mh=KVYHbhhMP6VQ2pPu)0.jpg' data-default-url='/view_video.php?viewkey=ph596e113baf1a0'  style='width:480px;height:340px;display:block;margin:0 auto;'></ins>            </li>

                                                                                                                        <li class="pcVideoListItem js-pop videoblock fixedSizeThumbContainer"
                    id="v475656465"
        data-video-id="475656465"
    data-type="video"
    data-video-vkey="68e92abfc0012"
    data-id="475656465"
    data-segment="straight"
    data-entrycode="VidPg-premVid"
        tabindex="0"
    data-event-label="Safe for Work"
>
    <div class="wrap flexibleHeight">
                    <div class="phimage"
                            >
                                                    <div class="preloadLine"></div>
                                                                                            <a href="/view_video.php?viewkey=68e92abfc0012" title="EP7 | Reacting to the Wildest Comments from My PornHub Fans 😳"                        class="latestThumb fade  videoPreviewBg linkVideoThumb js-linkVideoThumb img "
                        data-related-url="/api/v1/video/ajax_related_video?vkey=68e92abfc0012"
                        data-video-id="475656465"
                                                                    >
                        
                                                                                                                                                    <img
                                src="https://pix-fl.phncdn.com/c6251/videos/202510/10/25837715/original/0199e57e-6f08-7599-8df1-34ffc31ffd0c.jpg/plain/rs:fit:320:180?hdnea=st=1779558231~exp=1779644631~hdl=-1~hmac=29d4734fdf6d67442a843c4449d543ba9a5d7f28"
                                alt="EP7 | Reacting to the Wildest Comments from My PornHub Fans 😳"
                                data-pix=""                                loading="lazy"
                                                                    data-mediumthumb="https://pix-fl.phncdn.com/c6251/videos/202510/10/25837715/original/0199e57e-6f08-7599-8df1-34ffc31ffd0c.jpg/plain/rs:fit:320:180?hdnea=st=1779558231~exp=1779644631~hdl=-1~hmac=29d4734fdf6d67442a843c4449d543ba9a5d7f28"
                                                                                                                                    data-mediabook="https://kw.phncdn.com/c6251/videos/202510/10/25837715/180P_225K_25837715.webm?hdnea=st=1779558231~exp=1779561831~hdl=-1~hmac=d60447434a71e9bbbd39e89b40e91c133fb3cee1"
                                                                class=" js-pop js-videoThumb js-videoThumbFlip thumb js-videoPreview"
                                width="320" height="180"
                                                                title="EP7 | Reacting to the Wildest Comments from My PornHub Fans 😳" />
                                                                                                                        
                        <div class="marker-overlays js-noFade">
                                                            <var class="bgShadeEffect duration tooltipTrig" data-title="Video Duration">16:11</var>
                                                        
                                                                                                                                                                                                                            </div>

                                                                    </a>
            </div>
                            <div class="thumbnail-info-wrapper clearfix">
                                    <div class="videoUploaderBlock">
                        <div class="usernameWrapper">
                            <div class="usernameWrap">
                                                                                                                                            <a href="/channels/lexis-star-show" class="bolded gtm-event-watch-page" data-event="watch_page" data-label="thumb_username">Lexis Star Show</a>
                                                                                                </div>
                                                            <span class="channel-icon main-sprite searchPageIcon"></span>
                                                        </div>
                        <div class="videoDetailBlock">
                                                                                            <span class="views"><i class="ph-icon-view-on tooltipTrig" data-title="Total Views"></i><var>73K</var></span>
                                                                                            
                                                        <var class="added">7 months ago</var>
                        </div>
                    </div>
                                <div class="vidTitleWrapper">
                    <span class="title">
                                                                                    <a href="/view_video.php?viewkey=68e92abfc0012" title="EP7 | Reacting to the Wildest Comments from My PornHub Fans 😳" class="thumbnailTitle "                                                                                                        >
                                    EP7 | Reacting to the Wildest Comments from My PornHub Fans 😳                                </a>
                                                                        </span>
                                            <div class="rightAlign moreActionMenuButton gtm-event-actionmenu"
                             data-video-id="475656465"
                             data-token="MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8."
                             data-event="action_menu_watchpage"
                             data-label="menu_open"
                             data-menu-id="475656465" data-menu-can-add-to-playlist="1" data-menu-added-to-playlist="0" data-menu-is-private-member="0" data-menu-is-blocked="0" data-menu-is-pornhub="0" data-menu-is-channel="1" data-menu-is-content-partner="0" data-menu-is-subscribed="0" data-menu-is-compilation="false" data-menu-subscribe-id="69525" data-menu-can-subscribe="1" data-menu-title="Lexis Star Show"                        >
                            <span class="ph-icon-kebab-menu"></span>
                        </div>
                                    </div>
                            </div>
                    </div>
    </li>

                                                                                                                            <li class='tjListItem js_promoItem'>
        <ins class='adsbytrafficjunky' data-spot-id='2514911' data-type='native' data-height='340px' data-width='480px' data-inbanlabel='false' data-default-image='https://pix-cdn77.phncdn.com/c6251/videos/202512/23/33602905/original/019c5101-684b-7809-ab8c-eea3f5a935d9.jpg/plain/rs:fit:323:182?hash=J_8v7WHjf_IZkzIoEXaMJs8p2lY=&validto=1779644526' data-default-url='/view_video.php?viewkey=694abb86bfbca'  style='width:480px;height:340px;display:block;margin:0 auto;'></ins>            </li>

                                                                                                                                                    <li class="pcVideoListItem videoblock fixedSizeThumbContainer mockNsfwThumb">
                                <div class="wrap flexibleHeight">
                                    <div class="phimage">
                                        <a href="javascript:void(0)" class="latestThumb img">
                                            <img src="https://ei.phncdn.com/www-static/images/sfw_video_thumb_mock/2.png"
                                                 alt="Curvy Babe’s POV Adventure"
                                                 loading="lazy"
                                                 class="thumb"
                                                 width="320"
                                                 height="180" />
                                            <div class="marker-overlays js-noFade">
                                                <var class="bgShadeEffect duration tooltipTrig" data-title="Video Duration">12:10</var>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="thumbnail-info-wrapper clearfix">
                                        <div class="videoUploaderBlock">
                                            <div class="usernameWrapper">
                                                <div class="usernameWrap">
                                                    <a href="javascript:void(0)" class="username">
                                                        Pornhub                                                    </a>
                                                </div>
                                                <span class="channel-icon main-sprite tooltipTrig" data-title="Channel"></span>
                                            </div>
                                            <div class="videoDetailBlock">
                                    <span class="views">
                                        <i class="ph-icon-view-on tooltipTrig" data-title="Total Views"></i>
                                        <var>1.7M</var>
                                    </span>
                                            </div>
                                        </div>
                                        <div class="vidTitleWrapper">
                                <span class="title">
                                    <a href="javascript:void(0)" class="thumbnailTitle">
                                        Curvy Babe’s POV Adventure                                    </a>
                                </span>
                                            <div class="rightAlign moreActionMenuButton gtm-event-actionmenu" data-video-id="478376045" data-event="action_menu_homepage" data-label="menu_open">
                                                <span class="ph-icon-kebab-menu"></span>
                                                                                                <v-more-action-menu id="478376045" can-add-to-playlist="1" added-to-playlist="0" is-private-member="0" is-blocked="0" is-pornhub="0" is-channel="1" is-content-partner="0" is-subscribed="0" subscribe-id="69525" title="Pornhub" can-subscribe="1" vce-ready="">
                                                    <div class="moreActionMenu displayNone">
                                                        <a data-name="Add to Watch Later" data-video-added="0" data-video-id="478376045" data-label="watch_later" data-event="action_menu_homepage" class="moreActionLink addToWatchLaterLink gtm-event-actionmenu">
                                                            <span class="icon ph-icon-playlist-add"></span>
                                                            <span class="label">Add to Watch Later</span>
                                                        </a>
                                                        <a data-name="Subscribe to Uploader" data-is-pornhub="0" data-content-partner="0" data-channel="1" data-subscribed="0" data-id="69525" data-title="Pornhub" data-label="subscribe" data-event="action_menu_homepage" class="moreActionLink subscribeToLink gtm-event-actionmenu">
                                                            <span class="ph-icon-add-friend"></span>
                                                            <span class="label">Subscribe to Pornhub</span></a>
                                                        <a data-name="Not Interested" data-video-id="478376045" data-type="video" data-label="not_interested" data-event="action_menu_homepage" class="moreActionLink notInterestedLink gtm-event-actionmenu">
                                                            <span class="ph-icon-cancel"></span>
                                                            <span class="label">Not interested</span>
                                                        </a>
                                                    </div>
                                                </v-more-action-menu>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                                                                                                                                                        <li class='tjListItem js_promoItem'>
        <ins class='adsbytrafficjunky' data-spot-id='2514911' data-type='native' data-height='340px' data-width='480px' data-inbanlabel='false' data-default-image='https://pix-cdn77.phncdn.com/c6251/videos/202509/16/22852325/original/01995092-a509-7426-8223-31707a848dd8.png/plain/rs:fit:323:182?hash=HEcHwRByg3_RXmU_Z9ZmM9jh1d4=&validto=1779644548' data-default-url='/view_video.php?viewkey=68c8aa0bca3cb'  style='width:480px;height:340px;display:block;margin:0 auto;'></ins>            </li>

                                                                                                        </ul>
            </div>
        </div>
    </div>
    <div class="reset"></div>
</div>


<v-flag-modal
	platform="pc"
	loggedin="0"
	translation='{"successTitle":"Thank you for flagging","successText":"If we find this content to be in violation of our <a href=\"https:\/\/www.pornhub.com\/information\/terms\">Terms of Service<\/a> we will remove it.","successButton":"Got it","btnCancel":"Cancel","btnSubmit":"Submit","btnNext":"Next","loginto":"If you have knowledge that the content violates our <a href=\"https:\/\/help.pornhub.com\/hc\/en-us\/articles\/4419869793683-Child-Sexual-Abuse-Material-Policy\" target=\"_blank\" rel=\"nofollow noopener\">CSAM policy<\/a> or <a href=\"https:\/\/help.pornhub.com\/hc\/en-us\/articles\/4419871787027-Non-Consensual-Content-Policy\" target=\"_blank\" rel=\"nofollow noopener\">NCC policy<\/a>, you may report it via our <a class=\"crrLink\" data-href=\"\/content-removal\" data-Flag-For=\"video\">Content Removal Request form<\/a>.","loginUrl":"\/login?redirect=hpWSvmo5_U7hBInwOhkIs4qa6CVkPNGPbf-0Cx2wnaFuecwNpxxfX11xAHkplpG8Z3GQXeuwXpFlSjjxKZInlblCBdCEJeGGKDYq3sfxVukqcbeCa7-PR1ZUK1Q%3D","login":"Login","reason":"Tell us why","error":"Please provide reason","reasonBox":"Help us understand why you believe this content violates our terms of service or is otherwise objectionable by providing additional information\/detail(s).","reasonChannel":"Please provide URL and any additional information to help us locate and address the reason for flagging.","title":"Report this video","subtitle":"By reporting a piece of content that you think is inappropriate, you are helping to protect the Pornhub community as well as the integrity of our platform. Thank you! Reporting content is anonymous, so users cannot tell who made the report. Tell us why you would like to report this content:","desc":"Pornhub is a user-driven platform, whose objective is to provide a sex-positive environment for responsible users. \n            You may not approve of or like everything you see on Pornhub. That does not mean that the content is illegal<label for=\"readMoreState\" class=\"readMoreLabel\">... <span>Read more<\/span><\/label> <span class=\"readMoreDesc\">, or inappropriate. \n            If, however, you believe certain content is inappropriate, you can use the flagging feature to submit the content for review by our Pornhub staff. \n            All content that is reported through our flagging feature is reviewed to ensure it is not in violation of our <a href=\"\/information\/terms#terms\" rel=\"nofollow noopener\">Terms of Services<\/a>. \n            However, flagging something does not mean that it gets automatically removed. If the content does violate our <a href=\"\/information\/terms#terms\" rel=\"nofollow noopener\">Terms of Services<\/a>, \n            the content will be removed and the associated accounts could be permanently closed. For more information on our policies, how we enforce our policies, \n            and how to report content that you think may violate our <a href=\"\/information\/terms#terms\" rel=\"nofollow noopener\">Terms of Service<\/a>, please visit our <a href=\"https:\/\/help.pornhub.com\/hc\/en-us\/categories\/4419836212499\" target=\"_blank\" rel=\"nofollow noopener\">Trust and Safety page<\/a>.<\/span>","yes":"Yes","no":"No","confirmMessage":"Do you appear in this content or have first-hand knowledge that the content violates our <a href=\"https:\/\/help.pornhub.com\/hc\/en-us\/articles\/4419869793683\" target=\"_blank\" rel=\"nofollow noopener\">Child Sexual Abuse Material Policy<\/a>?","footer":"","moreInfoMessage":"For more information about how we process these requests, please click <a href=\"https:\/\/help.pornhub.com\/hc\/en-us\/articles\/4419875025043-Report-Harmful-Content\" target=\"_blank\" rel=\"nofollow noopener\">here<\/a>."}'
	flag-types='[{"key":"7","value":"Infringes My Rights or Other Legal Concern","tooltip":"This content otherwise invades your privacy (i.e. doxing, blackmail)","popup":"We are committed to protecting our community and the users of our platform. We have a zero-tolerance policy toward uploads that violate our <a target=\"_blank\" rel=\"noopener noreferrer\" href=\"https:\/\/help.pornhub.com\/hc\/en-us\/articles\/4419871787027\">non-consensual content policy<\/a>,\n                    To have content that you have reason to believe invades your privacy, violates our <a target=\"_blank\" rel=\"noopener noreferrer\" href=\"https:\/\/help.pornhub.com\/hc\/en-us\/articles\/4419871787027\">non-consensual content policy<\/a>, or is illegal, reviewed for removal,\n                    please complete and submit our <a href=\"\/content-removal\" rel=\"nofollow noopener\">CONTENT REMOVAL REQUEST FORM<\/a>. We treat content removal requests seriously and review all requests.","next":"\/content-removal"},{"key":"3","value":"Copyright Concern","tooltip":"This content infringes on your copyright","popup":"If you are a copyright owner and wish to report a copyright infringement, please complete and submit our <a href=\"\/information\/dmcaform\" rel=\"nofollow noopener\" class=\"js-reportLink\">DMCA takedown form<\/a>. \n                        Learn more about our copyright policy by visiting our DMCA page: <a href=\"\/information\/dmca\">www.pornhub.com\/information\/dmca<\/a>","next":"\/information\/dmcaform"},{"key":"2","value":"Potentially Features a Minor","tooltip":"For the purposes of our <a href=\"https:\/\/help.pornhub.com\/hc\/en-us\/articles\/4419869793683\" target=\"_blank\" rel=\"nofollow noopener\">policy on child sexual abuse material<\/a>, a minor is a person under 18 years of age.","popup":"We are committed to protecting our community and the users of our platform. We have a zero-tolerance policy toward uploads that violate our <a target=\"_blank\" rel=\"noopener noreferrer\" href=\"https:\/\/help.pornhub.com\/hc\/en-us\/articles\/4419869793683\">child sexual abuse material (CSAM) policy<\/a>.\n            To have content that you have reason to believe violates our <a target=\"_blank\" rel=\"noopener noreferrer\" href=\"https:\/\/help.pornhub.com\/hc\/en-us\/articles\/4419869793683\">CSAM policy<\/a> reviewed for removal, please complete and submit our\n            <a href=\"\/content-removal\" rel=\"nofollow noopener\">CONTENT REMOVAL REQUEST FORM<\/a>. We treat content removal requests seriously and review all requests. If you believe a user\u2019s profile violates this policy or is otherwise inappropriate, you can use the flagging feature to have the user\u2019s profile reviewed by Pornhub staff.","next":"\/content-removal"},{"key":"1","value":"Violent or Harmful Acts","tooltip":"The content features activity which poses a real threat or likelihood of causing serious physical injury or death to the individual(s) featured and\/or appears potentially non-consensual."},{"key":"6","value":"Hateful or Inflammatory","tooltip":"The content incites violence and\/or hatred against identifiable individuals and\/or groups of persons."},{"key":"5","value":"Spam or Misleading Content","tooltip":"Content that is massively posted or which serves to mislead users."},{"key":"4","value":"Otherwise Inappropriate or Objectionable","tooltip":"Content that you believe otherwise violates our <a href=\"\/information\/terms#terms\" rel=\"nofollow noopener\">terms of service<\/a>.","reason":"Help us understand why you believe this content violates our terms of service or is otherwise objectionable by providing additional information\/detail(s)."}]'
	flag-for='video'
	submit-url="/video/flag?token=MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8."
	item-id="474848195"
	is-sfw="1"
></v-flag-modal>

<script>
    var USER_FLAG_TYPES = {"regularUser":[{"key":11,"value":"Report cover photo, avatar or other profile information","popup":"We are committed to protecting our community and the users of our platform. We have a zero-tolerance policy toward uploads that violate our <a href=\"https:\/\/help.pornhub.com\/hc\/en-us\/articles\/4419871787027\" rel=\"noopener noreferrer\" target=\"_blank\">Non-Consensual Content Policy<\/a> or <a href=\"https:\/\/help.pornhub.com\/hc\/en-us\/articles\/4419869793683\" rel=\"noopener noreferrer\" target=\"_blank\">Child Sexual Abuse Material Policy<\/a>. If you believe a user&#39;s profile violates these policies or is otherwise inappropriate, you can use the flagging feature to have the user&#39;s profile reviewed by Pornhub staff.","next":""},{"key":21,"value":"User appears to be underage","popup":"We are committed to user and child safety, and Pornhub&#39;s <a href=\"https:\/\/www.pornhub.com\/information\/terms#terms\" rel=\"nofollow noopener noreferrer\" target=\"_blank\">Terms of Service<\/a> requires users to be at least 18 years of age or the age of majority in the jurisdiction where the website is accessed. If you believe this user is underage, please use the flagging feature to have the user reviewed by Pornhub staff.","next":""},{"key":31,"value":"User is posting inappropriate or objectionable comments or chat","popup":"","next":""},{"key":41,"value":"User is spamming","popup":"","next":""},{"key":71,"value":"User is posting comments or chat related to <a href=\"https:\/\/help.pornhub.com\/hc\/en-us\/articles\/4419871787027\" rel=\"noopener noreferrer\" target=\"_blank\">non-consensual activity<\/a> or <a href=\"https:\/\/help.pornhub.com\/hc\/en-us\/articles\/4419869793683\" target=\"_blank\" rel=\"noopener noreferrer\">child sexual abuse<\/a>","popup":"","next":"","reason":"Help us understand why you believe this user is violating our Terms of Service by providing additional information below."}],"mppCppUser":[{"key":11,"value":"Report cover photo, avatar or other profile information","popup":"We are committed to protecting our community and the users of our platform. We have a zero-tolerance policy toward uploads that violate our <a href=\"https:\/\/help.pornhub.com\/hc\/en-us\/articles\/4419871787027\" rel=\"noopener noreferrer\" target=\"_blank\">Non-Consensual Content Policy<\/a> or <a href=\"https:\/\/help.pornhub.com\/hc\/en-us\/articles\/4419869793683\" rel=\"noopener noreferrer\" target=\"_blank\">Child Sexual Abuse Material Policy<\/a>. If you believe a user&#39;s profile violates these policies or is otherwise inappropriate, you can use the flagging feature to have the user&#39;s profile reviewed by Pornhub staff.","next":""},{"key":51,"value":"User&#39;s content infringes my rights, or other legal concern","popup":"We are committed to protecting our community and the users of our platform. We have a zero-tolerance policy toward uploads that violate our <a href=\"https:\/\/help.pornhub.com\/hc\/en-us\/articles\/4419871787027\" rel=\"noopener noreferrer\" target=\"_blank\">Non-Consensual Content Policy<\/a>. If you believe this user&#39;s content invades your privacy, violates our non-consensual content policy, or is illegal, please use the flagging feature to have the user&#39;s content reviewed by Pornhub staff.","next":""},{"key":21,"value":"User&#39;s content potentially features a minor","popup":"We are committed to user safety and have a zero-tolerance policy toward content that violates our <a href=\"https:\/\/help.pornhub.com\/hc\/en-us\/articles\/4419869793683\" rel=\"noopener noreferrer\" target=\"_blank\">Child Sexual Abuse Material Policy<\/a>. If you believe this user&#39;s content is in violation of this policy, please use the flagging feature to have the user&#39;s content reviewed by Pornhub staff.","next":""},{"key":61,"value":"User&#39;s content is otherwise inappropriate or objectionable","popup":"","next":""},{"key":31,"value":"User is posting inappropriate or objectionable comments or chat","popup":"","next":""},{"key":41,"value":"User is spamming","popup":"","next":""},{"key":71,"value":"User is posting comments or chat related to <a href=\"https:\/\/help.pornhub.com\/hc\/en-us\/articles\/4419871787027\" rel=\"noopener noreferrer\" target=\"_blank\">non-consensual activity<\/a> or <a href=\"https:\/\/help.pornhub.com\/hc\/en-us\/articles\/4419869793683\" target=\"_blank\" rel=\"noopener noreferrer\">child sexual abuse<\/a>","popup":"","next":"","reason":"Help us understand why you believe this user is violating our Terms of Service by providing additional information below."}]}</script>
            </div>

            <div class="reset"></div>
                            <div class="p52np1uwwwz1f">
                    <ins class='adsbytrafficjunky' data-spot-id='2517131' data-height='250' data-width='950'  style='width:950;height:250;display:block;margin:0 auto;'></ins>                </div>
            
            <div class="footerContentWrapper sfwFooterLinks">
                <div class="bodyText">
                    <ul class="legalLinks">
                        <li><a href="https://www.pornhub.com/information">Terms of Service</a></li>
                        <li><a href="https://www.pornhub.com/information/privacy">Privacy Notice</a></li>
                        <li><a href="https://www.pornhub.com/information/dmca">DMCA</a></li>
                        <li><a href="https://www.pornhub.com/information/dmcaform">DMCA Form</a></li>
                                                <li><a href="/support">Support</a></li>
                        <li><a href="https://www.pornhub.com/information/2257">2257</a></li>
                        <li><a href="/content-removal">Content Removal</a></li>
                        <li><a href="https://help.pornhub.com/hc/en-us/articles/4419869793683" target="_blank" rel="nofollow">CSAM Policy</a></li>
                        <li><a href="https://help.pornhub.com/hc/en-us/articles/4419871787027" target="_blank" rel="nofollow">NCC Policy</a></li>
                        <li><a href="https://help.pornhub.com/hc/en-us" target="_blank" rel="nofollow">Help Center</a></li>
                        <li><a href="https://help.pornhub.com/hc/en-us/categories/4419836212499" target="_blank" rel="nofollow">Trust and Safety</a></li>
                    </ul>
                </div>
                <div class="logoFooterWrapper">
                    <div class="socialIconsWrapper">
                        <a href="https://www.x.com/pornhub" rel="noopener" target="_blank" title="Connect with PornHub on X">
                            <i class="phIconFooter ph-icon-social-twitter"></i>
                        </a>
                        
                        <a href="https://discord.gg/pornhub" rel="noopener" target="_blank" title="Connect with PornHub on Discord">
                            <i class="phIconFooter ph-icon-social-discord"></i>
                        </a>
                    </div>
                    <span class="copyright">&copy; Pornhub.com, 2026</span>
                    <a class="rtaLink" href="/information/rating" rel="nofollow">
                        <div class="rta">
                            <img
                                    id="RTAImage"
                                    alt="RTA"
                                    width="88px" height="31px"
                                    src=""
                            />
                        </div>
                    </a>
                    <a
                            href="https://help.pornhub.com/hc/en-us/articles/44854458951571-The-Steps-We-re-Taking-to-Stop-the-Publication-of-CSAM-and-NCM"
                            class="noticeLink orangeButton"
                            rel="noopener nofollow"
                            target="_blank"
                    >
                        Notice to Users                    </a>
                </div>
            </div>
        </div>

                            
                

    
    <script src="https://ei.phncdn.com/www-static/js/lib/vue/vue.min.js"></script>
    <script src="https://ei.phncdn.com/www-static/js/lib/vue/vue-custom-element.min.js"></script>
                <script src="https://ei.phncdn.com/www-static/js/mg_modal-1.0.0.js?cache=2026052109"></script>
                    <script defer src="https://ei.phncdn.com/www-static/js/lib/generated-lib.js?cache=2026052109"></script>
        
                
        
<script type="text/javascript">
    // HEAD.JS SCRIPT
    jsFileList.core_Js = [
        page_params.jqueryVersion
    ];

    jsFileList.cust_Js = [
        'https://ei.phncdn.com/www-static/js/header.js?cache=2026052109',
			'https://ei.phncdn.com/www-static/js/lib/jquery.slimscroll.min.js'
    ];

    jsFileList.site_Js = [
        'https://ei.phncdn.com/www-static/js/phub.js?cache=2026052109',
			'https://ei.phncdn.com/www-static/js/lib/user-clogs.js?cache=2026052109',
			'https://ei.phncdn.com/www-static/js/lib/probiller-common.min.js?cache=2026052109',
			'https://ei.phncdn.com/www-static/js/playlist/playlist-basic.js?cache=2026052109',
			'https://ei.phncdn.com/www-static/js/widgets-live-popup.js?cache=2026052109',
			'https://ei.phncdn.com/www-static/js/v-recaptcha.js?cache=2026052109',
			'https://ei.phncdn.com/www-static/js/vmobile/connection-modal.js?cache=2026052109',
			'https://ei.phncdn.com/www-static/js/vmobile/login-form.js?cache=2026052109',
			'https://ei.phncdn.com/www-static/js/vmobile/signup-form.js?cache=2026052109',
			'https://ei.phncdn.com/www-static/js/onboardingModalFlow/widgets-onboardingModalFlow.js?cache=2026052109',
			'https://ei.phncdn.com/www-static/js/ph-footer.js?cache=2026052109',
			'https://ei.phncdn.com/www-static/js/premium/premium-modals.js?cache=2026052109',
			'https://ei.phncdn.com/www-static/js/vmobile/settings/settings.js?cache=2026052109'
    ];

    jsFileList.page_Js = [
                                                        "https://ss.phncdn.com/jquery/jquery.tokeninput-1.6.0.js",
                                                                "https://ei.phncdn.com/www-static/js/autocomplete-crowdsource.js?cache=2026052109",
                                                                "https://ei.phncdn.com/www-static/js/crowdsource.js?cache=2026052109",
                                                                "https://ei.phncdn.com/www-static/js/v-flag-modal.js?cache=2026052109",
                                                                "https://ei.phncdn.com/www-static/js/v-suggest-pornstar.js?cache=2026052109",
                                                                "https://ei.phncdn.com/www-static/js/video-show.js?cache=2026052109",
                                                                "https://ei.phncdn.com/www-static/js/htmlPauseRoll/pb_block.js?cache=2026052109",
                                        ];

    var Load_scripts=function(){"use strict";var e=this;e.init=function(t){e.params=t;e.params.finalFileList=[];e.myFileList()},e.myFileList=function(){var t=e.getKeys(e.params.jsFileList),n=0,r=t.length;for(;n<r;n++){e.getFileList(e.params.jsFileList[t[n]])}e.params.head.ready(function(){e.runHeadJs()})},e.getFileList=function(t){var n=0,r=t.length;for(;n<r;n++){e.params.finalFileList.push(t[n])}},e.runHeadJs=function(){var t=0,n=e.params.finalFileList.length;if(page_params.loadOnce){e.params.head.load(e.params.finalFileList);}else{for(;t<n;t++){e.params.head.load(e.params.finalFileList[t]);}}},e.getKeys=function(e){var t=[],n;for(n in e){if(e.hasOwnProperty(n)){t.push(n)}}return t}},myHead_JS=new Load_scripts;

    if (typeof window.performance !== 'undefined') {
        // head.load - v1.0.3 (inlined from CDN for performance)
        (function(n,t){"use strict";function w(){}function u(n,t){if(n){typeof n=="object"&&(n=[].slice.call(n));for(var i=0,r=n.length;i<r;i++)t.call(n,n[i],i)}}function it(n,i){var r=Object.prototype.toString.call(i).slice(8,-1);return i!==t&&i!==null&&r===n}function s(n){return it("Function",n)}function a(n){return it("Array",n)}function et(n){var i=n.split("/"),t=i[i.length-1],r=t.indexOf("?");return r!==-1?t.substring(0,r):t}function f(n){(n=n||w,n._done)||(n(),n._done=1)}function ot(n,t,r,u){var f=typeof n=="object"?n:{test:n,success:!t?!1:a(t)?t:[t],failure:!r?!1:a(r)?r:[r],callback:u||w},e=!!f.test;return e&&!!f.success?(f.success.push(f.callback),i.load.apply(null,f.success)):e||!f.failure?u():(f.failure.push(f.callback),i.load.apply(null,f.failure)),i}function v(n){var t={},i,r;if(typeof n=="object")for(i in n)!n[i]||(t={name:i,url:n[i]});else t={name:et(n),url:n};return(r=c[t.name],r&&r.url===t.url)?r:(c[t.name]=t,t)}function y(n){n=n||c;for(var t in n)if(n.hasOwnProperty(t)&&n[t].state!==l)return!1;return!0}function st(n){n.state=ft;u(n.onpreload,function(n){n.call()})}function ht(n){n.state===t&&(n.state=nt,n.onpreload=[],rt({url:n.url,type:"cache"},function(){st(n)}))}function ct(){var n=arguments,t=n[n.length-1],r=[].slice.call(n,1),f=r[0];return(s(t)||(t=null),a(n[0]))?(n[0].push(t),i.load.apply(null,n[0]),i):(f?(u(r,function(n){s(n)||!n||ht(v(n))}),b(v(n[0]),s(f)?f:function(){i.load.apply(null,r)})):b(v(n[0])),i)}function lt(){var n=arguments,t=n[n.length-1],r={};return(s(t)||(t=null),a(n[0]))?(n[0].push(t),i.load.apply(null,n[0]),i):(u(n,function(n){n!==t&&(n=v(n),r[n.name]=n)}),u(n,function(n){n!==t&&(n=v(n),b(n,function(){y(r)&&f(t)}))}),i)}function b(n,t){if(t=t||w,n.state===l){t();return}if(n.state===tt){i.ready(n.name,t);return}if(n.state===nt){n.onpreload.push(function(){b(n,t)});return}n.state=tt;rt(n,function(){n.state=l;t();u(h[n.name],function(n){f(n)});o&&y()&&u(h.ALL,function(n){f(n)})})}function at(n){n=n||"";var t=n.split("?")[0].split(".");return t[t.length-1].toLowerCase()}function rt(t,i){function e(t){t=t||n.event;u.onload=u.onreadystatechange=u.onerror=null;i()}function o(f){f=f||n.event;(f.type==="load"||/loaded|complete/.test(u.readyState)&&(!r.documentMode||r.documentMode<9))&&(n.clearTimeout(t.errorTimeout),n.clearTimeout(t.cssTimeout),u.onload=u.onreadystatechange=u.onerror=null,i())}function s(){if(t.state!==l&&t.cssRetries<=20){for(var i=0,f=r.styleSheets.length;i<f;i++)if(r.styleSheets[i].href===u.href){o({type:"load"});return}t.cssRetries++;t.cssTimeout=n.setTimeout(s,250)}}var u,h,f;i=i||w;h=at(t.url);h==="css"?(u=r.createElement("link"),u.type="text/"+(t.type||"css"),u.rel="stylesheet",u.href=t.url,t.cssRetries=0,t.cssTimeout=n.setTimeout(s,500)):(u=r.createElement("script"),u.type="text/"+(t.type||"javascript"),u.src=t.url);u.onload=u.onreadystatechange=o;u.onerror=e;u.async=!1;u.defer=!1;t.errorTimeout=n.setTimeout(function(){e({type:"timeout"})},7e3);f=r.head||r.getElementsByTagName("head")[0];f.insertBefore(u,f.lastChild)}function vt(){for(var t,u=r.getElementsByTagName("script"),n=0,f=u.length;n<f;n++)if(t=u[n].getAttribute("data-headjs-load"),!!t){i.load(t);return}}function yt(n,t){var v,p,e;return n===r?(o?f(t):d.push(t),i):(s(n)&&(t=n,n="ALL"),a(n))?(v={},u(n,function(n){v[n]=c[n];i.ready(n,function(){y(v)&&f(t)})}),i):typeof n!="string"||!s(t)?i:(p=c[n],p&&p.state===l||n==="ALL"&&y()&&o)?(f(t),i):(e=h[n],e?e.push(t):e=h[n]=[t],i)}function e(){if(!r.body){n.clearTimeout(i.readyTimeout);i.readyTimeout=n.setTimeout(e,50);return}o||(o=!0,vt(),u(d,function(n){f(n)}))}function k(){r.addEventListener?(r.removeEventListener("DOMContentLoaded",k,!1),e()):r.readyState==="complete"&&(r.detachEvent("onreadystatechange",k),e())}var r=n.document,d=[],h={},c={},ut="async"in r.createElement("script")||"MozAppearance"in r.documentElement.style||n.opera,o,g=n.head_conf&&n.head_conf.head||"head",i=n[g]=n[g]||function(){i.ready.apply(null,arguments)},nt=1,ft=2,tt=3,l=4,p;if(r.readyState==="complete")e();else if(r.addEventListener)r.addEventListener("DOMContentLoaded",k,!1),n.addEventListener("load",e,!1);else{r.attachEvent("onreadystatechange",k);r.attachEvent("onload",e);p=!1;try{p=!n.frameElement&&r.documentElement}catch(wt){}p&&p.doScroll&&function pt(){if(!o){try{p.doScroll("left")}catch(t){n.clearTimeout(i.readyTimeout);i.readyTimeout=n.setTimeout(pt,50);return}e()}}()}i.load=i.js=ut?lt:ct;i.test=ot;i.ready=yt;i.ready(r,function(){y()&&u(h.ALL,function(n){f(n)});i.feature&&i.feature("domloaded",!0)})})(window);
    }

    var readyStateCheckInterval = setInterval(function() {
        if (document.readyState === "complete") {
            clearInterval(readyStateCheckInterval);
            myHead_JS.init({
                'jsFileList'    : jsFileList,   //json object with file list
                'head'			: head 			//head.js plugin object
            });
        }
    }, 30);

    // Lazy Load function
    function Performance(e){var t=this;t.listener=e;t.domInteractive=false;t.domContentLoadedEventStart=false;t.domContentLoadedEventEnd=false;t.domComplete=false;t.loadEventStart=false;t.loadEventEnd=false;t.isset=function(e){if(typeof e!="undefined"){return true}return false};t.test=function(){if(!t.domInteractive&&performance.timing.domInteractive>0){t.domInteractive=true;var e=performance.timing.domInteractive-performance.timing.navigationStart;if(t.isset(t.listener)&&t.listener.domInteractive){t.listener.domInteractive(e)}}if(!t.domContentLoadedEventStart&&performance.timing.domContentLoadedEventStart>0){t.domContentLoadedEventStart=true;var e=performance.timing.domContentLoadedEventStart-performance.timing.navigationStart;if(t.isset(t.listener)&&t.listener.domContentLoadedEventStart){t.listener.domContentLoadedEventStart(e)}}if(!t.domContentLoadedEventEnd&&performance.timing.domContentLoadedEventEnd>0){t.domContentLoadedEventEnd=true;var e=performance.timing.domContentLoadedEventEnd-performance.timing.navigationStart;if(t.isset(t.listener)&&t.listener.domContentLoadedEventEnd){t.listener.domContentLoadedEventEnd(e)}}if(!t.domComplete&&performance.timing.domComplete>0){t.domComplete=true;var e=performance.timing.domComplete-performance.timing.navigationStart;if(t.isset(t.listener)&&t.listener.domComplete){t.listener.domComplete(e)}}if(!t.loadEventStart&&performance.timing.loadEventStart>0){t.loadEventStart=true;var e=performance.timing.loadEventStart-performance.timing.navigationStart;if(t.isset(t.listener)&&t.listener.loadEventStart){t.listener.loadEventStart(e)}}if(!t.loadEventEnd&&performance.timing.loadEventEnd>0){t.loadEventEnd=true;var e=performance.timing.loadEventEnd-performance.timing.navigationStart;if(t.isset(t.listener)&&t.listener.loadEventEnd){t.listener.loadEventEnd(e)}}if(!(t.domInteractive&&t.domInteractive&&t.domContentLoadedEventStart&&t.domContentLoadedEventEnd&&t.domComplete&&t.loadEventStart)){setTimeout(function(){t.test()},250)}};setTimeout(function(){t.test()},250)}

    var hasRun = false;

    function ll() {
        if (hasRun) {
            return;
        }
        hasRun = true;
        loadThumbs();
    }

    function PerformanceListener() {
        this.loadEventEnd = function(t) {
            setTimeout(function(){ ll(); }, 5);
        }
    }

    var t = new Performance(new PerformanceListener()), llTimeout = 15000;

    if (typeof performance === "undefined") {
        llTimeout = 1000;
    }

    setTimeout(function(){ ll(); }, llTimeout);

    function loadThumbsLazyLoad() {
        var image = document.querySelectorAll('.js-preload'),
            thumbToUse = 'data-mediumthumb';

        for (var i = 0; i < image.length; i++) {
            var itemsCount  = image[i];

            if (itemsCount.src != itemsCount.getAttribute(thumbToUse)) {
                itemsCount.src = itemsCount.getAttribute(thumbToUse);
            }

            if (i == 10) {
                break;
            }
        }
    }

    loadThumbsLazyLoad();

    // Thumbnail fetching:
    function loadThumbs() {
        var image = document.querySelectorAll('.js-preload'),
            thumbToUse = 'data-mediumthumb';
        for (var i = 0; i < image.length; i++) {
            var itemsCount = image[i];
            if (itemsCount.getAttribute(thumbToUse)) {
                if (itemsCount.src != itemsCount.getAttribute(thumbToUse)) {
                    itemsCount.src = itemsCount.getAttribute(thumbToUse);
                }
            }
        }
    }
</script>


            <script>
        (function(w, func){
            if (!func.isInWhitelist()) {
                func.inject();
            }
        })(window, (function (w) {
            'use strict'
            var c  = "aHR0cHM6Ly93d3cucG9ybmh1Yi5jb20=",
                wl = ['google', 'googlebot', 'pornhub(premium|soft){0,1}', 'msn', 'yahoo', 'yandex', 'pornhubvybmsymdol4iibwgwtkpwmeyd6luq2gxajgjzfjvotyt5zhyd'],
                pl = ['50\\.16\\.241\\.113', '50\\.16\\.241\\.114', '50\\.16\\.241\\.117', '50\\.16\\.247\\.234', '52\\.204\\.97\\.54',
                    '52\\.5\\.190\\.19', '54\\.197\\.234\\.188', '54\\.208\\.100\\.253', '23\\.21\\.227\\.69'];
            function validate(reg) {
                return w.location.href.search(reg) >= 0;
            }
            return {
                isInWhitelist: function() {
                    var reg = new RegExp('(\\.|\\/\\/)(((' + wl.join('|') + ')\\.(com|us|ca|co|ai|net|org|info|biz|io|dev|onion)|rf-pornhub\\.com)($|\\.|\\/)|('+ pl.join('|') +')($|\\/))', 'g');
                    return validate(reg)
                },
                inject: function () {
                    var divs = document.querySelectorAll('div');
                    var randomId = Math.floor(Math.random()*divs.length);
                    var script = document.createElement('script');
                    var scriptText = 'window.location.href = "' + w.atob(c) + '?utm_source=' + w.location.href + '&utm_medium=redirects&utm_campaign=hotlinkerredirects";';
                    script.innerText = scriptText;
                    divs[randomId].appendChild(script);
                }
            }
        })(window));
    </script>
        


<script type="text/javascript">
    var MODAL_PREMIUM_MESSAGE = {"backMessage":"Go back"};
</script>
                <script src="https://ei.phncdn.com/www-static/js/sfw_functions.js?cache=2026052109"></script>
                    
<script type="text/javascript">
    var captchaType = document.getElementById('captcha_type'),
        captchaToken = document.getElementById('captcha_token'),
        LOGIN_SIGNUP_MODAL_SIGNUP = {"activated":false};

    function recaptchaV3ApiCall() {
        grecaptcha.enterprise.ready(function () {
            grecaptcha.enterprise.execute('6LectvslAAAAAC51V1_hA5yWoPnhCvYbJaulh5Us', {action: 'signup'}).then(function (token) {
                addingTokens(token);
            });
        });
    }

    function initializeV3Captcha() {
        var head = document.getElementsByTagName('head')[0];
        var script = document.createElement('script');
        script.type = 'text/javascript';
        var promise = new Promise(function (resolve, reject) {
            script.onload = function () {
                grecaptcha.enterprise.ready(function () {
                    grecaptcha.enterprise.execute('6LectvslAAAAAC51V1_hA5yWoPnhCvYbJaulh5Us', {action: 'submit'}).then(function (token) {
                        addingTokens(token);
                        resolve('done');
                    });
                });
            };
        });
        script.src = 'https://www.google.com/recaptcha/enterprise.js?render=6LectvslAAAAAC51V1_hA5yWoPnhCvYbJaulh5Us';
        head.appendChild(script);
        return promise;
    }

    function addingTokens(token) {
        var captchaMultipleTokens = document.querySelectorAll('.js_captcha_token');
        captchaToken && (captchaToken.value = token);

        captchaMultipleTokens && [].forEach.call(captchaMultipleTokens, function (el) {
            el.value = token;
        });
    }
</script>

        
                    <link rel="stylesheet" href="https://ei.phncdn.com/www-static/css/header-non-critical.css?cache=2026052109" type="text/css" media="none" onload="this.media='all'" />
            <link rel="stylesheet" href="https://ei.phncdn.com/www-static/css/commons-non-critical.css?cache=2026052109" type="text/css" media="none" onload="this.media='all'" />
            <link rel="stylesheet" href="https://ei.phncdn.com/www-static/css/modals_commons.css?cache=2026052109" type="text/css" media="none" onload="this.media='all'" />

            <noscript>
                <link rel="stylesheet" href="https://ei.phncdn.com/www-static/css/header-non-critical.css?cache=2026052109" type="text/css" />
                <link rel="stylesheet" href="https://ei.phncdn.com/www-static/css/commons-non-critical.css?cache=2026052109" type="text/css" />
                <link rel="stylesheet" href="https://ei.phncdn.com/www-static/css/modals_commons.css?cache=2026052109" type="text/css" />
            </noscript>
        
        <script>
            var TOP_BODY = {"verificationModalTitle":"Two-Step Verification","phoneNumberVerificationError":"Incorrect code. Please try again.","ajaxError":"There was an error processing your request. Please try again.","loginUrl":"\/front\/authenticate","verificationSuccessfulMessage":"Logging in","token":"MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8.","urlResendCode":"\/user\/resend_verification_code","emptyImgSrc":"data:image\/gif;base64,R0lGODlhAQABAIAAAAAAAP\/\/\/yH5BAEAAAAALAAAAAABAAEAAAIBRAA7","country":"us"};
            var newModal = 'B';
            var clickedElement = '';
        </script>

                        <v-toast-message undo-text="Undo"></v-toast-message>
<script type="text/javascript">
    var videoMoreActionEnabled	= "0";
    var isLoggedIn	= "0";
    var loginRedirectUrl = "/login?redirect=_5fvpKib3BBw6-nLv4j5B9nc2Rknr-LdIw6ZKRNhjRw79YBrTVz58eRbBVL8OE90WK9sPz18tQlv1EvU0xR3x_-QNbFPTqyiGWAeeBJXhvZWo4eb4-4TWXW_2rI%3D";
    var signupRedirectUrl = "/signup?redirect=_5fvpKib3BBw6-nLv4j5B9nc2Rknr-LdIw6ZKRNhjRw79YBrTVz58eRbBVL8OE90WK9sPz18tQlv1EvU0xR3x_-QNbFPTqyiGWAeeBJXhvZWo4eb4-4TWXW_2rI%3D";
    var interestedUrl = "/api/v1/recommended/ajax_video_interest";
    var notInterestedUrl = "/api/v1/recommended/ajax_video_not_interested";
    var removeWatchLaterUrl = "/api/v1/playlist/video_remove_watchlater";
    var actionMenuTranslations = {"addToWatchLater":"Add to Watch Later","removeWatchLater":"Remove from Watch Later","addedToWatchLater":"Added to Watch Later","removedFromWatchLater":"Removed from Watch Later","subscribeToMsg":"Subscribe to","unSubscribeToMsg":"Unsubscribe from","subscribedMsg":"You have subscribed to","unSubscribedMsg":"You have unsubscribed from","betterVideosMsg":"Thank you, we will use this to recommend better videos","tryLater":"Something went wrong, Please try later","notInterestedMessage":"Thank you. We will use this to make your recommendations better.","undo":"Undo","manage":"Manage","notInterested":"Not interested","snoozeVideo":"Snooze video","hideVideo":"Hide video","hideCreator":"Hide","snoozeCreator":"Snooze","manageVideoFeed":"Manage video feed","ribbonManageVideoFeed":"You\u2019ve hidden many videos or creators. <button class=\"js-ribbon-manage-feed\">Manage your feed<\/button> to see more videos.","deleteClip":"Delete Clip","deleteCompilation":"Delete Compilation"};
    var isNotInterestedInContentFilterV2 = "1";
    var isProfilePage = "";
    var actionMenuToken = "MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8.";
    var subscribeActionObj = {"confirmSubscribeTxt":"By subscribing to this content partner you are also subscribing to all of their channels, would you like to continue?","confirmUnsubscribeTxt":"By unsubscribing from this content partner you are also unsubscribing from all of their channels, would you like to continue?","subscribeToChannelUrl":"\/channel\/subscribe_add_json?token=MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8.","unSubscribeFromChannelUrl":"\/channel\/subscribe_remove_json?token=MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8.","subscribeToUserUrl":"\/user\/subscribe_add_json?token=MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8.","unSubscribeFromUserUrl":"\/user\/subscribe_remove_json?token=MTc3OTU1ODI0MTBliE2CcRcjVOXicDsOVdS699IoDtZRcKTPMmxkxFhERPxA3PkFai1n7Nn6gKnGDf7tEjazk5DnuNBQJhS6MC8.","cannotSubscribe":"You cannot subscribe to a private member."};
    var actionMenuHideOption = true;
    var actionMenuOriginPage = "watchpage";
    var isSubscriptionsPage = false;
</script>
            </body>
</html>
